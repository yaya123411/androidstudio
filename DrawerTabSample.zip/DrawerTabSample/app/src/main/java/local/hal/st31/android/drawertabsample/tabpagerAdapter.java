package local.hal.st31.android.drawertabsample;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import local.hal.st31.android.drawertabsample.ui.home.one.one;
import local.hal.st31.android.drawertabsample.ui.home.two.two;

public class tabpagerAdapter extends FragmentStatePagerAdapter {

    String[] tabarray = new String[]{"テスト１","テスト２"};

    public tabpagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @Override
    public CharSequence getPageTitle(int position){
        return tabarray[position];
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {

        Fragment fragment = null;

        if(position == 0){
            fragment = new one();
        }else if(position == 1){
            fragment = new two();
        }
        return fragment;
    }

    @Override
    public int getCount() {
        return 2;
    }
}

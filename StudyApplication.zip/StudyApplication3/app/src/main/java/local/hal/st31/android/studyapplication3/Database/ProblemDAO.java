package local.hal.st31.android.studyapplication3.Database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ProblemDAO {
    /**
     * タイトル情報の全てのデータを取得するメソッド
     * @param db
     * @return
     */
    public static Cursor findAll(SQLiteDatabase db, long titleId){
        String sql = "SELECT * FROM problems WHERE titleId = '" + titleId + "' ORDER BY updateTime DESC";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * タイトルに含まれる問題を全件取得するメソッド
     * @param db
     * @param titleId
     * @return
     */
    public static Cursor findProblemAll(SQLiteDatabase db, Long titleId){
        String sql = "SELECT * FROM problems WHERE titleId = '" + titleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * そのユーザーがいるかをチェックする
     * @param db
     * @param id
     * @return
     */
    public static Problem findIdByPK(SQLiteDatabase db, long id){
        //id=_id
        String sql = "SELECT * FROM problems WHERE _id = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);
        Problem result = null;
        if(cursor.moveToFirst()){
            int idxQuestion = cursor.getColumnIndex("question");
            String question = cursor.getString(idxQuestion);
            int idxChoice = cursor.getColumnIndex("choice");
            String choice = cursor.getString(idxChoice);
            int idxchoiceA = cursor.getColumnIndex("choiceA");
            String choiceA = cursor.getString(idxchoiceA);
            int idxChoiceB = cursor.getColumnIndex("choiceB");
            String choiceB = cursor.getString(idxChoiceB);
            int idxChoiceC = cursor.getColumnIndex("choiceC");
            String choiceC = cursor.getString(idxChoiceC);
            int idxChoiceD = cursor.getColumnIndex("choiceD");
            String choiceD = cursor.getString(idxChoiceD);
            int idxChoiceE = cursor.getColumnIndex("choiceE");
            String choiceE = cursor.getString(idxChoiceE);
            int idxChoiceF = cursor.getColumnIndex("choiceF");
            String choiceF = cursor.getString(idxChoiceF);
            int idxChoiceG = cursor.getColumnIndex("choiceG");
            String choiceG = cursor.getString(idxChoiceG);
            int idxReply = cursor.getColumnIndex("reply");
            String reply = cursor.getString(idxReply);
            int idxExplanation = cursor.getColumnIndex("explanation");
            String explanation = cursor.getString(idxExplanation);

            result = new Problem();
            result.setId(id);
            result.setQuestion(question);
            result.setChoice(choice);
            result.setChoiceA(choiceA);
            result.setChoiceB(choiceB);
            result.setChoiceC(choiceC);
            result.setChoiceD(choiceD);
            result.setChoiceE(choiceE);
            result.setChoiceF(choiceF);
            result.setChoiceG(choiceG);
            result.setReply(reply);
            result.setExplanation(explanation);
        }
        return result;
    }

    /**
     * アップロードボタンが押された問題リストの問題をまとめるメソッド
     * @param db
     * @param problemTitleId
     * @return
     */
    public static ArrayList<Map<String, String>> findByTitleId(SQLiteDatabase db, long problemTitleId) {
        String sql = "";
        ArrayList<Map<String, String>> result = new ArrayList<>();
        sql = "SELECT question,choice,choiceA,choiceB,choiceC,choiceD,choiceE,choiceF,choiceG,reply,explanation FROM problems WHERE titleId = '" + problemTitleId + "' ORDER BY updateTime DESC";
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        for (int i = 0; i < cursor.getCount(); i++) {
            Map<String, String> record = new HashMap<>();
            record.put("question", cursor.getString(0));
            record.put("choice", cursor.getString(1));
            record.put("choiceA", cursor.getString(2));
            record.put("choiceB", cursor.getString(3));
            record.put("choiceC", cursor.getString(4));
            record.put("choiceD", cursor.getString(5));
            record.put("choiceE", cursor.getString(6));
            record.put("choiceF", cursor.getString(7));
            record.put("choiceG", cursor.getString(8));
            record.put("reply", cursor.getString(9));
            record.put("explanation", cursor.getString(10));
            result.add(record);
            cursor.moveToNext();
        }
        return result;
    }

    /**
     * 問題情報を追加するメソッド
     * @param db
     * @param userId
     * @param titleId
     * @param question
     * @param explanation
     * @return
     */
    public static long insert(SQLiteDatabase db, String userId, long titleId, String question, String choice, String[] hchoice, String reply, String explanation){
        String sql = "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, userId);
        stmt.bindString(2, String.valueOf(titleId));
        stmt.bindString(3, question);
        stmt.bindString(4, choice);
        if(choice.equals("off")){
            //記述式の場合
            stmt.bindString(5, hchoice[0]);
            for(int i=6; i<hchoice.length+5; i++){
                stmt.bindString(i, "");
            }
        }else{
            for(int i=5; i<hchoice.length+5; i++){
                stmt.bindString(i, hchoice[i-5]);
            }
        }
        stmt.bindString(12, reply);
        stmt.bindString(13, explanation);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * 問題情報を更新するメソッド
     * @param db
     * @param problemId
     * @param question
     * @param explanation
     * @return
     */
    public static int update(SQLiteDatabase db, long problemId, String question, String choice, String[] hchoice, String reply, String explanation){
        String sql = "UPDATE problems SET question = ?, choice = ?, choiceA = ?, choiceB = ?, choiceC = ?, choiceD = ?, choiceE = ?, choiceF = ?, choiceG = ?, reply = ?, explanation = ?, updateTime = datetime('now') WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, question);
        stmt.bindString(2, choice);
        if(choice.equals("off")) {
            //記述式の場合
            stmt.bindString(3, hchoice[0]);
            for(int i=4; i<hchoice.length+3; i++){
                stmt.bindString(i, "");
            }
        }else {
            for(int i=3; i<hchoice.length+3; i++){
                stmt.bindString(i, hchoice[i-3]);
            }
        }
        stmt.bindString(10, reply);
        stmt.bindString(11, explanation);
        stmt.bindLong(12, problemId);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }

    /**
     * 問題情報を削除するメソッド
     * @param db
     * @param problemId
     * @return
     */
    public static int delete(SQLiteDatabase db, long problemId){
        String sql = "DELETE FROM problems WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, problemId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    /**
     * タイトルに含まれる問題の個数を返すメソッド
     * @param db
     * @param titleId
     * @return
     */
    public static Integer problemCount(SQLiteDatabase db, long titleId){
        //id=_id
        String sql = "SELECT COUNT(*) as count FROM problems WHERE titleId = '" + titleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        Integer count = 0;
        if(cursor.moveToFirst()){
            int idxCount = cursor.getColumnIndex("count");
            String strCount = cursor.getString(idxCount);
            count = Integer.parseInt(strCount);
        }
        return count;
    }

    public static Problem findTitleAll(SQLiteDatabase db, long titleId){
        //id=_id
        String sql = "SELECT * FROM problems WHERE titleId = '" + titleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        Problem result = null;
        if(cursor.moveToFirst()){
            int idxQuestion = cursor.getColumnIndex("question");
            String question = cursor.getString(idxQuestion);
            int idxChoice = cursor.getColumnIndex("choice");
            String choice = cursor.getString(idxChoice);
            int idxchoiceA = cursor.getColumnIndex("choiceA");
            String choiceA = cursor.getString(idxchoiceA);
            int idxChoiceB = cursor.getColumnIndex("choiceB");
            String choiceB = cursor.getString(idxChoiceB);
            int idxChoiceC = cursor.getColumnIndex("choiceC");
            String choiceC = cursor.getString(idxChoiceC);
            int idxChoiceD = cursor.getColumnIndex("choiceD");
            String choiceD = cursor.getString(idxChoiceD);
            int idxChoiceE = cursor.getColumnIndex("choiceE");
            String choiceE = cursor.getString(idxChoiceE);
            int idxChoiceF = cursor.getColumnIndex("choiceF");
            String choiceF = cursor.getString(idxChoiceF);
            int idxChoiceG = cursor.getColumnIndex("choiceG");
            String choiceG = cursor.getString(idxChoiceG);
            int idxReply = cursor.getColumnIndex("reply");
            String reply = cursor.getString(idxReply);
            int idxExplanation = cursor.getColumnIndex("explanation");
            String explanation = cursor.getString(idxExplanation);

            result = new Problem();
            result.setQuestion(question);
            result.setChoice(choice);
            result.setChoiceA(choiceA);
            result.setChoiceB(choiceB);
            result.setChoiceC(choiceC);
            result.setChoiceD(choiceD);
            result.setChoiceE(choiceE);
            result.setChoiceF(choiceF);
            result.setChoiceG(choiceG);
            result.setChoiceG(reply);
            result.setExplanation(explanation);
        }
        return result;
    }

    /**
     * 問題数を取得
     * @param db
     * @param titleId
     * @return
     */
    public static String countProblem(SQLiteDatabase db, long titleId){
        //id=_id
        String sql = "SELECT COUNT(*) as count FROM problems WHERE titleId = '" + titleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        String result = null;
        if(cursor.moveToFirst()) {
            int idxCount = cursor.getColumnIndex("count");
            result = cursor.getString(idxCount);
        }
        return result;
    }

    /**
     * 問題を全件取得
     * @param db
     * @param titleId
     * @return
     */
    public static ArrayList<String> ProblemIdAll(SQLiteDatabase db, long titleId){
        ArrayList<String> arrayList = new ArrayList<String>();
        //id=_id
        String sql = "SELECT _id FROM problems WHERE titleId = '" + titleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        CharSequence[] list = new CharSequence[cursor.getCount()];
        for (int i = 0; i < list.length; i++) {
            arrayList.add(cursor.getString(0));
            cursor.moveToNext();
        }
        return arrayList;
    }

    public static Problem findIdByPK(SQLiteDatabase db, CharSequence id){
        String sql = "SELECT * FROM problems WHERE _id = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);
        Problem result = null;
        if(cursor.moveToFirst()){
            int idxQuestion = cursor.getColumnIndex("question");
            String question = cursor.getString(idxQuestion);
            int idxChoice = cursor.getColumnIndex("choice");
            String choice = cursor.getString(idxChoice);
            int idxchoiceA = cursor.getColumnIndex("choiceA");
            String choiceA = cursor.getString(idxchoiceA);
            int idxChoiceB = cursor.getColumnIndex("choiceB");
            String choiceB = cursor.getString(idxChoiceB);
            int idxChoiceC = cursor.getColumnIndex("choiceC");
            String choiceC = cursor.getString(idxChoiceC);
            int idxChoiceD = cursor.getColumnIndex("choiceD");
            String choiceD = cursor.getString(idxChoiceD);
            int idxChoiceE = cursor.getColumnIndex("choiceE");
            String choiceE = cursor.getString(idxChoiceE);
            int idxChoiceF = cursor.getColumnIndex("choiceF");
            String choiceF = cursor.getString(idxChoiceF);
            int idxChoiceG = cursor.getColumnIndex("choiceG");
            String choiceG = cursor.getString(idxChoiceG);
            int idxReply = cursor.getColumnIndex("reply");
            String reply = cursor.getString(idxReply);
            int idxExplanation = cursor.getColumnIndex("explanation");
            String explanation = cursor.getString(idxExplanation);

            result = new Problem();
            result.setQuestion(question);
            result.setChoice(choice);
            result.setChoiceA(choiceA);
            result.setChoiceB(choiceB);
            result.setChoiceC(choiceC);
            result.setChoiceD(choiceD);
            result.setChoiceE(choiceE);
            result.setChoiceF(choiceF);
            result.setChoiceG(choiceG);
            result.setReply(reply);
            result.setExplanation(explanation);

            //空白ではないカラム数
            int count = 0;

            result.setCount(count);
        }
        return result;
    }

    //正解、間違いの抽出条件
    public static Cursor findCondition(SQLiteDatabase db, long titleId, int count, String style, String extract){
        String sql = "";
        String sqlAddStyle = "";

        if(!extract.equals("")) {
            //検索されている場合
            sqlAddStyle = " AND p.question like '%" + extract + "%' ";
        }

        if(!style.equals("")){
            if(style.equals("正解")){
                //正解のみが押された場合
                sql = "SELECT question,m._id,c.count,choice FROM problems as p LEFT OUTER JOIN (SELECT * FROM correctSolutionProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as c ON p._id = c.problemId\n" +
                        "LEFT OUTER JOIN (SELECT * FROM mistakeProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as m ON p._id = m.problemId\n" +
                        "WHERE p.titleId = '" +titleId + "' " +
                        "AND m._id IS NULL " +
                        sqlAddStyle +
                        "ORDER BY updateTime DESC";
//            sql = "SELECT * FROM problems LEFT OUTER JOIN correctSolutionProblem ON problems._id = correctSolutionProblem.problemId WHERE problems.titleId = '" + titleId + "' AND correctSolutionProblem.count = '" + count + "' ORDER BY updateTime DESC";
            }else if(style.equals("間違い")){
                sql = "SELECT question,m._id,c.count,choice FROM problems as p LEFT OUTER JOIN (SELECT * FROM correctSolutionProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as c ON p._id = c.problemId\n" +
                        "LEFT OUTER JOIN (SELECT * FROM mistakeProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as m ON p._id = m.problemId\n" +
                        "WHERE p.titleId = '" +titleId + "' " +
                        "AND c._id IS NULL " +
                        sqlAddStyle +
                        "ORDER BY updateTime DESC";
//            sql = "SELECT * FROM problems LEFT OUTER JOIN mistakeProblem ON problems._id = mistakeProblem.problemId WHERE problems.titleId = '" + titleId + "' AND mistakeProblem.count = '" + count + "' ORDER BY updateTime DESC";
            }else if(style.equals("最初")){
                //最初が押された場合
                sql = "SELECT question,m._id,c.count,choice,p._id as problemId FROM problems as p LEFT OUTER JOIN (SELECT * FROM correctSolutionProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as c ON p._id = c.problemId\n" +
                        "LEFT OUTER JOIN (SELECT * FROM mistakeProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as m ON p._id = m.problemId\n" +
                        "WHERE p.titleId = '" +titleId + "' " +
                        sqlAddStyle +
                        "ORDER BY problemId";
            }else if(style.equals("最後")){
                //最後が押された場合
                sql = "SELECT question,m._id,c.count,choice,p._id as problemId FROM problems as p LEFT OUTER JOIN (SELECT * FROM correctSolutionProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as c ON p._id = c.problemId\n" +
                        "LEFT OUTER JOIN (SELECT * FROM mistakeProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as m ON p._id = m.problemId\n" +
                        "WHERE p.titleId = '" +titleId + "' " +
                        sqlAddStyle +
                        "ORDER BY problemId DESC";
            }else if(style.equals("検索")){
                sql = "SELECT question,m._id,c.count,choice FROM problems as p LEFT OUTER JOIN (SELECT * FROM correctSolutionProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as c ON p._id = c.problemId " +
                        "LEFT OUTER JOIN (SELECT * FROM mistakeProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as m ON p._id = m.problemId " +
                        "WHERE p.titleId = '" +titleId + "' " +
                        sqlAddStyle +
                        "ORDER BY updateTime DESC";
            }
        }else{
            sql = "SELECT question,m._id,c.count,choice FROM problems as p LEFT OUTER JOIN (SELECT * FROM correctSolutionProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as c ON p._id = c.problemId " +
                    "LEFT OUTER JOIN (SELECT * FROM mistakeProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as m ON p._id = m.problemId " +
                    "WHERE p.titleId = '" +titleId + "' " +
                    "ORDER BY updateTime DESC";
        }

        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    //並び替え
//    public static Cursor findOrderby(SQLiteDatabase db, long titleId, int count, String orderby, String addWhere){
//        String sql = "";
//        String strWhere = "";
//
//        if(!addWhere.equals("")) {
//            //検索されている場合
//            strWhere = " AND p.question like '%" + addWhere + "%' ";
//        }
//
//        if(orderby.equals("最初")){
//            //最初が押された場合
//            sql = "SELECT * FROM problems as p LEFT OUTER JOIN (SELECT * FROM correctSolutionProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as c ON p._id = c.problemId\n" +
//                    "LEFT OUTER JOIN (SELECT * FROM mistakeProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as m ON p._id = m.problemId\n" +
//                    "WHERE p.titleId = '" +titleId + "' " +
//                    strWhere +
//                    "ORDER BY _id";
//        }else if(orderby.equals("最後")){
//            //最後が押された場合
//            sql = "SELECT * FROM problems as p LEFT OUTER JOIN (SELECT * FROM correctSolutionProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as c ON p._id = c.problemId\n" +
//                    "LEFT OUTER JOIN (SELECT * FROM mistakeProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as m ON p._id = m.problemId\n" +
//                    "WHERE p.titleId = '" +titleId + "' " +
//                    strWhere +
//                    "ORDER BY _id DESC";
//        }
//        Cursor cursor = db.rawQuery(sql, null);
//        return cursor;
//    }

    /**
     * タイトル情報の全てのデータを取得するメソッド
     * @param db
     * @return
     */
    public static Cursor findPastAll(SQLiteDatabase db, long titleId, long count){
        String sql = "SELECT * FROM problems as p LEFT OUTER JOIN (SELECT * FROM correctSolutionProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as c ON p._id = c.problemId\n" +
                "LEFT OUTER JOIN (SELECT * FROM mistakeProblem WHERE count = '" + count + "' AND titleId = '" + titleId + "') as m ON p._id = m.problemId\n" +
                "WHERE p.titleId = '" +titleId + "' GROUP BY p._id";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * 条件で一致した問題のIDを全件取得
     * @param db
     * @param titleId
     * @return
     */
    public static CharSequence[] ProblemIdSeachAll(SQLiteDatabase db, long titleId, long count, String style, String extract){
        String sqlCount = "";
        String strWhere = "";

        if(!extract.equals("")) {
            //検索されている場合
            strWhere = " AND question like '%" + extract + "%' ";
        }
        if(count != 0){
            //成績の並び替えだった場合
            sqlCount = "count = " + count;
        }

        String sql = "SELECT _id FROM problems WHERE titleId = '" + titleId + "'" + strWhere + "ORDER BY updateTime DESC";

        //絞り込み
        if(style.equals("正解")){
            //正解のみが押された場合
            sql = "SELECT * FROM problems LEFT OUTER JOIN correctSolutionProblem ON problems._id = correctSolutionProblem.problemId WHERE problems.titleId = '" + titleId + "' AND correctSolutionProblem." + sqlCount + strWhere + " ORDER BY updateTime DESC";
        }else if(style.equals("間違い")){
            sql = "SELECT * FROM problems LEFT OUTER JOIN mistakeProblem ON problems._id = mistakeProblem.problemId WHERE problems.titleId = '" + titleId + "' AND mistakeProblem." + sqlCount + strWhere + " ORDER BY updateTime DESC";
        }
        //並び替え
        if(style.equals("最初")){
            //最初が押された場合
            sql = "SELECT * FROM problems WHERE titleId = '" + titleId + "'" + strWhere + " ORDER BY _id";
        }else if(style.equals("最後")){
            //最後が押された場合
            sql = "SELECT * FROM problems WHERE titleId = '" + titleId + "'" + strWhere + " ORDER BY _id DESC";
        }

        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        CharSequence[] list = new CharSequence[cursor.getCount()];
        for (int i = 0; i < list.length; i++) {
            list[i] = cursor.getString(0);
            cursor.moveToNext();
        }
        return list;
    }


    //-----------------------------------------ダウンロード------------------------------------
    //ダウンロードした問題を問題テーブルに追加する
    public static long shareProblemInsert(SQLiteDatabase db, String userId, long titleId, String question, String choice, String choiceA, String choiceB, String choiceC, String choiceD, String choiceE, String choiceF, String choiceG, String reply, String explanation){
        String sql = "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, userId);
        stmt.bindLong(2, titleId);
        stmt.bindString(3, question);
        stmt.bindString(4, choice);
        stmt.bindString(5, choiceA);
        stmt.bindString(6, choiceB);
        stmt.bindString(7, choiceC);
        stmt.bindString(8, choiceD);
        stmt.bindString(9, choiceE);
        stmt.bindString(10, choiceF);
        stmt.bindString(11, choiceG);
        stmt.bindString(12, reply);
        stmt.bindString(13, explanation);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * ダウンロードした問題のデータを取得
     * @param db
     * @param downloadId
     * @return
     */
    public static ArrayList<Problem> downloadAddProblemTitle(SQLiteDatabase db, long downloadId){
        ArrayList<Problem> arrayList = new ArrayList<>();
        String sql = "SELECT problems.titleId, problems.question, problems.choice, problems.choiceA, problems.choiceB, problems.choiceC, problems.choiceD, problems.choiceE, problems.choiceF, problems.choiceG, problems.reply, problems.explanation, problems.updateTime FROM download LEFT OUTER JOIN problems ON download.parentTitleId = problems.titleId WHERE download._id = '" + downloadId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        CharSequence[] list = new CharSequence[cursor.getCount()];
        Problem result = null;
        cursor.moveToFirst();
        for (int i = 0; i < list.length; i++) {
            String titleId = cursor.getString(0);
            String question = cursor.getString(1);
            String choice = cursor.getString(2);
            String choiceA = cursor.getString(3);
            String choiceB = cursor.getString(4);
            String choiceC = cursor.getString(5);
            String choiceD = cursor.getString(6);
            String choiceE = cursor.getString(7);
            String choiceF = cursor.getString(8);
            String choiceG = cursor.getString(9);
            String reply = cursor.getString(10);
            String explanation = cursor.getString(11);
            String updateTime = cursor.getString(12);

            result = new Problem();
            result.setTitleId(Long.parseLong(String.valueOf(titleId)));
            result.setQuestion(question);
            result.setChoice(choice);
            result.setChoiceA(choiceA);
            result.setChoiceB(choiceB);
            result.setChoiceC(choiceC);
            result.setChoiceD(choiceD);
            result.setChoiceE(choiceE);
            result.setChoiceF(choiceF);
            result.setChoiceG(choiceG);
            result.setReply(reply);
            result.setExplanation(explanation);
            result.setUpdateTime(updateTime);
            arrayList.add(result);
            cursor.moveToNext();
        }
        return arrayList;
    }

    /**
     * 問題のタイトルが削除された時のメソッド
     * @param db
     * @param titleId
     * @return
     */
    public static int problemTitledelete(SQLiteDatabase db, long titleId) {
        String sql = "DELETE FROM problems WHERE titleId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, titleId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    /**
     * ダウンロード済みの問題を全て削除する
     * @param db
     * @param downloadId
     * @return
     */
    public static int deleteByProblemId(SQLiteDatabase db, long downloadId){
        String sql = "DELETE FROM problems WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, downloadId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    //--------------------------------------------メニュー---------------------------------
    public static Cursor findSerch(SQLiteDatabase db, long titleId, String serch, String sort){
        String sql = "";
        String where = "";
        String orderBy = "";

        if(!serch.equals("")){
            //検索
            where = " AND question like '%" + serch + "%'";
        }
        if(!sort.equals("")){
            //並び替え
            if(sort.equals("更新順")) {
                orderBy = " ORDER BY updateTime DESC";
            }else if(sort.equals("新しい順")){
                orderBy = " ORDER BY _id DESC";
            }else if(sort.equals("古い順")){
                orderBy = " ORDER BY _id ASC";
            }
        }else{
            orderBy = " ORDER BY updateTime DESC";
        }

        sql = "SELECT * FROM problems WHERE titleId = '" + titleId + "'" + where + orderBy;
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    //--------------------------------------レポート-----------------------------------
    /**
     * タイトルに含まれる問題を全件取得するメソッド
     * @param db
     * @param titleId
     * @return
     */
    public static Cursor findProblemAllReport(SQLiteDatabase db, Long titleId){
        String sql = "SELECT p._id,p.question,CASE WHEN c._id IS NULL THEN 0 ELSE COUNT(*) END AS num FROM problems as p LEFT OUTER JOIN correctSolutionProblem as c ON p._id = c.problemId WHERE p.titleId = " + titleId + " GROUP BY p._id";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * 答えの選択肢の文章を取得するメソッド
     * @param db
     * @param problemId
     * @return
     */
    public static HashMap<String, String> getChoose(SQLiteDatabase db, CharSequence problemId){
        ArrayList<String> arrayList = new ArrayList<>();
        HashMap<String, String> chooseList = new HashMap<>();
        //id=_id
        String sql = "SELECT * FROM problems WHERE _id = '" + problemId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        for (int i = 0; i < cursor.getCount(); i++) {
            arrayList.add(cursor.getString(4));
            arrayList.add(cursor.getString(5));
            arrayList.add(cursor.getString(6));
            arrayList.add(cursor.getString(7));
            arrayList.add(cursor.getString(8));
            arrayList.add(cursor.getString(9));
            arrayList.add(cursor.getString(10));
            arrayList.add(cursor.getString(11));
            arrayList.add(cursor.getString(12));
            cursor.moveToNext();
        }

        //選択式ならば
        if(arrayList.get(8).indexOf("ア") != -1 && arrayList.get(0).equals("on")){
            chooseList.put("ア:", arrayList.get(1));
        }
        if(arrayList.get(8).indexOf("イ") != -1 && arrayList.get(0).equals("on")){
            chooseList.put("イ:", arrayList.get(2));
        }
        if(arrayList.get(8).indexOf("ウ") != -1 && arrayList.get(0).equals("on")){
            chooseList.put("ウ:", arrayList.get(3));
        }
        if(arrayList.get(8).indexOf("エ") != -1 && arrayList.get(0).equals("on")){
            chooseList.put("エ:", arrayList.get(4));
        }
        if(arrayList.get(8).indexOf("オ") != -1 && arrayList.get(0).equals("on")){
            chooseList.put("オ:", arrayList.get(5));
        }
        if(arrayList.get(8).indexOf("カ") != -1 && arrayList.get(0).equals("on")){
            chooseList.put("カ:", arrayList.get(6));
        }
        if(arrayList.get(8).indexOf("キ") != -1 && arrayList.get(0).equals("on")){
            chooseList.put("キ:", arrayList.get(7));
        }

        if(arrayList.get(0).equals("off")){
            //記述式ならば
            chooseList.put("", arrayList.get(8));
        }

        return chooseList;
    }
}

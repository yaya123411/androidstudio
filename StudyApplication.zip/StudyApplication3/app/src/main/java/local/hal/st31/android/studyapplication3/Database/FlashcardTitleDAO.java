package local.hal.st31.android.studyapplication3.Database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

public class FlashcardTitleDAO {
    /**
     * タイトル情報の全てのデータを取得するメソッド
     * @param db
     * @return
     */
    public static Cursor findAll(SQLiteDatabase db, String userId){
        String sql = "SELECT * FROM flashcardTitle WHERE userId = '" + userId + "' AND downloadId = 0 ORDER BY updateTime DESC";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * アップロードした単語帳のデータを取得するメソッド
     * @param db
     * @param userId
     * @return
     */
    public static Cursor findUpload(SQLiteDatabase db, String userId){
        String sql = "SELECT * FROM flashcardTitle WHERE userId = '" + userId + "' AND uploadFlg = 1 ORDER BY updateTime DESC";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * 特定のタイトル情報を取得するメソッド
     * @param db
     * @param id
     * @return
     */
    public static FlashcardTitle findIdByPK(SQLiteDatabase db, long id){
        String sql = "SELECT * FROM flashcardTitle WHERE _id = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);
        FlashcardTitle result = null;
        if(cursor.moveToFirst()){
            int idxId = cursor.getColumnIndex("_id");
            String flashcardTitleId = cursor.getString(idxId);
            int idxTitle = cursor.getColumnIndex("title");
            String title = cursor.getString(idxTitle);
            int idxFormulaFlg = cursor.getColumnIndex("formulaFlg");
            String formula = cursor.getString(idxFormulaFlg);
            int idxUploadFlg = cursor.getColumnIndex("uploadFlg");
            String uploadFlg = cursor.getString(idxUploadFlg);

            result = new FlashcardTitle();
            result.setId(Long.parseLong(flashcardTitleId));
            result.setTitle(title);
            result.setFormulaFlg(Integer.parseInt(formula));
            result.setUploadFlg(Integer.parseInt(uploadFlg));
        }
        return result;
    }

    /**
     * タイトル情報を追加するメソッド
     * @param db
     * @param userId
     * @param title
     * @return
     */
    public static long insert(SQLiteDatabase db, String userId, String title, int formulaFlg){
        String sql = "INSERT INTO flashcardTitle (userId, title, downloadId, uploadFlg, formulaFlg, updateTime) VALUES (?, ?, 0, 0, ?, datetime('now'))";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, userId);
        stmt.bindString(2, title);
        stmt.bindLong(3, formulaFlg);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * 単語帳のタイトルを更新するメソッド
     * @param db
     * @param flashcardTitleId
     * @param title
     * @return
     */
    public static int update(SQLiteDatabase db, long flashcardTitleId, String title){
        String sql = "UPDATE flashcardTitle SET title = ?, updateTime = datetime('now') WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, title);
        stmt.bindLong(2, flashcardTitleId);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }

    /**
     * 単語帳のタイトル情報を削除するメソッド
     * @param db
     * @param id
     * @return
     */
    public static int delete(SQLiteDatabase db, long id){
        String sql = "DELETE FROM flashcardTitle WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, id);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    /**
     * アップロードするメソッド
     * @param db
     * @param flashcardTitleId
     * @return
     */
    public static int updateUpload(SQLiteDatabase db, long flashcardTitleId){
        String sql = "UPDATE flashcardTitle SET uploadFlg = 1 WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, flashcardTitleId);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }

    /**
     * 特定のタイトル情報を取得するメソッド
     * @param db
     * @param id
     * @return
     */
    public static FlashcardTitle updateFindUploadFlg(SQLiteDatabase db, long id){
        String sql = "SELECT * FROM flashcardTitle WHERE _id = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);
        FlashcardTitle result = null;
        if(cursor.moveToFirst()){
            int idxUploadFlg = cursor.getColumnIndex("uploadFlg");
            String uploadFlg = cursor.getString(idxUploadFlg);

            result = new FlashcardTitle();
            result.setUploadFlg(Integer.parseInt(uploadFlg));
        }
        return result;
    }

    //-----------------------------------------ダウンロード-------------------------------------
    /**
     * 既にダウンロードしてあるかどうか
     * @param db
     * @param downloadId
     * @return
     */
    public static FlashcardTitle downloadDone(SQLiteDatabase db, long downloadId){
        String sql = "SELECT _id FROM flashcardTitle WHERE downloadId = '" + downloadId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        FlashcardTitle result = null;
        if(cursor.moveToFirst()){
            int idxId = cursor.getColumnIndex("_id");
            String id = cursor.getString(idxId);

            result = new FlashcardTitle();
            result.setId(Long.parseLong(id));
        }
        return result;
    }

    /**
     * ダウンロードしたタイトル一覧を表示するメソッド
     * @param db
     * @param userId
     * @return
     */
    public static Cursor findDownload(SQLiteDatabase db, String userId, int formula){
        String sql = "SELECT * FROM flashcardTitle WHERE userId = '" + userId + "' AND formulaFlg = " + formula + " AND downloadId <> 0 ORDER BY updateTime DESC";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    //ダウンロードした単語帳を単語帳タイトルテーブルに追加する
    public static long shareFlashcardTitleInsert(SQLiteDatabase db, String userId, long downloadId, String title, int formulaFlg){
        String sql = "INSERT INTO flashcardTitle (userId, downloadId, title, uploadFlg, formulaFlg, updateTime) VALUES (?, ?, ?, 0, ?, datetime('now'))";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, userId);
        stmt.bindLong(2, downloadId);
        stmt.bindString(3, title);
        stmt.bindLong(4, formulaFlg);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * ダウンロードした単語帳のタイトルのデータを取得
     * @param db
     * @param downloadId
     * @return
     */
    public static FlashcardTitle downloadAddFlashcardTitle(SQLiteDatabase db, long downloadId){
        String sql = "SELECT flashcardTitle.title,flashcardTitle.msg,flashcardTitle.formulaFlg FROM download LEFT OUTER JOIN flashcardTitle ON download.parentTitleId = flashcardTitle._id WHERE download._id = '" + downloadId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        FlashcardTitle result = null;
        if(cursor.moveToFirst()){
            int idxTitle = cursor.getColumnIndex("title");
            String title = cursor.getString(idxTitle);
            int idxMsg = cursor.getColumnIndex("msg");
            String msg = cursor.getString(idxMsg);
            int idxFormulaFlg = cursor.getColumnIndex("formulaFlg");
            String formulaFlg = cursor.getString(idxFormulaFlg);

            result = new FlashcardTitle();
            result.setTitle(title);
            result.setMsg(msg);
            result.setFormulaFlg(Integer.parseInt(formulaFlg));
        }
        return result;
    }

    /**
     * ダウンロード済みの単語帳タイトルを削除する
     * @param db
     * @param downloadId
     * @return
     */
    public static int deleteByDownloadId(SQLiteDatabase db, long downloadId){
        String sql = "DELETE FROM flashcardTitle WHERE downloadId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, downloadId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    /**
     * 公式かを識別する
     * @param db
     * @param flashcardTitleId
     * @return
     */
    public static int formulaMarkFindByTitldId(SQLiteDatabase db, long flashcardTitleId){
        String sql = "SELECT formulaFlg FROM flashcardTitle WHERE _id = '" + flashcardTitleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        int result = 0;
        if(cursor.moveToFirst()){
            int idxFormulaFlg = cursor.getColumnIndex("formulaFlg");
            String formulaFlg = cursor.getString(idxFormulaFlg);

            result = Integer.parseInt(formulaFlg);
        }
        return result;
    }

    public static long downloadIdByFlashcardId(SQLiteDatabase db, long flashcardTitleId){
        String sql = "SELECT downloadId FROM flashcardTitle WHERE _id = '" + flashcardTitleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        long result = 0;
        if(cursor.moveToFirst()){
            int idxDownloadId = cursor.getColumnIndex("downloadId");
            String downloadId = cursor.getString(idxDownloadId);

            result = Long.parseLong(String.valueOf(downloadId));
        }

        return result;
    }

    //------------------------------------------メニュー---------------------------------------
    /**
     * 並び替え、抽出条件を指定できるメソッド
     * @param db
     * @param userId
     * @param serch
     * @param sort
     * @return
     */
    public static Cursor findSeach(SQLiteDatabase db, String userId, String serch, String take, String sort, int downloadFlg){
        String sql = "";
        String where = "";
        String orderBy = "";

        if(!serch.equals("")){
            //検索ボタンが押された場合
            where = " AND title like '%" + serch + "%'";
        }
        if(downloadFlg == 0){
            where += " AND downloadId = 0";
        }else{
            where += " AND downloadId <> 0";
        }
        if(!take.equals("")){
            //抽出条件
            if(take.equals("アップロードされてる")){
                where += " AND uploadFlg = 1";
            }else if(take.equals("アップロードされていない")){
                where += " AND uploadFlg = 0";
            }
        }
        if(!sort.equals("")){
            //並び替え
            if(sort.equals("更新順")) {
                orderBy = " ORDER BY updateTime DESC";
            }else if(sort.equals("新しい順")){
                orderBy = " ORDER BY _id DESC";
            }else if(sort.equals("古い順")){
                orderBy = " ORDER BY _id ASC";
            }
        }else{
            orderBy = " ORDER BY updateTime DESC";
        }

        sql = "SELECT * FROM FlashcardTitle WHERE userId = '" + userId + "'" + where + orderBy;

        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    //--------------------------------------------メニュー---------------------------------
    public static Cursor findSerch(SQLiteDatabase db, long flashcardTitleId, String serch, String sort, int downloadFlg){
        String sql = "";
        String where = "";
        String orderBy = "";

        if(!serch.equals("")){
            //検索
            where = " AND front like '%" + serch + "%'";
        }
        if(downloadFlg == 0){
            where += " AND downloadId = 0";
        }else{
            where += " AND downloadId <> 0";
        }
        if(!sort.equals("")){
            //並び替え
            if(sort.equals("更新順")) {
                orderBy = " ORDER BY updateTime DESC";
            }else if(sort.equals("新しい順")){
                orderBy = " ORDER BY _id DESC";
            }else if(sort.equals("古い順")){
                orderBy = " ORDER BY _id ASC";
            }
        }else{
            orderBy = " ORDER BY updateTime DESC";
        }

        sql = "SELECT * FROM flashcard WHERE flashcardTitleId = '" + flashcardTitleId + "'" + where + orderBy;
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    //----------------------------------------アップロード--------------------------------
    /**
     * 自分がアップロードした単語帳をダウンロードテーブルから削除する
     * @param db
     * @param id
     * @return
     */
    public static int uploadUpdate(SQLiteDatabase db, long id){
        String sql = "UPDATE flashcardTitle SET uploadFlg = 0 WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, id);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }
}

package local.hal.st31.android.studyapplication3.Database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

public class UserDAO {
    /**
     * 主キーによる検索
     *
     * @param db SQLinteDatabaseオブジェクト。
     * @param id 主キー値
     * @return 主キーに対応するデータを格納したMemoオブジェクト。対応するデータが存在しない場合はnull。
     */
    public static User findByPK(SQLiteDatabase db, String id, String password){
        String sql = "SELECT * FROM user WHERE _userId = '" + id + "' and password = '" + password + "'";
        Cursor cursor = db.rawQuery(sql, null);
        User result = null;
        if(cursor.moveToFirst()){
            int idxUserName = cursor.getColumnIndex("userName");
            String userName = cursor.getString(idxUserName);
            int idxUserId = cursor.getColumnIndex("_userId");
            String userId = cursor.getString(idxUserId);

            result = new User();
            result.setUserId(userId);
            result.setUserName(userName);
        }
        return result;
    }

    //そのユーザーがいるかをチェックする
    public static User findUserIdByPK(SQLiteDatabase db, String id){
        String sql = "SELECT * FROM user WHERE _userId = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);
        User result = null;

        if(cursor.moveToFirst()){
            int idxUserId = cursor.getColumnIndex("_userId");
            String userId = cursor.getString(idxUserId);
            int idxUserName = cursor.getColumnIndex("userName");
            String userName = cursor.getString(idxUserName);
            int idxPassword = cursor.getColumnIndex("password");
            String password = cursor.getString(idxPassword);

            result = new User();
            result.setUserId(userId);
            result.setUserName(userName);
            result.setPassword(password);
        }
        return result;
    }

    /**
     * ユーザー情報を新規登録するメソッド
     * @param db SQLiteDatabaseオブジェクト。
     * @param strUserId ユーザーID
     * @param strUserName ユーザー名
     * @param strPassword パスワード
     * @return 登録したレコードの主キー値
     */
    public static long insert(SQLiteDatabase db, String strUserId, String strUserName, String strPassword, int formulaFlg){
        String sql = "INSERT INTO user (_userId, userName, password, formulaFlg) VALUES (?, ?, ?, ?)";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, strUserId);
        stmt.bindString(2, strUserName);
        stmt.bindString(3, strPassword);
        stmt.bindLong(4, formulaFlg);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * ユーザー情報を更新するメソッド
     * @param db
     * @param strOldUserId
     * @param strUserId
     * @param strUserName
     * @param strPassword
     * @return
     */
    public static int update(SQLiteDatabase db,String strOldUserId, String strUserId, String strUserName, String strPassword){
        String sql = "UPDATE user SET _userId = ?, userName = ?, password = ? WHERE _userId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, strUserId);
        stmt.bindString(2, strUserName);
        stmt.bindString(3, strPassword);
        stmt.bindString(4, strOldUserId);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }

    /**
     * 公式の人かを識別
     * @param db
     * @param id
     * @return
     */
    public static int formulaMarkFindByPK(SQLiteDatabase db, String id){
        String sql = "SELECT formulaFlg FROM user WHERE _userId = '" + id + "' AND formulaFlg IS NOT NULL";
        Cursor cursor = db.rawQuery(sql, null);
        int result = 0;
        if(cursor.moveToFirst()){
            int idxFormulaFlg = cursor.getColumnIndex("formulaFlg");
            String formulaFlg = cursor.getString(idxFormulaFlg);

            result = Integer.parseInt(formulaFlg);
        }
        return result;
    }

    /**
     * アカウント削除するメソッド
     * @param db
     * @param userId
     * @return
     */
    public static void accountDelete(SQLiteDatabase db, String userId){
        String[] sql = {
                "DELETE FROM correctSolutionProblem WHERE userId = ?",
                "DELETE FROM flashcard WHERE userId = ?",
                "DELETE FROM flashcardInterrupt WHERE userId = ?",
                "DELETE FROM flashcardTitle WHERE userId = ?",
                "DELETE FROM grades WHERE userId = ?",
                "DELETE FROM memo WHERE userId = ?",
                "DELETE FROM mistakeProblem WHERE userId = ?",
                "DELETE FROM problems WHERE userId = ?",
                "DELETE FROM problemInterrupt WHERE userId = ?",
                "DELETE FROM titleLists WHERE userId = ?",
                "DELETE FROM user WHERE _userId = ?"
        };
        for(int i=0; i< sql.length; i++){
            SQLiteStatement stmt = db.compileStatement(sql[i]);
            stmt.bindString(1, userId);
            stmt.executeUpdateDelete();
        }
    }
}
package local.hal.st31.android.studyapplication3.Database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

public class MemoDAO {
    /**
     * メモの全てのデータを取得するメソッド
     * @param db
     * @param userId
     * @return
     */
    public static Cursor findAll(SQLiteDatabase db, String userId){
        String sql = "SELECT * FROM memo WHERE userId = '" + userId + "' ORDER BY date DESC";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * 特定のメモを取得するメソッド
     * @param db
     * @param id
     * @return
     */
    public static Memo findIdByPK(SQLiteDatabase db, long id){
        String sql = "SELECT * FROM memo WHERE _id = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);
        Memo result = null;
        if(cursor.moveToFirst()){
            int idxId = cursor.getColumnIndex("_id");
            String flashcardTitleId = cursor.getString(idxId);
            int idxTitle = cursor.getColumnIndex("title");
            String title = cursor.getString(idxTitle);
            int idxNote = cursor.getColumnIndex("note");
            String note = cursor.getString(idxNote);
            int idxDate = cursor.getColumnIndex("date");
            String date = cursor.getString(idxDate);

            result = new Memo();
            result.setId(Long.parseLong(flashcardTitleId));
            result.setTitle(title);
            result.setNote(note);
            result.setDate(date);
        }
        return result;
    }

    /**
     * メモを追加するメソッド
     * @param db
     * @param userId
     * @param title
     * @param note
     * @return
     */
    public static long insert(SQLiteDatabase db, String userId, String title, String note){
        String sql = "INSERT INTO memo (userId, title, note, date) VALUES (?, ?, ?, datetime('now'))";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, userId);
        stmt.bindString(2, title);
        stmt.bindString(3, note);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * メモを更新するメソッド
     * @param db
     * @param id
     * @param title
     * @param note
     * @return
     */
    public static int update(SQLiteDatabase db, long id, String title, String note){
        String sql = "UPDATE memo SET title = ?, note = ?, date = datetime('now') WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, title);
        stmt.bindString(2, note);
        stmt.bindLong(3, id);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }

    /**
     * メモを削除するメソッド
     * @param db
     * @param problemTitleId
     * @return
     */
    public static int delete(SQLiteDatabase db, long problemTitleId){
        String sql = "DELETE FROM memo WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, problemTitleId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    //-----------------------------------------メニュー-------------------------------------
    public static Cursor findSerch(SQLiteDatabase db, String userId, String serch, String sort){
        String where = "";
        String orderBy = "";

        if(!serch.equals("")){
            //検索
            where = " AND title like '%" + serch + "%'";
        }
        if(!sort.equals("")){
            //並び替え
            if(sort.equals("更新順")) {
                orderBy = " ORDER BY date DESC";
            }else if(sort.equals("新しい順")){
                orderBy = " ORDER BY _id DESC";
            }else if(sort.equals("古い順")){
                orderBy = " ORDER BY _id ASC";
            }
        }else{
            orderBy = " ORDER BY date DESC";
        }

        String sql = "SELECT * FROM memo WHERE userId = '" + userId + "'" + where + orderBy;
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }
}

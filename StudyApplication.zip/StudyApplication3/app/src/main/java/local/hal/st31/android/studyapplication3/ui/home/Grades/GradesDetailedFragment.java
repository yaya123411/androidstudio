package local.hal.st31.android.studyapplication3.ui.home.Grades;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.Grades;
import local.hal.st31.android.studyapplication3.Database.GradesDAO;
import local.hal.st31.android.studyapplication3.Database.ProblemDAO;
import local.hal.st31.android.studyapplication3.Database.TitleList;
import local.hal.st31.android.studyapplication3.Database.TitleListDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.home.Memo.MemoTopFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GradesDetailedFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class GradesDetailedFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    View view;

    //フラグメントを呼び出す
    public static GradesDetailedFragment newInstance(){
// Fragemnt01 インスタンス生成
        GradesDetailedFragment GradesDetailedFragment = new GradesDetailedFragment();

        return GradesDetailedFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_grades_detailed,
                container, false);
        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "成績一覧");
        editor.commit();
        setHasOptionsMenu(true);

        return view;
    }

    //メニューが押された場合
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        boolean returnVal = true;
        int itemId = item.getItemId();
        switch (itemId) {
            case R.id.menuReport:
                //レポート
                LayoutInflater inflater = getActivity().getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.dialog_report, null, false);

                //ダイアログのリストを取得
                ListView dialogReportList = dialogView.findViewById(R.id.dialogReportList);
                Cursor cursors = ProblemDAO.findProblemAllReport(db, myPrefs.getLong("titleId", 0));
                String[] from = {"question", "num"};
                int[] to = {R.id.reportTitle, R.id.percent};
                SimpleCursorAdapter adapter = new SimpleCursorAdapter(getActivity(), R.layout.dialog_report_list, cursors, from, to, 0);
                adapter.setViewBinder(new DialogCustomViewBinder());
                dialogReportList.setAdapter(adapter);

                //ダイアログ作成
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setView(dialogView);

                builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });

                //ダイアログ出力
                AlertDialog alertDialog = builder.create();
                alertDialog.setCanceledOnTouchOutside(false);
                alertDialog.show();
                break;
        }
        return returnVal;
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        //部品を取得
        TextView textTitle = view.findViewById(R.id.gradesTitle);
        TextView textMaxScore = view.findViewById(R.id.myMaxScore);
        TextView textMinScore = view.findViewById(R.id.myMinScore);
        TextView textAvgScore = view.findViewById(R.id.myAverageScore);
        TextView textCount = view.findViewById(R.id.titleCount);

        //データベースに接続
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        //メモボタンが押された場合
        FloatingActionButton memo = view.findViewById(R.id.gradesDetailedMemo);
        memo.setOnClickListener((View v) -> {
            migrate(MemoTopFragment.newInstance());
        });

        //戻るボタンが押された場合
        ImageView btnBack = view.findViewById(R.id.gradesDetailedBack);
        btnBack.setOnClickListener((View v) -> {
            editor.putString("menu", "");
            editor.commit();
            back();
        });

        //タイトルを取得
        TitleList title = TitleListDAO.findIdByPK(db, myPrefs.getLong("titleId",0));
        //最大スコア取得
        Grades max = GradesDAO.maxScore(db, myPrefs.getLong("titleId",0));
        //最小スコア取得
        Grades min = GradesDAO.minScore(db, myPrefs.getLong("titleId",0));
        //平均スコア取得
        Grades avg = GradesDAO.avgScore(db, myPrefs.getLong("titleId",0));
        //個数を取得
        Integer count = GradesDAO.GradesCount(db, myPrefs.getLong("titleId",0));
        //出力
        textTitle.setText(title.getTitle());
        textMaxScore.setText(max.getMaxScore()+"点");
        textMinScore.setText(min.getMinScore()+"点");
        textAvgScore.setText(avg.getAvgScore()+"点");
        textCount.setText(count + "件検出");

        Resources res = getResources();
        int chocolate_color = res.getColor(R.color.list);
        //過去問出力
        ListView lvPref = view. findViewById(R.id.gradesList);
        List<String> prefList = new ArrayList<>();
        for(int i=0; i<count; i++){
            prefList.add(i+1 + "回目");
//            if(i % 2 == 0){
//                //idが偶数の場合
//                ((ViewGroup)view.getParent()).setBackgroundColor(chocolate_color);
//            }else{
//                ((ViewGroup)view.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
//            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, prefList);
        lvPref.setAdapter(adapter);
        lvPref.setOnItemClickListener(new ListItemClickListener());
    }

    /**
     * リストが選択された時の処理が記述されたメンバクラス。
     * 第2画面へ処理を移動する
     */
    private class ListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            //保存領域に接続
            SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = myPrefs.edit();

            editor.putLong("gradesNo", position+1);
            editor.commit();

            migrate(GradesMoreDetailedFragment.newInstance(position));
        }
    }

    /**
     * レポートのリストビューのカスタムビューバインダークラス。
     */
    private class DialogCustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch (view.getId()) {
                case R.id.reportTitle:
                    TextView reportTitle = (TextView)view;
                    reportTitle.setText(cursor.getString(columnIndex));

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)reportTitle.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)reportTitle.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }
                    return true;
                case R.id.percent:
                    //保存領域に接続
                    SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                    _helper = new DatabaseHelper(getActivity());
                    SQLiteDatabase db = _helper.getWritableDatabase();
                    //個数を取得
                    Integer count = GradesDAO.GradesCount(db, myPrefs.getLong("titleId",0));
                    TextView percent = (TextView)view;
                    double doublePercent = Math.floor(Double.parseDouble(cursor.getString(columnIndex))/count*100);
                    percent.setText(String.valueOf(doublePercent).substring(0, String.valueOf(doublePercent).length()-2) + "%");
                    return true;
            }
            return false;
        }
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
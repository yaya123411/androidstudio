package local.hal.st31.android.studyapplication3.Database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.text.ParseException;

public class FlashcardInterruptDAO {
    //単語帳の中断した場合のDAO
    /**
     * 特定の単語の中断データを取得するメソッド
     * @param db
     * @param titleId
     * @return
     */
    public static FlashcardInterrupt findIdByPK(SQLiteDatabase db, long titleId) throws ParseException {
        //id=_id
        String sql = "SELECT * FROM flashcardInterrupt WHERE flashcardTitleId = '" + titleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        FlashcardInterrupt result = null;
        if (cursor.moveToFirst()) {
            int idxPage = cursor.getColumnIndex("page");
            String page = cursor.getString(idxPage);
            int idxSettingRememberFlg = cursor.getColumnIndex("settingRememberFlg");
            String settingRememberFlg = cursor.getString(idxSettingRememberFlg);
            int idxUpdateTime = cursor.getColumnIndex("updateTime");
            String updateTime = cursor.getString(idxUpdateTime);

            result = new FlashcardInterrupt();
            result.setPage(page);
            result.setSettingRememberFlg(Integer.parseInt(settingRememberFlg));
            result.setUpdateTime(updateTime);
        }
        return result;
    }

    /**
     * 単語を追加するメソッド
     * @param db
     * @param userId
     * @param flashcardTitleId
     * @param page
     * @return
     */
    public static long insert(SQLiteDatabase db, String userId, long flashcardTitleId, String downloadId, Integer page, Integer settingRememberFlg, String date) {
        String sql = "INSERT INTO flashcardInterrupt (userId, flashcardTitleId, downloadId, page, settingRememberFlg, updateTime) VALUES (?, ?, ?, ?, ?, ?)";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, userId);
        stmt.bindLong(2, flashcardTitleId);
        if(downloadId != null){
            //ダウンロードした問題ならば
            stmt.bindLong(3, Long.parseLong(downloadId));
        }else{
            stmt.bindLong(3, Long.parseLong(String.valueOf(0)));
        }
        stmt.bindString(4, String.valueOf(page));
        stmt.bindLong(5, settingRememberFlg);
        stmt.bindString(6, date);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * 単語を更新するメソッド
     * @param db
     * @param flashcardTitleId
     * @param page
     * @return
     */
    public static int update(SQLiteDatabase db, long flashcardTitleId, long page, String date) {
        String sql = "UPDATE flashcardInterrupt SET page = ?, updateTime = ? WHERE flashcardTitleId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, String.valueOf(page));
        stmt.bindString(2, date);
        stmt.bindLong(3, flashcardTitleId);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }

    /**
     * 単語を削除するメソッド
     * @param db
     * @param problemId
     * @return
     */
    public static int delete(SQLiteDatabase db, long problemId) {
        String sql = "DELETE FROM flashcardInterrupt WHERE flashcardTitleId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, problemId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    //------------------------------------ダウンロード------------------------------

    /**
     * ダウンロードされた単語帳が中断されたかどうか
     * @param db
     * @param flashcardTitleId
     * @return 中断された=downloadId、自作で作った単語帳が中断された=null
     */
    public static String findDownloadId(SQLiteDatabase db, long flashcardTitleId) {
        String sql = "SELECT downloadId FROM flashcardTitle WHERE _id = '" + flashcardTitleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        String downloadId = null;
        if (cursor.moveToFirst()) {
            downloadId = cursor.getString(0);
        }
        return downloadId;
    }

    /**
     * ダウンロード済みの中断履歴があれば削除する
     * @param db
     * @param titleId
     * @return
     */
    public static int deleteByDownloadId(SQLiteDatabase db, long titleId) {
        String sql = "DELETE FROM flashcardInterrupt WHERE flashcardTitleId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, titleId);
        int result = stmt.executeUpdateDelete();
        return result;
    }
}

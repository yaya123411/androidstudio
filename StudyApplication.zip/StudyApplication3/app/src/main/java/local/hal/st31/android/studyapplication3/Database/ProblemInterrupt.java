package local.hal.st31.android.studyapplication3.Database;

public class ProblemInterrupt {
    /**
     * id
     */
    private long _id;
    /**
     * 回答データ
     */
    private String _json;
    /**
     * 中断したページ
     */
    private String _page;
    /**
     * 中断した時間
     */
    private Double _time;
    /**
     * 更新日
     */
    private String _updateTime;

    //以下アクセサメソッド

    public long getId(){
        return _id;
    }
    public void setId(long id){
        _id = id;
    }
    public String getJson(){
        return _json;
    }
    public void setJson(String json){
        _json = json;
    }
    public String getPage(){
        return _page;
    }
    public void setPage(String page){
        _page = page;
    }
    public Double getTime(){
        return _time;
    }
    public void setTime(Double time){
        _time = time;
    }
    public String getUpdateTime(){
        return _updateTime;
    }
    public void setUpdateTime(String updateTime){
        _updateTime = updateTime;
    }
}

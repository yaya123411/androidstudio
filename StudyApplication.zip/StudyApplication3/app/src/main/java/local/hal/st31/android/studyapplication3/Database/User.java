package local.hal.st31.android.studyapplication3.Database;

public class User {
    /**
     * ユーザー名
     */
    private String _userId;
    private String _userName;
    private String _password;

    //以下アクセサメソッド

    public String getUserId(){
        return _userId;
    }
    public void setUserId(String userId){
        _userId = userId;
    }
    public String getUserName(){
        return _userName;
    }
    public void setUserName(String userName){
        _userName = userName;
    }
    public String getPassword(){
        return _password;
    }
    public void setPassword(String password){
        _password = password;
    }
}
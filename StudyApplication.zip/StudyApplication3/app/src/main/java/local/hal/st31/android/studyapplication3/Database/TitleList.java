package local.hal.st31.android.studyapplication3.Database;

public class TitleList {
    /**
     * id
     */
    private long _id;
    /**
     * タイトル
     */
    private String _title;
    /**
     * 時間
     */
    private String _time;
    /**
     * アップロードしたかを表すフラグ
     */
    private int _uploadFlg;
    /**
     * 公式かを識別
     */
    private int _formulaFlg;
    /**
     * アップロード時のメッセージ
     */
    private String _msg;
    /**
     * 更新日
     */
    private String _updateTime;

    //以下アクセサメソッド

    public long getId(){
        return _id;
    }
    public void setId(long id){
        _id = id;
    }
    public String getTitle(){
        return _title;
    }
    public void setTitle(String title){
        _title = title;
    }
    public String getTime(){
        return _time;
    }
    public void setTime(String time){
        _time = time;
    }
    public int getUploadFlg(){
        return _uploadFlg;
    }
    public void setUploadFlg(int uploadFlg){
        _uploadFlg = uploadFlg;
    }
    public int getFormulaFlg(){
        return _formulaFlg;
    }
    public void setFormulaFlg(int formulaFlg){
        _formulaFlg = formulaFlg;
    }
    public String getMsg(){
        return _msg;
    }
    public void setMsg(String msg){
        _msg = msg;
    }
    public String getUpdateTime(){
        return _updateTime;
    }
    public void setUpdateTime(String updateTime){
        _updateTime = updateTime;
    }
}

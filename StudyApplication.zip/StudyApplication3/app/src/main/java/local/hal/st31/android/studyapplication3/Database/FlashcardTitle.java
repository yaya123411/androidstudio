package local.hal.st31.android.studyapplication3.Database;

public class FlashcardTitle {
    /**
     * id
     */
    private long _id;
    /**
     * タイトル
     */
    private String _title;
    /**
     * アップロードしたかを表すフラグ
     */
    private int _uploadFlg;
    /**
     * 公式かの識別
     */
    private int _formulaFlg;
    /**
     * アップロード時のメッセージ
     */
    private String _msg;

    //以下アクセサメソッド

    public long getId(){
        return _id;
    }
    public void setId(long id){
        _id = id;
    }
    public String getTitle(){
        return _title;
    }
    public void setTitle(String title){
        _title = title;
    }
    public int getUploadFlg(){
        return _uploadFlg;
    }
    public void setUploadFlg(int uploadFlg){
        _uploadFlg = uploadFlg;
    }
    public int getFormulaFlg(){
        return _formulaFlg;
    }
    public void setFormulaFlg(int formulaFlg){
        _formulaFlg = formulaFlg;
    }
    public String getMsg(){
        return _msg;
    }
    public void setMsg(String msg){
        _msg = msg;
    }
}

package local.hal.st31.android.studyapplication3.ui.account;

import android.app.ActionBar;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.SampleDate;
import local.hal.st31.android.studyapplication3.Database.User;
import local.hal.st31.android.studyapplication3.Database.UserDAO;
import local.hal.st31.android.studyapplication3.MainActivity;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.home.HomeFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link LoginFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class LoginFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;

    public static LoginFragment newInstance(){
// Fragemnt01 インスタンス生成
        LoginFragment LoginFragment = new LoginFragment();

        return LoginFragment;
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "ログイン");
        editor.commit();
        setHasOptionsMenu(true);

        return inflater.inflate(R.layout.fragment_login,
                container, false);
    }

    @Override
    public void onResume() {
        super.onResume();

        //保存領域に接続
        SharedPreferences myPrefs = this.getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "ログイン");
        editor.commit();
        setHasOptionsMenu(true);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();
//        SampleDate.insert(db);

        Button btnLogin = view.findViewById(R.id.btnLogin);
        TextView btnNewRegistering = view.findViewById(R.id.btnNewRegistering);
        //ログインボタンが押された場合
        btnLogin.setOnClickListener( v -> {

            EditText etUserId = view.findViewById(R.id.etUserId);
            String strUserId = etUserId.getText().toString();
            EditText etPassword = view.findViewById(R.id.etPassword);
            String strPassword = etPassword.getText().toString();
            User result = UserDAO.findByPK(db, strUserId, strPassword);
            if(result != null){
                //ユーザーが存在した場合
                SharedPreferences myPrefs = this.getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = myPrefs.edit();

                editor.putString("userId", result.getUserId());
                editor.putString("memu", "");
                editor.commit();
                back();
                Toast.makeText(this.getActivity(), R.string.textLoginMsg, Toast.LENGTH_SHORT).show();
            }else{
                //ユーザーID又はパスワードが一致しなかった場合
                Toast.makeText(this.getActivity(), R.string.textErrMsg, Toast.LENGTH_SHORT).show();
            }
        });

        //新規登録ボタンが押された場合
        btnNewRegistering.setOnClickListener( v -> {
            back();
            migrate(NewRegisteringFragment.newInstance());
        });
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
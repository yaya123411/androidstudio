package local.hal.st31.android.studyapplication3.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * 就職課題
 *
 * データベースのヘルパークラス。
 *
 * @author yaya2
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    /**
     * データベースフォイル名の定数フィールド。
     */
    private static final String DATABASE_NAME = "StudyApplication.db";
    /**
     * バージョン情報の定義フィールド
     */
    private static final int DATABASE_VERSION = 1;

    /**
     * コンストラクタ。
     *
     * @param context コンテキスト
     */
    public DatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        //ユーザー情報
        StringBuffer sb = new StringBuffer();
        sb.append("CREATE TABLE user (");
        sb.append("_userId TEXT NOT NULL,");
        sb.append("userName TEXT NOT NULL,");
        sb.append("password TEXT NOT NULL,");
        //管理者に任命された人は1、そうでなければNULL
        sb.append("intendantFlg TEXT,");
        //公式に任命された人は1、そうでなければNULL
        sb.append("formulaFlg TEXT");
        sb.append(");");
        String sql = sb.toString();

        db.execSQL(sql);

        //---------------------------問題作成&問題出題----------------------------------

        //タイトル情報
        StringBuffer sbProblemTitle = new StringBuffer();
        sbProblemTitle.append("CREATE TABLE titleLists (");
        sbProblemTitle.append("_id INTEGER PRIMARY KEY AUTOINCREMENT,");
        sbProblemTitle.append("userId TEXT NOT NULL,");
        //ダウンロードID(ダウンロードしていなければnull)
        sbProblemTitle.append("downloadId TEXT NOT NULL,");
        //タイトル
        sbProblemTitle.append("title TEXT NOT NULL,");
        //時間
        sbProblemTitle.append("time TEXT NOT NULL,");
        //アップロードしたかを表すフラグ
        sbProblemTitle.append("uploadFlg TEXT NOT NULL,");
        //公式から出ている単語帳だった場合1、そうでない場合null
        sbProblemTitle.append("formulaFlg TEXT,");
        //アップロード時のメッセージ
        sbProblemTitle.append("msg TEXT,");
        //更新日
        sbProblemTitle.append("updateTime TEXT NOT NULL");
        sbProblemTitle.append(");");
        String sbProblemTitleSql = sbProblemTitle.toString();

        db.execSQL(sbProblemTitleSql);

        //問題情報
        StringBuffer sbProblem = new StringBuffer();
        sbProblem.append("CREATE TABLE problems (");
        sbProblem.append("_id INTEGER PRIMARY KEY AUTOINCREMENT,");
        sbProblem.append("userId TEXT NOT NULL,");
        sbProblem.append("titleId TEXT NOT NULL,");
        //問題
        sbProblem.append("question TEXT NOT NULL,");
        //選択問題=on,記述式-off
        sbProblem.append("choice TEXT NOT NULL,");
        //選択式の回答
        sbProblem.append("choiceA TEXT,");
        sbProblem.append("choiceB TEXT,");
        sbProblem.append("choiceC TEXT,");
        sbProblem.append("choiceD TEXT,");
        sbProblem.append("choiceE TEXT,");
        sbProblem.append("choiceF TEXT,");
        sbProblem.append("choiceG TEXT,");
        //選択式のみの回答
        sbProblem.append("reply TEXT,");
        //解説
        sbProblem.append("explanation TEXT,");
        //更新日
        sbProblem.append("updateTime TEXT NOT NULL");
        sbProblem.append(");");
        String sbProblemSql = sbProblem.toString();

        db.execSQL(sbProblemSql);

        //間違えた問題
        StringBuffer sbMistakeProblem = new StringBuffer();
        sbMistakeProblem.append("CREATE TABLE mistakeProblem (");
        sbMistakeProblem.append("_id INTEGER PRIMARY KEY AUTOINCREMENT,");
        sbMistakeProblem.append("userId TEXT NOT NULL,");
        sbMistakeProblem.append("titleId TEXT NOT NULL,");
        sbMistakeProblem.append("problemId TEXT NOT NULL,");
        //ダウンロードID(ダウンロードしていなければnull)
        sbMistakeProblem.append("downloadId TEXT NOT NULL,");
        sbMistakeProblem.append("count TEXT NOT NULL,");
        //答え
        sbMistakeProblem.append("reply TEXT NOT NULL,");
        //自分の回答
        sbMistakeProblem.append("myReply TEXT NOT NULL,");
        sbMistakeProblem.append("notAnswereFlg TEXT NOT NULL");
        sbMistakeProblem.append(");");
        String sbMistakeProblemSql = sbMistakeProblem.toString();

        db.execSQL(sbMistakeProblemSql);

        //正解した問題
        StringBuffer sbCorrectSolutionProblem = new StringBuffer();
        sbCorrectSolutionProblem.append("CREATE TABLE correctSolutionProblem (");
        sbCorrectSolutionProblem.append("_id INTEGER PRIMARY KEY AUTOINCREMENT,");
        sbCorrectSolutionProblem.append("userId TEXT NOT NULL,");
        sbCorrectSolutionProblem.append("titleId TEXT NOT NULL,");
        sbCorrectSolutionProblem.append("problemId TEXT NOT NULL,");
        //ダウンロードID(ダウンロードしていなければnull)
        sbCorrectSolutionProblem.append("downloadId TEXT NOT NULL,");
        sbCorrectSolutionProblem.append("count TEXT NOT NULL,");
        //答え
        sbCorrectSolutionProblem.append("reply TEXT NOT NULL");
        sbCorrectSolutionProblem.append(");");
        String sbCorrectSolutionProblemSql = sbCorrectSolutionProblem.toString();

        db.execSQL(sbCorrectSolutionProblemSql);

        //問題出題で途中で退出した記録
        StringBuffer sbProblemInterrupt = new StringBuffer();
        sbProblemInterrupt.append("CREATE TABLE problemInterrupt (");
        sbProblemInterrupt.append("_id INTEGER PRIMARY KEY AUTOINCREMENT,");
        sbProblemInterrupt.append("userId TEXT NOT NULL,");
        sbProblemInterrupt.append("ProblemTitleId TEXT NOT NULL,");
        //ダウンロードID(ダウンロードしていなければnull)
        sbProblemInterrupt.append("downloadId TEXT NOT NULL,");
        //回答したjsonファイル
        sbProblemInterrupt.append("json TEXT NOT NULL,");
        //中断したページ
        sbProblemInterrupt.append("page TEXT NOT NULL,");
        //中断した時の制限時間
        sbProblemInterrupt.append("time TEXT NOT NULL,");
        //更新日
        sbProblemInterrupt.append("updateTime TEXT NOT NULL");
        sbProblemInterrupt.append(");");
        String sbProblemInterruptSql = sbProblemInterrupt.toString();

        db.execSQL(sbProblemInterruptSql);

        //-------------------------------成績---------------------------------------

        //成績
        StringBuffer sbGrades = new StringBuffer();
        sbGrades.append("CREATE TABLE grades (");
        sbGrades.append("_id INTEGER PRIMARY KEY AUTOINCREMENT,");
        sbGrades.append("userId TEXT NOT NULL,");
        sbGrades.append("titleId TEXT NOT NULL,");
        //ダウンロードID(ダウンロードしていなければnull)
        sbGrades.append("downloadId TEXT NOT NULL,");
        //同じ問題を解いた回数
        sbGrades.append("count TEXT NOT NULL,");
        //正解率
        sbGrades.append("correctSolutionRate TEXT NOT NULL,");
        //正解数
        sbGrades.append("correctSolutionNum TEXT NOT NULL,");
        //回答した制限時間
        sbGrades.append("time TEXT NOT NULL,");
        //回答した日付
        sbGrades.append("data TEXT NOT NULL");
        sbGrades.append(");");
        String sbGradesSql = sbGrades.toString();

        db.execSQL(sbGradesSql);

        //-------------------------------単語帳-----------------------------------------

        //単語帳のタイトル
        StringBuffer sbFlashcardTitle = new StringBuffer();
        sbFlashcardTitle.append("CREATE TABLE flashcardTitle (");
        sbFlashcardTitle.append("_id INTEGER PRIMARY KEY AUTOINCREMENT,");
        sbFlashcardTitle.append("userId TEXT NOT NULL,");
        //ダウンロードID(ダウンロードしていなければnull)
        sbFlashcardTitle.append("downloadId TEXT NOT NULL,");
        //タイトル
        sbFlashcardTitle.append("title TEXT NOT NULL,");
        //公式から出ている単語帳だった場合1、そうでない場合null
        sbFlashcardTitle.append("formulaFlg TEXT,");
        //アップロード済みかどうか
        sbFlashcardTitle.append("uploadFlg TEXT,");
        //アップロード時のメッセージ
        sbFlashcardTitle.append("msg TEXT,");
        //更新日
        sbFlashcardTitle.append("updateTime TEXT NOT NULL");
        sbFlashcardTitle.append(");");
        String sbFlashcardTitleSql = sbFlashcardTitle.toString();

        db.execSQL(sbFlashcardTitleSql);

        //単語帳の単語
        StringBuffer sbFlashcard = new StringBuffer();
        sbFlashcard.append("CREATE TABLE flashcard (");
        sbFlashcard.append("_id INTEGER PRIMARY KEY AUTOINCREMENT,");
        sbFlashcard.append("userId TEXT NOT NULL,");
        sbFlashcard.append("flashcardTitleId TEXT NOT NULL,");
        //表の内容
        sbFlashcard.append("front TEXT NOT NULL,");
        //裏の内容
        sbFlashcard.append("back TEXT NOT NULL,");
        //覚えたにチェックが付けられた場合=1、その他=0
        sbFlashcard.append("remember TEXT NOT NULL,");
        //更新日
        sbFlashcard.append("updateTime TEXT NOT NULL");
        sbFlashcard.append(");");
        String sbFlashcardSql = sbFlashcard.toString();

        db.execSQL(sbFlashcardSql);

        //単語帳で途中で退出した記録
        StringBuffer sbFlashcardInterrupt = new StringBuffer();
        sbFlashcardInterrupt.append("CREATE TABLE flashcardInterrupt (");
        sbFlashcardInterrupt.append("_id INTEGER PRIMARY KEY AUTOINCREMENT,");
        sbFlashcardInterrupt.append("userId TEXT NOT NULL,");
        sbFlashcardInterrupt.append("flashcardTitleId TEXT NOT NULL,");
        //ダウンロードID(ダウンロードしていなければnull)
        sbFlashcardInterrupt.append("downloadId TEXT NOT NULL,");
        //中断したページ
        sbFlashcardInterrupt.append("page TEXT NOT NULL,");
        //設定情報(覚えたやつを省くか)
        sbFlashcardInterrupt.append("settingRememberFlg TEXT NOT NULL,");
        //更新日
        sbFlashcardInterrupt.append("updateTime TEXT NOT NULL");
        sbFlashcardInterrupt.append(");");
        String sbFlashcardInterruptSql = sbFlashcardInterrupt.toString();

        db.execSQL(sbFlashcardInterruptSql);

        //-----------------------------メモ帳-----------------------------------
        StringBuffer sbMemo = new StringBuffer();
        sbMemo.append("CREATE TABLE memo (");
        sbMemo.append("_id INTEGER PRIMARY KEY AUTOINCREMENT,");
        //ユーザーID
        sbMemo.append("userId TEXT NOT NULL,");
        //タイトル
        sbMemo.append("title TEXT NOT NULL,");
        //内容
        sbMemo.append("note TEXT NOT NULL,");
        //更新日
        sbMemo.append("date TEXT NOT NULL");
        sbMemo.append(");");
        String sbMemoSql = sbMemo.toString();

        db.execSQL(sbMemoSql);

        //----------------------------キャンバス--------------------------------------
        StringBuffer sbCanvas = new StringBuffer();
        sbCanvas.append("CREATE TABLE canvas (");
        sbCanvas.append("_id INTEGER PRIMARY KEY AUTOINCREMENT,");
        //メモID
        sbCanvas.append("memoId TEXT NOT NULL,");
        //始まりのX座標
        sbCanvas.append("startGetX TEXT NOT NULL,");
        //始まりのY座標
        sbCanvas.append("startGetY TEXT NOT NULL,");
        //終わりのX座標
        sbCanvas.append("finishGetX TEXT NOT NULL,");
        //終わりのY座標
        sbCanvas.append("finishGetY TEXT NOT NULL,");
        //色の指定
        sbCanvas.append("color TEXT NOT NULL");
        sbCanvas.append(");");
        String sbCanvasSql = sbCanvas.toString();

        db.execSQL(sbCanvasSql);

        StringBuffer sbCanvasLine = new StringBuffer();
        sbCanvasLine.append("CREATE TABLE canvasLine (");
        sbCanvasLine.append("_id INTEGER PRIMARY KEY AUTOINCREMENT,");
        //キャンバスID
        sbCanvasLine.append("canvasId TEXT NOT NULL,");
        //メモID
        sbCanvasLine.append("memoId TEXT NOT NULL,");
        //X座標
        sbCanvasLine.append("getX TEXT NOT NULL,");
        //Y座標
        sbCanvasLine.append("getY TEXT NOT NULL");
        sbCanvasLine.append(");");
        String sbCanvasLineSql = sbCanvasLine.toString();

        db.execSQL(sbCanvasLineSql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
    }
}
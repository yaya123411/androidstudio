package local.hal.st31.android.studyapplication3.Database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TitleListDAO {
    /**
     * タイトル情報の全てのデータを取得するメソッド
     * @param db
     * @return
     */
    public static Cursor findAll(SQLiteDatabase db, String userId){
        String sql = "SELECT * FROM titleLists WHERE userId = '" + userId + "' AND downloadId = 0 ORDER BY updateTime DESC";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * アップロードした問題のデータを取得するメソッド
     * @param db
     * @param userId
     * @return
     */
    public static Cursor findUpload(SQLiteDatabase db, String userId){
        String sql = "SELECT * FROM titleLists WHERE userId = '" + userId + "' AND uploadFlg = 1 ORDER BY updateTime DESC";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * タイトルがあるかをチェックするメソッド
     * @param db
     * @param id
     * @return
     */
    public static TitleList findIdByPK(SQLiteDatabase db, long id){
        //id=_id
        String sql = "SELECT * FROM titleLists WHERE _id = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);
        TitleList result = null;
        if(cursor.moveToFirst()){
            int idxTitle = cursor.getColumnIndex("title");
            String title = cursor.getString(idxTitle);
            int idxTime = cursor.getColumnIndex("time");
            String time = cursor.getString(idxTime);
            int idxFormula = cursor.getColumnIndex("formulaFlg");
            String formula = cursor.getString(idxFormula);
            int idxMsg = cursor.getColumnIndex("msg");
            String msg = cursor.getString(idxMsg);
            int idxUploadFlg = cursor.getColumnIndex("uploadFlg");
            String uploadFlg = cursor.getString(idxUploadFlg);

            result = new TitleList();
            result.setId(id);
            result.setTitle(title);
            result.setTime(time);
            result.setFormulaFlg(Integer.parseInt(formula));
            result.setMsg(msg);
            result.setUploadFlg(Integer.parseInt(uploadFlg));
        }
        return result;
    }

    /**
     * タイトル情報を追加するメソッド
     * @param db
     * @param userId
     * @param title
     * @param time
     * @return
     */
    public static long insert(SQLiteDatabase db, String userId, String title, Integer time, int formulaFlg){
        String sql = "INSERT INTO titleLists (userId, downloadId, title, time, uploadFlg, formulaFlg, updateTime) VALUES (?, 0, ?, ?, 0, ?, datetime('now'))";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, userId);
        stmt.bindString(2, title);
        stmt.bindString(3, Integer.toString(time));
        stmt.bindLong(4, formulaFlg);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * タイトル情報を更新するメソッド
     * @param db
     * @param problemTitleId
     * @param title
     * @param time
     * @return
     */
    public static int update(SQLiteDatabase db, long problemTitleId, String title, Integer time){
        String sql = "UPDATE titleLists SET title = ?, time = ?, updateTime = datetime('now') WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, title);
        stmt.bindString(2, Integer.toString(time));
        stmt.bindLong(3, problemTitleId);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }

    /**
     * アップロードした場合、アップロードフラグを1にする
     * @param db
     * @param titleId
     * @return
     */
    public static int updateUpload(SQLiteDatabase db, long titleId){
        String sql = "UPDATE titleLists SET uploadFlg = 1 WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, titleId);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }

    /**
     * タイトル情報を削除するメソッド
     * @param db
     * @param id
     * @return
     */
    public static int delete(SQLiteDatabase db, long id){
        String sql = "DELETE FROM titleLists WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, id);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    /**
     * 特定のタイトル情報を取得するメソッド
     * @param db
     * @param id
     * @return
     */
    public static TitleList updateFindUploadFlg(SQLiteDatabase db, long id){
        String sql = "SELECT * FROM titleLists WHERE _id = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);
        TitleList result = null;
        if(cursor.moveToFirst()){
            int idxUploadFlg = cursor.getColumnIndex("uploadFlg");
            String uploadFlg = cursor.getString(idxUploadFlg);

            result = new TitleList();
            result.setUploadFlg(Integer.parseInt(uploadFlg));
        }
        return result;
    }

    //-----------------------------------------ダウンロード-------------------------------------
    //ダウンロードした問題を問題タイトルテーブルに追加する
    public static long shareProblemTitleInsert(SQLiteDatabase db, String userId, long downloadId, String title, int formulaFlg, int time){
        String sql = "INSERT INTO titleLists (userId, downloadId, title, time, uploadFlg, formulaFlg, updateTime) VALUES (?, ?, ?, ?, 0, ?, datetime('now'))";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, userId);
        stmt.bindLong(2, downloadId);
        stmt.bindString(3, title);
        stmt.bindString(4, String.valueOf(time));
        stmt.bindLong(5, formulaFlg);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * タイトル情報の全てのデータを取得するメソッド
     * @param db
     * @return
     */
    public static Cursor allDownload(SQLiteDatabase db, String userId, int formula){
        String sql = "SELECT * FROM titleLists WHERE userId = '" + userId + "' AND downloadId <> 0 AND formulaFlg = " + formula + " ORDER BY updateTime DESC";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * ダウンロード済みの問題タイトルを削除する
     * @param db
     * @param downloadId
     * @return
     */
    public static int deleteByDownloadId(SQLiteDatabase db, long downloadId){
        String sql = "DELETE FROM titleLists WHERE downloadId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, downloadId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    /**
     * 公式かを識別する
     * @param db
     * @param problemTitleId
     * @return
     */
    public static int formulaMarkFindByTitldId(SQLiteDatabase db, String problemTitleId){
        String sql = "SELECT formulaFlg FROM titleLists WHERE _id = '" + problemTitleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        int result = 0;
        if(cursor.moveToFirst()){
            int idxFormulaFlg = cursor.getColumnIndex("formulaFlg");
            String formulaFlg = cursor.getString(idxFormulaFlg);

            result = Integer.parseInt(formulaFlg);
        }
        return result;
    }

    /**
     * 既にダウンロードしてあるかどうか
     * @param db
     * @param downloadId
     * @return
     */
    public static TitleList downloadDone(SQLiteDatabase db, long downloadId){
        String sql = "SELECT _id FROM titleLists WHERE downloadId = '" + downloadId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        TitleList result = null;
        if(cursor.moveToFirst()){
            int idxId = cursor.getColumnIndex("_id");
            String id = cursor.getString(idxId);

            result = new TitleList();
            result.setId(Long.parseLong(id));
        }
        return result;
    }

    //------------------------------------------メニュー---------------------------------------

    /**
     * 並び替え、抽出条件を指定できるメソッド
     * @param db
     * @param userId
     * @param serch
     * @param sort
     * @return
     */
    public static Cursor findSeach(SQLiteDatabase db, String userId, String serch, String take, String sort){
        String sql = "";
        String where = "";
        String orderBy = "";
        if(!serch.equals("")){
            //検索ボタンが押された場合
            where = " AND title like '%" + serch + "%'";
        }
        if(!take.equals("")){
            //抽出条件
            if(take.equals("アップロードされてる")){
                where += " AND uploadFlg = 1";
            }else if(take.equals("アップロードされていない")){
                where += " AND uploadFlg = 0";
            }
        }
        if(!sort.equals("")){
            //並び替え
            if(sort.equals("更新順")) {
                orderBy = " ORDER BY updateTime DESC";
            }else if(sort.equals("新しい順")){
                orderBy = " ORDER BY _id DESC";
            }else if(sort.equals("古い順")){
                orderBy = " ORDER BY _id ASC";
            }else if(sort.equals("制限時間が短い順")){
                orderBy = " ORDER BY CAST(time AS SIGNED) ASC";
            }else if(sort.equals("制限時間が長い順")){
                orderBy = " ORDER BY CAST(time AS SIGNED) DESC";
            }
        }else{
            orderBy = " ORDER BY updateTime DESC";
        }

        sql = "SELECT * FROM titleLists WHERE userId = '" + userId + "' AND downloadId = 0" + where + orderBy;

        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    //----------------------------------------アップロード--------------------------------
    /**
     * 自分がアップロードした問題をダウンロードテーブルから削除する
     * @param db
     * @param id
     * @return
     */
    public static int uploadUpdate(SQLiteDatabase db, long id){
        String sql = "UPDATE titleLists SET uploadFlg = 0 WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, id);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }
}


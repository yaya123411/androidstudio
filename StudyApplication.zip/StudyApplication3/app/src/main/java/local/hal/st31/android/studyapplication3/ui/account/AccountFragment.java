package local.hal.st31.android.studyapplication3.ui.account;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.UiThread;
import androidx.appcompat.app.AlertDialog;
import androidx.core.os.HandlerCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.FlashcardDAO;
import local.hal.st31.android.studyapplication3.Database.FlashcardTitleDAO;
import local.hal.st31.android.studyapplication3.Database.Grades;
import local.hal.st31.android.studyapplication3.Database.GradesDAO;
import local.hal.st31.android.studyapplication3.Database.ProblemDAO;
import local.hal.st31.android.studyapplication3.Database.TitleListDAO;
import local.hal.st31.android.studyapplication3.Database.User;
import local.hal.st31.android.studyapplication3.Database.UserDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.download.DownloadFragment;
import local.hal.st31.android.studyapplication3.ui.home.Flashcard.FlashcardTopFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemMake.ProblemMakeFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemQuestion.ProblemEndFragment;
import local.hal.st31.android.studyapplication3.ui.share.ShareFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AccountFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AccountFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    View view;
    private int changeFlg = 0;
    private AlertDialog.Builder builder;
    /**
     * ログに記載するタグ用の文字列。
     */
    protected static final String DEBUG_TAG = "Post2DB";
    /**
     * post先のURL。
     */
    private static final String FLASHCARD_URL = "http://yaya8976.php.xdomain.jp/android/studyApplication/flashcard.php";
    private static final String PROBLEM_URL = "http://yaya8976.php.xdomain.jp/android/studyApplication/problem.php";

    public static AccountFragment newInstance(){
// Fragemnt01 インスタンス生成
        AccountFragment AccountFragment = new AccountFragment();

        return AccountFragment;
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "アカウント");
        editor.commit();
        setHasOptionsMenu(true);

        return inflater.inflate(R.layout.fragment_account,
                container, false);
    }

    //メニューが押された場合
    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        _helper = new DatabaseHelper(this.getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        boolean returnVal = true;
        int itemId = item.getItemId();
        switch(itemId){
            case R.id.menu_logout:
                //ログアウトが押された場合
                //ダイアログ作成
                builder = new AlertDialog.Builder(getActivity());
                TextView titleView = new TextView(getActivity());
                titleView.setText(R.string.dialog_logout_title);
                titleView.setGravity(Gravity.CENTER);
                titleView.setTextSize(24);
                titleView.setPadding(20, 20, 20, 20);
                builder.setCustomTitle(titleView);

                builder.setPositiveButton(R.string.logaut, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //ログアウトボタンが押された場合
                        editor.putString("userId", null);
                        editor.commit();
                        migrate(LoginFragment.newInstance());
                        Toast.makeText(getActivity(), R.string.logout_msg, Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //キャンセルボタンが押された場合
                    }
                });

                //ダイアログ出力
                AlertDialog alertDialog = builder.create();
                alertDialog.setCancelable(false);
                alertDialog.setCanceledOnTouchOutside(false);
                alertDialog.show();
                break;
            case R.id.menu_account_delete:
                //アカウント消去が押された場合
                LayoutInflater inflater = getActivity().getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.dialog_account_delete_check, null, false);
                CheckBox agreeCheck = dialogView.findViewById(R.id.agreeCheck);
                TextView accountDeleteButton = dialogView.findViewById(R.id.accountDeleteButton);
                //デフォルト
                accountDeleteButton.setVisibility(View.INVISIBLE);

                //ダイアログ作成
                builder = new AlertDialog.Builder(getActivity());
                builder.setView(dialogView);

                //チェックボックスが押された場合
                agreeCheck.setOnClickListener(parts -> {
                    if (agreeCheck.isChecked()) {
                        //チェックボックスにチェックが付けられた場合
                        accountDeleteButton.setVisibility(View.VISIBLE);
                    }else{
                        accountDeleteButton.setVisibility(View.INVISIBLE);
                    }
                });

                builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //キャンセルボタンが押された場合
                    }
                });

                //ダイアログ出力
                AlertDialog dialog = builder.show();

                accountDeleteButton.setOnClickListener((View v) -> {
                    //アカウント削除処理
                    UserDAO.accountDelete(db, myPrefs.getString("userId",null));
                    editor.putString("userId", null);
                    editor.commit();
                    migrate(LoginFragment.newInstance());
                    dialog.dismiss();
                    Toast.makeText(getActivity(), R.string.delete_msg, Toast.LENGTH_SHORT).show();
                });

                break;
        }
        return returnVal;
    }

    @Override
    public void onResume() {
        super.onResume();

        //データベース接続
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        String strUserId = myPrefs.getString("userId", null);

        //ユーザー情報を格納する
        User result = UserDAO.findUserIdByPK(db, strUserId);

        if(result != null) {
            //ユーザーが存在した場合
            TextView etUserId = view.findViewById(R.id.etUserId);
            etUserId.setText(result.getUserId());
            TextView etUserName = view.findViewById(R.id.etUserName);
            etUserName.setText(result.getUserName());
            String strPassword = "";
            TextView etPassword = view.findViewById(R.id.etPassword);
            for(int i=0;i<result.getPassword().length();i++){
                strPassword += "●";
            }
            etPassword.setText(strPassword);
        }

        if(myPrefs.getInt("intFlg",0) != 0){
            //無事編集された場合
            Toast.makeText(getActivity(), "編集が完了しました", Toast.LENGTH_SHORT).show();
            SharedPreferences.Editor editor = myPrefs.edit();
            editor.putInt("intFlg", 0);
            editor.commit();
        }

        //ユーザー情報を格納する
        int formulaMarkUser = UserDAO.formulaMarkFindByPK(db, strUserId);
        ImageView imageView = view.findViewById(R.id.formulaMark);
        if(formulaMarkUser == 0){
            //公式ではなかった場合
            imageView.setVisibility(View.INVISIBLE);
        }else{
            //公式だった場合
            imageView.setVisibility(View.VISIBLE);
        }

        ListView uploadList = view.findViewById(R.id.uploadList);
        Button changeButton = view.findViewById(R.id.changeButton);
        TextView changeText = view.findViewById(R.id.changeText);
        changeButton.setOnClickListener((View v) -> {
            //切り替えボタンが押された場合
            Cursor list = null;
            if(changeFlg == 0){
                //単語帳一覧ボタンが押された場合
                list = FlashcardTitleDAO.findUpload(db, myPrefs.getString("userId",""));

                changeText.setText("単語帳一覧");
                changeButton.setText("問題一覧に切り替え");
                changeFlg = 1;
            }else{
                //問題ボタンが押された場合
                list = TitleListDAO.findUpload(db, myPrefs.getString("userId",""));

                changeText.setText("問題一覧");
                changeButton.setText("単語帳に切り替え");
                changeFlg = 0;
            }

            list(list);
        });

        //リストを表示
        Cursor list = null;
        if(changeFlg == 0){
            //問題ボタンが押された場合
            list = TitleListDAO.findUpload(db, myPrefs.getString("userId",""));
        }else{
            //単語帳一覧ボタンが押された場合
            list = FlashcardTitleDAO.findUpload(db, myPrefs.getString("userId",""));
        }
        list(list);
    }

    /**
     * リストビューのカスタムビューバインダークラス。
     */
    private class CustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch (view.getId()) {
                case R.id.accountTitle:
                    //タイトル
                    TextView accountTitle = view.findViewById(R.id.accountTitle);
                    accountTitle.setText(cursor.getString(columnIndex));
                    return true;
                case R.id.updateDelete:
                    //削除ボタン
                    long id = Long.parseLong(cursor.getString(columnIndex));
                    ImageView btnDelete = (ImageView)view;

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)btnDelete.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)btnDelete.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }

                    btnDelete.setOnClickListener((View v) -> {
                        //削除ボタンが押された場合
                        LayoutInflater inflater = getActivity().getLayoutInflater();
                        View dialogView = inflater.inflate(R.layout.dialog_delete_check, null, false);
                        //ダイアログ作成
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setView(dialogView);

                        builder.setPositiveButton(R.string.dialogDeleteTitle, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //データベース接続
                                _helper = new DatabaseHelper(getActivity());
                                SQLiteDatabase db = _helper.getWritableDatabase();

                                //保存領域に接続
                                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

                                if(changeFlg == 0){
                                    //問題タイトルが削除された場合
                                    sendPastData(myPrefs.getString("userId",null), id, "problem");

                                    Cursor list = TitleListDAO.findUpload(db, myPrefs.getString("userId",""));
                                    list(list);
                                }else{
                                    //単語帳タイトルが削除された場合
                                    sendPastData(myPrefs.getString("userId",null), id, "flashcard");

                                    Cursor list = FlashcardTitleDAO.findUpload(db, myPrefs.getString("userId",""));
                                    list(list);
                                }
                                Toast.makeText(getActivity(), "削除しました", Toast.LENGTH_SHORT).show();
                            }
                        });

                        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });

                        //ダイアログ出力
                        builder.create().show();
                    });
                    return true;
            }
            return false;
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        //編集画面への遷移
        Button btnEdit = view.findViewById(R.id.btnEdit);
        btnEdit.setOnClickListener((View v) -> {
            migrate(AccountEditFragment.newInstance());
        });
    }

    //--------------------------------------------------------非同期処理(単語帳)------------------------------------------------------------

    /**
     * 非同期でサーバにポストを開始するメソッド
     * @param id
     * @param style
     */
    @UiThread
    private void sendPastData(String userId, long id, String style){
        //データベース接続
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        TitleListDAO.uploadUpdate(db, id);
        FlashcardTitleDAO.uploadUpdate(db, id);
        Looper mainLooper = Looper.getMainLooper();
        Handler handler = HandlerCompat.createAsync(mainLooper);
        BackgroundExecutor backgroundPostAccess = new BackgroundExecutor(handler, userId, id, style);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.submit(backgroundPostAccess);
    }

    /**
     * 非同期でサーバにポストするためのクラス。
     */
    private class BackgroundExecutor implements Runnable {

        /**
         * ハンドラオブジェクト。
         */
        private final Handler _handler;
        private final String _userId;
        private final long _id;
        private final String _style;

        /**
         * コンストラクタ。
         * 非同期でサーバにポストするのに必要な情報を取得する。
         * @param handler
         * @param id
         * @param style
         */
        public BackgroundExecutor(Handler handler, String userId, long id, String style){
            _handler = handler;
            _userId = userId;
            _id = id;
            _style = style;
        }

        @Override
        public void run() {
            String postData = "userId=" + _userId + "&titleId=" + _id + "&style=" + _style + "&action=delete";
            HttpURLConnection con = null;
            String err = "";
            URL url = null;
            InputStream is = null;
            String result = "";
            boolean success = false;

            try {
                if(_style.equals("flashcard")){
                    //単語帳のサーバーに飛ぶ
                    url = new URL(FLASHCARD_URL);
                }else{
                    //問題のサーバーに飛ぶ
                    url = new URL(PROBLEM_URL);
                }
                con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setConnectTimeout(5000);
                con.setReadTimeout(5000);
                con.setDoOutput(true);
                OutputStream os = con.getOutputStream();
                os.write(postData.getBytes());
                os.flush();
                os.close();
                int status = con.getResponseCode();
                if(status != 200){
                    throw new IOException("ステータスコード:" + status);
                }
                is = con.getInputStream();

                result = is2String(is);
                success = true;
            }
            catch (SocketTimeoutException ex){
                err = getString(R.string.msg_err_timeout);
                Log.e(DEBUG_TAG, "タイムアウト", ex);
            }
            catch (MalformedURLException ex){
                err = getString(R.string.msg_err_send);
                Log.e(DEBUG_TAG, "URL変換失敗", ex);
            }
            catch (IOException ex){
                err = getString(R.string.msg_err_send);
                Log.e(DEBUG_TAG, "通信失敗", ex);
            }
            finally {
                if(con != null){
                    con.disconnect();
                }
                try {
                    if(is != null){
                        is.close();
                    }
                }
                catch (IOException ex){
                    Log.e(DEBUG_TAG, "InputStream開放失敗", ex);
                }
            }
        }
    }

    /**
     * InputStreamオブジェクトを文字列に変換するメソッド。変換文字コードはUTF-8。
     *
     * @param is 変換対象のInputStreamオブジェクト。
     * @return 変換された文字列。
     * @throws IOException 変換に失敗した時に発生。
     */
    private String is2String(InputStream is) throws IOException{
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuffer sb = new StringBuffer();
        char[] b = new char[1024];
        int line;
        while (0 <= (line = reader.read(b))){
            sb.append(b, 0, line);
        }
        return sb.toString();
    }

    public void list(Cursor cursor){
        ListView uploadList = view.findViewById(R.id.uploadList);
        TextView count = view.findViewById(R.id.titleCount10);

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

        String[] from = {"title", "_id"};
        int[] to = {R.id.accountTitle, R.id.updateDelete};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(getActivity(), R.layout.upload_delete, cursor, from, to, 0);
        adapter.setViewBinder(new CustomViewBinder());
        uploadList.setAdapter(adapter);
        count.setText(cursor.getCount() + "件検出");
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        editor.putString("menu", "");
        editor.commit();

        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }

    @Override
    public void onDestroy(){
        _helper.close();
        super.onDestroy();
    }
}
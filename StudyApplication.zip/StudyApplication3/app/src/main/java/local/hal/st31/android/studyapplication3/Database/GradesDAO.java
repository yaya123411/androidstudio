package local.hal.st31.android.studyapplication3.Database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class GradesDAO {
    /**
     * 成績の全てのデータを取得するメソッド
     * @param db
     * @return
     */
    public static Cursor findAll(SQLiteDatabase db, String userId){
        String sql = "SELECT * FROM grades LEFT OUTER JOIN titleLists ON titleLists._id = grades.titleId WHERE grades.userId = '" + userId + "' GROUP BY grades.titleId ORDER BY _id DESC";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * 特定の成績を1件取り出す
     * @param db
     * @param id
     * @return
     */
    public static Grades findIdByPK(SQLiteDatabase db, long id, Integer count){
        String sql = "SELECT * FROM grades WHERE titleId = '" + id + "' and count = '" + count + "'";
        Cursor cursor = db.rawQuery(sql, null);
        Grades result = null;
        if(cursor.moveToFirst()){
            int idxId = cursor.getColumnIndex("_id");
            String strId = cursor.getString(idxId);
            int idxUserId = cursor.getColumnIndex("userId");
            String strUserId = cursor.getString(idxUserId);
            int idxTitleId = cursor.getColumnIndex("titleId");
            String strTitleId = cursor.getString(idxTitleId);
            int idxCount = cursor.getColumnIndex("count");
            String strCount = cursor.getString(idxCount);
            int idxCorrectSolutionRate = cursor.getColumnIndex("correctSolutionRate");
            String strCorrectSolutionRate = cursor.getString(idxCorrectSolutionRate);
            int idxCorrectSolutionNum = cursor.getColumnIndex("correctSolutionNum");
            String strCorrectSolutionNum = cursor.getString(idxCorrectSolutionNum);
            int idxTime = cursor.getColumnIndex("time");
            String strTime = cursor.getString(idxTime);
            String strData = cursor.getString(idxTime);

            result = new Grades();
            result.setId(Long.parseLong(strId));
            result.setUserId(strUserId);
            result.setTitleId(Long.parseLong(strTitleId));
            result.setCount(Integer.parseInt(strCount));
            result.setCorrectSolutionRate(Integer.parseInt(strCorrectSolutionRate));
            result.setCorrectSolutionNum(Integer.parseInt(strCorrectSolutionNum));
            result.setTime(Double.parseDouble(strTime));
            result.setData(String.valueOf(strData));
        }
        return result;
    }

    /**
     * 成績の個数を返す
     * @param db
     * @param id
     * @return
     */
    public static int GradesCount(SQLiteDatabase db, long id){
        //id=_id
        String sql = "SELECT count(*) as count FROM grades WHERE titleId = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);
        String strCount = "";
        if(cursor.moveToFirst()){
            int idxCount = cursor.getColumnIndex("count");
            strCount = cursor.getString(idxCount);
        }
        return Integer.parseInt(strCount);
    }

    /**
     * 成績を追加するメソッド
     * @param db
     * @param userId
     * @param titleId
     * @param correctSolutionRate
     * @param correctSolutionNum
     * @param time
     * @return
     */
    public static long insert(SQLiteDatabase db, String userId, long titleId, String downloadId, int correctSolutionRate, int correctSolutionNum, Double time){
        //同じタイトルを解いた個数を取得
        String selectSql = "SELECT count(*) as count FROM grades WHERE titleId = '" + titleId + "'";
        Cursor cursor = db.rawQuery(selectSql, null);
        int count = 0;
        if(cursor.moveToFirst()){
            int idxCount = cursor.getColumnIndex("count");
            String strCount = cursor.getString(idxCount);
            count = Integer.parseInt(strCount);
        }
        //成績を追加
        String insertSql = "INSERT INTO grades (userId, titleId, downloadId, count, correctSolutionRate, correctSolutionNum, time, data) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))";
        SQLiteStatement stmt = db.compileStatement(insertSql);
        stmt.bindString(1, userId);
        stmt.bindLong(2, titleId);
        if(downloadId != null){
            //ダウンロードした問題ならば
            stmt.bindLong(3, Long.parseLong(downloadId));
        }else{
            stmt.bindLong(3, Long.parseLong(String.valueOf(0)));
        }
        stmt.bindLong(4, count+1);
        stmt.bindLong(5, correctSolutionRate);
        stmt.bindLong(6, correctSolutionNum);
        stmt.bindDouble(7, time);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * 成績を削除するメソッド
     * @param db
     * @param titleId
     * @return
     */
    public static int delete(SQLiteDatabase db, long titleId){
        String sql = "DELETE FROM grades WHERE titleId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, titleId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    /**
     * 最大スコアを格納する
     * @param db
     * @param titleId
     * @return
     */
    public static Grades maxScore(SQLiteDatabase db, long titleId){
        String sql = "SELECT MAX(CAST(correctSolutionRate AS SIGNED)) as max FROM grades WHERE titleId = '" + titleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        Grades result = null;
        if(cursor.moveToFirst()){
            int idxMax = cursor.getColumnIndex("max");
            String max = cursor.getString(idxMax);

            result = new Grades();
            result.setMaxScore(Integer.parseInt(max));
        }
        return result;
    }

    /**
     * 最小スコアを格納する
     * @param db
     * @param titleId
     * @return
     */
    public static Grades minScore(SQLiteDatabase db, long titleId){
        String sql = "SELECT MIN(CAST(correctSolutionRate AS SIGNED)) as min FROM grades WHERE titleId = '" + titleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        Grades result = null;
        if(cursor.moveToFirst()){
            int idxMin = cursor.getColumnIndex("min");
            String min = cursor.getString(idxMin);

            result = new Grades();
            result.setMinScore(Integer.parseInt(min));
        }
        return result;
    }

    /**
     * 平均スコアを格納する
     * @param db
     * @param titleId
     * @return
     */
    public static Grades avgScore(SQLiteDatabase db, long titleId){
        String sql = "SELECT AVG(CAST(correctSolutionRate AS SIGNED)) as avg FROM grades WHERE titleId = '" + titleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        Grades result = null;
        if(cursor.moveToFirst()){
            int idxAvg = cursor.getColumnIndex("avg");
            String avg = cursor.getString(idxAvg);

            Double doubleAvg = Double.parseDouble(avg);
            BigDecimal bigAvg = new BigDecimal(doubleAvg).setScale(0, RoundingMode.HALF_UP);
            result = new Grades();
            result.setAvgScore(bigAvg);
        }
        return result;
    }

    /**
     * ダウンロード済みの問題の成績を全て削除する
     * @param db
     * @param downloadId
     * @return
     */
    public static int deleteByDownloadId(SQLiteDatabase db, long downloadId){
        String sql = "DELETE FROM grades WHERE downloadId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, downloadId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    //---------------------------------------メニュー----------------------------
    public static Cursor findSerch(SQLiteDatabase db, String userId, String serch, String take, String sort){
        String sql = "";
        String where = "";
        String orderBy = "";

        if(!serch.equals("")){
            //検索ボタンが押された場合
            where = " AND titleLists.title like '%" + serch + "%'";
        }
        if(!take.equals("")){
            //抽出条件
            if(take.equals("ダウンロードしている")){
                where += " AND uploadFlg = 1";
            }else if(take.equals("ダウンロードされていない")){
                where += " AND uploadFlg = 0";
            }
        }
        if(!sort.equals("")){
            //並び替え
            if(sort.equals("新しい順")){
                orderBy = " ORDER BY _id DESC";
            }else if(sort.equals("古い順")){
                orderBy = " ORDER BY _id ASC";
            }else if(sort.equals("最高点が高い順")){
                orderBy = " ORDER BY correctSolutionRate DESC";
            }else if(sort.equals("最高点が低い順")){
                orderBy = " ORDER BY correctSolutionRate ASC";
            }
        }else{
            orderBy = " ORDER BY updateTime DESC";
        }

        sql = "SELECT * FROM grades LEFT OUTER JOIN titleLists ON titleLists._id = grades.titleId WHERE grades.userId = '" + userId + "'" + where + " GROUP BY titleId" + orderBy;
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }
}


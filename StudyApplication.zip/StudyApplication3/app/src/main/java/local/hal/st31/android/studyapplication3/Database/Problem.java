package local.hal.st31.android.studyapplication3.Database;

public class Problem {
    //問題
    /**
     * 問題番号
     */
    private long _Id;
    /**
     * 問題タイトルID
     */
    private long _titleId;
    /**
     * 問題
     */
    private int _count;
    /**
     * 問題
     */
    private String _question;
    /**
     * 回答形式
     */
    private String _choice;
    /**
     * 選択肢A
     */
    private String _choiceA;
    /**
     * 選択肢B
     */
    private String _choiceB;
    /**
     * 選択肢C
     */
    private String _choiceC;
    /**
     * 選択肢D
     */
    private String _choiceD;
    /**
     * 選択肢E
     */
    private String _choiceE;
    /**
     * 選択肢F
     */
    private String _choiceF;
    /**
     * 選択肢G
     */
    private String _choiceG;
    /**
     * 選択式のみの回答
     */
    private String _reply;
    /**
     * 解説
     */
    private String _explanation;
    /**
     * 更新日
     */
    private String _updateTime;

    //以下アクセサメソッド

    public long getId(){
        return _Id;
    }
    public void setId(long Id){
        _Id = Id;
    }
    public long getTitleId(){
        return _titleId;
    }
    public void setTitleId(long titleId){
        _titleId = titleId;
    }
    public String getQuestion(){
        return _question;
    }
    public void setQuestion(String question){
        _question = question;
    }
    public String getChoice(){
        return _choice;
    }
    public void setChoice(String choice){
        _choice = choice;
    }
    public String getChoiceA(){
        return _choiceA;
    }
    public void setChoiceA(String choiceA){
        _choiceA = choiceA;
    }
    public String getChoiceB(){
        return _choiceB;
    }
    public void setChoiceB(String choiceB){
        _choiceB = choiceB;
    }
    public String getChoiceC(){
        return _choiceC;
    }
    public void setChoiceC(String choiceC){
        _choiceC = choiceC;
    }
    public String getChoiceD(){
        return _choiceD;
    }
    public void setChoiceD(String choiceD){
        _choiceD = choiceD;
    }
    public String getChoiceE(){
        return _choiceE;
    }
    public void setChoiceE(String choiceE){
        _choiceE = choiceE;
    }
    public String getChoiceF(){
        return _choiceF;
    }
    public void setChoiceF(String choiceF){
        _choiceF = choiceF;
    }
    public String getChoiceG(){
        return _choiceG;
    }
    public void setChoiceG(String choiceG){
        _choiceG = choiceG;
    }
    public String getReply(){
        return _reply;
    }
    public void setReply(String reply){
        _reply = reply;
    }
    public String getExplanation(){
        return _explanation;
    }
    public void setExplanation(String explanation){
        _explanation = explanation;
    }
    public String getUpdateTime(){
        return _updateTime;
    }
    public void setUpdateTime(String updateTime){
        _updateTime = updateTime;
    }
    public Integer getCount(){
        return _count;
    }
    public void setCount(Integer count){
        _count = count;
    }
}

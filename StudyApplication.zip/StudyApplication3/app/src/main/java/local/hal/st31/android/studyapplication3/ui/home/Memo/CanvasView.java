package local.hal.st31.android.studyapplication3.ui.home.Memo;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

public class CanvasView extends View {
    private static ArrayList<ArrayList<Float>> lineParent = new ArrayList<>(); //座標を保存する
    private ArrayList<Float> lineChild = new ArrayList<>(); //座標を保存する
    private static ArrayList<ArrayList<Float>> coordinateParent = new ArrayList<>(); //座標を保存する
    private final ArrayList<ArrayList<Float>> deleteCoordinateParent = new ArrayList<>();
    private ArrayList<Float> coordinateChild = new ArrayList<>();
    private static ArrayList<Integer> ArrayColor;  // カラーリスト
    private static ArrayList<Path> pathList;  // 直線リスト
    private ArrayList<Path> deletePathList = new ArrayList(); // 消された直線リスト
    private ArrayList<Integer> deleteColor = new ArrayList(); // 消されたカラーリスト
    private Integer color;//現在の色
    private final Paint paint;//現在のペンの状態
    private int colorFlg = 0;//色のフラグ
    private int histryFlg = 0; //どれくらい残すかのフラグ

    //======================================================================================
    //--  コンストラクタ
    //======================================================================================
    public CanvasView(Context context, AttributeSet attrs) {
        super(context, attrs);
        //-- 初期化
        //- Path関連
        pathList = new ArrayList<Path>();   // リストの作成
        ArrayColor = new ArrayList<Integer>();   // リストの作成
        coordinateParent = new ArrayList<>();
        deletePathList = new ArrayList<>();
        deleteColor = new ArrayList<>();
        lineParent = new ArrayList<>();

        //- Paint関連
        paint = new Paint();
        paint.setColor(Color.BLACK);          // 色の指定
        paint.setStyle(Paint.Style.STROKE); // 描画設定を'線'に設定
        paint.setAntiAlias(true);           // アンチエイリアスの適応
        paint.setStrokeWidth(10);           // 線の太さ
    }

    //======================================================================================
    //--  描画メソッド
    //======================================================================================
    @Override
    protected void onDraw(Canvas canvas) {
        for(int i=0; i<pathList.size(); i++){
            paint.setColor(ArrayColor.get(i));
            canvas.drawPath(pathList.get(i), paint);   // Pathの描画
        }
        invalidate();   // 再描画
    }

    //======================================================================================
    //--  タッチイベント
    //=====================================================================================
    private static Path drawingPath;

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        switch ( event.getAction() ) {
            case MotionEvent.ACTION_DOWN:                             //- 画面をタッチしたとき
                lineChild = new ArrayList<>();
                coordinateChild.add(event.getX());
                coordinateChild.add(event.getY());
                drawingPath = new Path();                         // 新たなPathのインスタンスの作成
                drawingPath.moveTo(event.getX(), event.getY());   // 始点を設定
                pathList.add(drawingPath);                        // リストにPathを追加
                if(ArrayColor.size() == 0){
                    //一番最初に画面をタッチした場合(デフォルト)
                    ArrayColor.add(paint.getColor());
                }else{
                    if(colorFlg == 0){
                        //カラーボタンが押されなかった場合
                        ArrayColor.add(ArrayColor.get(ArrayColor.size()-1));
                    }else{
                        //カラーボタンが押された場合
                        ArrayColor.add(color);
                        colorFlg = 0;
                    }
                }
                if(histryFlg == 1){
                    //一つ前に戻るボタンが押され、そのまま画面をタップした場合
                    deletePathList.clear();
                    deleteColor.clear();
                    histryFlg = 0;
                }
                break;
            case MotionEvent.ACTION_UP:                               //- 画面から指を離したとき
                coordinateChild.add(event.getX());
                coordinateChild.add(event.getY());
                coordinateParent.add(coordinateChild);//座標を追加
                coordinateChild = new ArrayList<>();
                lineParent.add(lineChild);//座標を追加
                drawingPath.moveTo(event.getX(), event.getY());   // 移動先の追加
                break;
            case MotionEvent.ACTION_MOVE:                             //- タッチしながら指をスライドさせたとき
                drawingPath.lineTo(event.getX(), event.getY());   // 移動先の追加
                lineChild.add(event.getX());
                lineChild.add(event.getY());
                break;
        }
        return true;   /* 返却値は必ず "true" にすること!! */
    }

    /**
     * クリアボタンが押された場合
     */
    public void allDelete() {
        // リストが保持している配列、インスタンスを全て削除
        pathList.clear();
        deletePathList.clear();
        ArrayColor.clear();
        deleteColor.clear();
        lineParent.clear();
        lineChild.clear();
        coordinateParent.clear();
        coordinateChild.clear();
    }

    /**
     * 一つ戻るボタンが押された場合
     * @return
     */
    public Integer oneReturn(){
        if(pathList.size() != 0){
            color = ArrayColor.get(ArrayColor.size()-1);
            deletePathList.add(pathList.get(pathList.size()-1));
            pathList.remove(pathList.size()-1);
            deleteColor.add(ArrayColor.get(ArrayColor.size()-1));
            ArrayColor.remove(ArrayColor.size()-1);
            deleteCoordinateParent.add(coordinateParent.get(coordinateParent.size()-1));
            coordinateParent.remove(coordinateParent.size()-1);
            colorFlg = 1;
            histryFlg = 1;
        }
        return color;
    }

    /**
     * 一つ進ボタンが押された場合
     */
    public void oneAdvance(){
        if(deletePathList.size() != 0){
            pathList.add(deletePathList.get(deletePathList.size()-1));
            deletePathList.remove(deletePathList.size()-1);
            ArrayColor.add(deleteColor.get(deleteColor.size()-1));
            deleteColor.remove(deleteColor.size()-1);
            coordinateParent.add(deleteCoordinateParent.get(deleteCoordinateParent.size()-1));
            deleteCoordinateParent.remove(deleteCoordinateParent.size()-1);
        }
    }

    /**
     * 色を変換するメソッド
     * @param color
     */
    public void penColor(int color){
        // 色の指定
        paint.setColor(color);
        this.color = color;
        colorFlg = 1;
    }

    /**
     * 以下アクセサメソッド
     * @return
     */
    public static ArrayList<ArrayList<Float>> getCoordinate(){
        return coordinateParent;
    }

    public static ArrayList<ArrayList<Float>> getLine(){
        return lineParent;
    }

    public static ArrayList<Integer> getColorList(){
        return ArrayColor;
    }

    public static void setCoordinate(ArrayList<ArrayList<Float>> coordinateParent){
        CanvasView.coordinateParent = coordinateParent;
    }

    public static void setColorList(ArrayList<Integer> ArrayColor){
        CanvasView.ArrayColor = ArrayColor;
    }

    public static void setLine(ArrayList<ArrayList<Float>> lineParent){
        CanvasView.lineParent = lineParent;
        for(int i=0; i<coordinateParent.size(); i++){
            drawingPath = new Path();                         // 新たなPathのインスタンスの作成
            drawingPath.moveTo(coordinateParent.get(i).get(0), coordinateParent.get(i).get(1));   // 始点を設定
            pathList.add(drawingPath);                        // リストにPathを追加
            for (int j=0; j<lineParent.get(i).size()/2; j++){
                drawingPath.lineTo(lineParent.get(i).get(j*2), lineParent.get(i).get(j*2+1));   // 移動先の追加
            }
            drawingPath.moveTo(coordinateParent.get(i).get(2), coordinateParent.get(i).get(3));   // 移動先の追加
        }
    }
}
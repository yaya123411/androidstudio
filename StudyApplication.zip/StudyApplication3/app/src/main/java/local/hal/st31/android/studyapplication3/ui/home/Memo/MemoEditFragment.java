package local.hal.st31.android.studyapplication3.ui.home.Memo;

import static android.app.Activity.RESULT_OK;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.ParcelFileDescriptor;
import android.speech.RecognizerIntent;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;

import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.Flashcard;
import local.hal.st31.android.studyapplication3.Database.FlashcardDAO;
import local.hal.st31.android.studyapplication3.Database.Memo;
import local.hal.st31.android.studyapplication3.Database.MemoDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.OCR;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MemoEditFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MemoEditFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    /**
     * 新規登録モードか更新モードかを表すフィールド。
     */
    private int _mode = MemoTopFragment.MODE_INSERT;
    //任意の識別番号
    private static final int REQUEST_CODE = 12345;
    //ocr
    private static final int REQUEST_CODE_PICK_CONTENT = 0;
    private Intent intent;
    private OCR _ocr;
    View view;

    //フラグメントを呼び出す
    public static MemoEditFragment newInstance(int mode, Long idNo) {
// Fragemnt01 インスタンス生成
        MemoEditFragment MemoEditFragment = new MemoEditFragment();

        // Bundle にパラメータを設定
        Bundle args = new Bundle();
        args.putInt("mode", mode);
        args.putLong("idNo", idNo);
        MemoEditFragment.setArguments(args);

        return MemoEditFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_memo_edit,
                container, false);

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "メモ帳編集");
        editor.commit();
        setHasOptionsMenu(true);

        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        return view;
    }

    //メニューが押された場合
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Bundle args = getArguments();
        boolean returnVal = true;
        int itemId = item.getItemId();
        switch (itemId) {
            case R.id.menuPen:
                EditText etTitle = view.findViewById(R.id.productMemoEtTitle);
                String strTitle = etTitle.getText().toString();
                EditText etNote = view.findViewById(R.id.productMemoEtNote);
                String strNote = etNote.getText().toString();

                _helper = new DatabaseHelper(getActivity());
                SQLiteDatabase db = _helper.getWritableDatabase();

                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = myPrefs.edit();

                if(args.getLong("idNo") != 0){
                    editor.putLong("memoTitleId", args.getLong("idNo"));
                    editor.commit();
                }

                Memo memo = MemoDAO.findIdByPK(db, myPrefs.getLong("memoTitleId", 0));

                if (memo != null) {
                    //上書き処理
                    if (!strTitle.equals(memo.getTitle()) || !strNote.equals(memo.getNote())) {
                        //タイトル又は内容が変更されていた場合
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("保存しますか?");

                        builder.setPositiveButton(R.string.dialog_yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //はいが押された場合
                                MemoDAO.update(db, args.getLong("idNo"), strTitle, strNote);
                                migrate(CanvasFragment.newInstance(args.getLong("idNo")));
                            }
                        });
                        builder.setNegativeButton(R.string.dialog_no, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //いいえが押された場合
                                etTitle.setText(memo.getTitle());
                                etNote.setText(memo.getNote());
                                migrate(CanvasFragment.newInstance(args.getLong("idNo")));
                            }
                        });

                        //ダイアログ出力
                        builder.create().show();
                    } else {
                        migrate(CanvasFragment.newInstance(args.getLong("idNo")));
                    }
                } else {
                    //新規登録処理
                    if (!strTitle.equals("") || !strNote.equals("")) {
                        //タイトル又は内容が変更されていた場合
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("保存しますか?");

                        builder.setPositiveButton(R.string.dialog_yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //はいが押された場合
                                long memoId = MemoDAO.insert(db, myPrefs.getString("userId", null), strTitle, strNote);
                                editor.putLong("memoTitleId", memoId);
                                editor.commit();
                                migrate(CanvasFragment.newInstance(args.getLong("idNo")));
                            }
                        });
                        builder.setNegativeButton(R.string.dialog_no, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //いいえが押された場合
                                etTitle.setText("");
                                etNote.setText("");
                                migrate(CanvasFragment.newInstance(args.getLong("idNo")));
                            }
                        });

                        //ダイアログ出力
                        builder.create().show();
                    } else {
                        migrate(CanvasFragment.newInstance(args.getLong("idNo")));
                    }
                }
                break;
            case R.id.menuAudio:
                //マイクボタンが押された場合
                //音声認識用のインテントを作成
                intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                //認識する言語を指定（この場合は日本語）
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.JAPANESE.toString());
                //認識する候補数の指定
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 10);
                //音声認識時に表示する案内を設定
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "話してください");
                //音声認識を開始
                startActivityForResult(intent, REQUEST_CODE);
                break;
            case R.id.menuCamera:
                //カメラボタンが押された場合
                _ocr = new OCR(getActivity().getApplicationContext());
                LayoutInflater cameraInflater = getActivity().getLayoutInflater();
                View cameraDialogView = cameraInflater.inflate(R.layout.dialog_camera, null, false);
                AlertDialog.Builder cameraDuilder = new AlertDialog.Builder(getActivity());
                cameraDuilder.setView(cameraDialogView);

                TextView textCamera = cameraDialogView.findViewById(R.id.textCamera);
                TextView textGallery = cameraDialogView.findViewById(R.id.textGallery);

                //キャンセルボタンが押された場合
                cameraDuilder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });

                //ダイアログ出力
                AlertDialog cameraDialog = cameraDuilder.show();

                //写真を撮影するボタンが押された場合
                textCamera.setOnClickListener((View view) -> {
                    //カメラを起動
                    cameraLauncher.launch(null);
                    cameraDialog.dismiss();
                });

                textGallery.setOnClickListener((View view) -> {
                    //写真を選択するボタンが押された場合
                    if (Build.VERSION.SDK_INT < 19) {
                        intent = new Intent(Intent.ACTION_PICK);
                        intent.setAction(Intent.ACTION_GET_CONTENT);
                    } else {
                        intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                    }
                    intent.setType("image/*");
                    startActivityForResult(intent, REQUEST_CODE_PICK_CONTENT);
                    cameraDialog.dismiss();
                });
                break;
        }
        return returnVal;
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        //保存領域をオープンさせる
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        Bundle args = getArguments();

        _mode = args.getInt("mode");

        //戻るボタンが押された場合
        ImageView btnBack = view.findViewById(R.id.memoEditBack);
        btnBack.setOnClickListener((View v) -> {
            //ダイアログ作成
            EditText title = view.findViewById(R.id.productMemoEtTitle);
            EditText note = view.findViewById(R.id.productMemoEtNote);

            Memo result = MemoDAO.findIdByPK(db, myPrefs.getLong("memoTitleId",0));

            if(result != null){
                //リストがクリックされた場合
                if(!result.getTitle().equals(title.getText().toString()) || !result.getNote().equals(note.getText().toString())){
                    //変更された場合
                    LayoutInflater inflater = getActivity().getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.dialog_back, null, false);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    TextView transition = dialogView.findViewById(R.id.dialogTransition);
                    TextView cancel = dialogView.findViewById(R.id.dialogCancel);
                    builder.setView(dialogView);

                    //ダイアログ出力
                    AlertDialog alertDialog = builder.show();

                    transition.setOnClickListener(parts -> {
                        //遷移ボタンが押された場合
                        alertDialog.dismiss();
                        editor.putString("menu", "");
                        editor.commit();
                        back();
                    });
                    cancel.setOnClickListener(parts -> {
                        //キャンセルボタンが押された場合
                        alertDialog.dismiss();
                    });
                }else{
                    editor.putString("menu", "");
                    editor.commit();
                    back();
                }
            }else{
                if(!"".equals(title.getText().toString()) || !"".equals(note.getText().toString())){
                    //変更された場合
                    LayoutInflater inflater = getActivity().getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.dialog_back, null, false);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    TextView transition = dialogView.findViewById(R.id.dialogTransition);
                    TextView cancel = dialogView.findViewById(R.id.dialogCancel);
                    builder.setView(dialogView);

                    //ダイアログ出力
                    AlertDialog alertDialog = builder.show();

                    transition.setOnClickListener(parts -> {
                        //遷移ボタンが押された場合
                        alertDialog.dismiss();
                        editor.putString("menu", "");
                        editor.commit();
                        back();
                    });
                    cancel.setOnClickListener(parts -> {
                        //キャンセルボタンが押された場合
                        alertDialog.dismiss();
                    });
                    editor.putInt("addFlg", 0);
                    editor.commit();
                }else{
                    editor.putString("menu", "");
                    editor.commit();
                    back();
                }
            }
        });

        EditText etTitle = view.findViewById(R.id.productMemoEtTitle);
        EditText etNote = view.findViewById(R.id.productMemoEtNote);
        if (_mode == MemoTopFragment.MODE_UPDATE) {
            //リストが押された場合
            if(args.getLong("idNo") != 0){
                editor.putLong("memoTitleId", args.getLong("idNo"));
                editor.commit();
            }
            //データを保持
            Memo result = MemoDAO.findIdByPK(db, myPrefs.getLong("memoTitleId", 0));
            if(result != null){
                etTitle.setText(result.getTitle());
                etNote.setText(result.getNote());
            }
        } else {
            //プラスボタン(追加)が押された場合
            //消去ボタンのテキストを追加に変更
            Button btnUpdateAdd = view.findViewById(R.id.btnUpdateAdd);
            btnUpdateAdd.setText(R.string.btnInsert);

            //追加のボタンの色を変更
            btnUpdateAdd.setBackgroundColor(Color.rgb(0, 100, 255));
        }

        if(myPrefs.getLong("memoAction", 0) == 2){
            back();
            migrate(MemoEditFragment.newInstance(MemoTopFragment.MODE_UPDATE, myPrefs.getLong("memoTitleId", 0)));
            editor.putLong("memoAction", 0);
            editor.commit();
        }

        //更新、追加ボタンが押された場合
        Button btnUpdate = view.findViewById(R.id.btnUpdateAdd);
        btnUpdate.setOnClickListener((View v) -> {
            int flg = 0;
            String msg = "";
            String strTitle = etTitle.getText().toString();
            String strNote = etNote.getText().toString();

            //タイトル
            if (strTitle.equals("")) {
                etTitle.setError("値を入力してください");
                flg = 1;
            }

            if (flg == 0) {
                //入力チェックがOKだった場合
                Button btnUpdateAdd = view.findViewById(R.id.btnUpdateAdd);
                String strBtnUpdateAdd = btnUpdateAdd.getText().toString();

                if (strBtnUpdateAdd.equals("追加")) {
                    //追加ボタンが押された場合
                    MemoDAO.insert(db, myPrefs.getString("userId", null), strTitle, strNote);
                    msg = "追加しました";
                } else {
                    //更新ボタンが押された場合
                    MemoDAO.update(db, args.getLong("idNo"), strTitle, strNote);
                    msg = "更新しました";
                }
                Toast.makeText(this.getActivity(), msg, Toast.LENGTH_SHORT).show();
                back();
            }
        });
    }

    //音声認識が終わると自動で呼び出されるメソッド
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        EditText result = dialog().findViewById(R.id.editResult);

        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            //マイクボタンが押された場合
            //data から音声認識の結果を取り出す（リスト形式で）
            ArrayList<String> kekka = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

            //認識結果が一つ以上ある場合はテキストビューに結果を表示する
            if (kekka.size() > 0) {
                //一番最初にある認識結果を表示する
                result.setText(kekka.get(0));
            } else {
                //何らかの原因で音声認識に失敗した場合はエラーメッセージを表示
                result.setText("音声の認識に失敗しました…");
            }
        } else if (requestCode == REQUEST_CODE_PICK_CONTENT) {
            //カメラボタンの写真を選択するボタンが押された場合
            String ocrString;
            if (resultCode == RESULT_OK && data != null) {
                Bitmap bitmap = null;
                if (Build.VERSION.SDK_INT < 19) {
                    try {
                        InputStream in = getActivity().getContentResolver().openInputStream(data.getData());
                        bitmap = BitmapFactory.decodeStream(in);
                        try {
                            if (in != null) {
                                in.close();
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                } else {
                    Uri uri = data.getData();
                    try {
                        ParcelFileDescriptor parcelFileDescriptor = getActivity().getContentResolver().openFileDescriptor(uri, "r");
                        if (parcelFileDescriptor != null) {
                            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
                            bitmap = BitmapFactory.decodeFileDescriptor(fileDescriptor);
                            parcelFileDescriptor.close();
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (bitmap != null) {
                    ocrString = _ocr.getString(getActivity().getApplicationContext(), bitmap);
                } else {
                    ocrString = "bitmap is null";
                }
            } else {
                ocrString = "上手く読み取れませんでした";
            }
            result.setText(ocrString);
        }
    }

    //カメラボタンの写真を撮影するボタンが押された場合
    private final ActivityResultLauncher<Void> cameraLauncher = registerForActivityResult(
            new ActivityResultContracts.TakePicturePreview(), bitmap -> {
                EditText result = dialog().findViewById(R.id.editResult);
                try {
                    int rotationDegree = 0;
                    InputImage image = InputImage.fromBitmap(bitmap, rotationDegree);

                    // 日本語もサポートした！
                    TextRecognizer recognizer = TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());

                    Task<Text> task = recognizer.process(image)
                            .addOnSuccessListener(new OnSuccessListener<Text>() {
                                @Override
                                public void onSuccess(Text visionText) {
                                    String resultText = visionText.getText(); // 文字列取得！
                                    result.setText(resultText);
                                }
                            });
                } catch (NullPointerException e) {
                    result.setText("正常に値を受け取れませんでした");
                }
            });

    //ダイアログ生成メソッド
    public AlertDialog dialog() {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_audio_camera_result, null, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(dialogView);

        //キャンセルボタンが押された場合
        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });

        //ダイアログ出力
        return builder.show();
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment) {
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back() {
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
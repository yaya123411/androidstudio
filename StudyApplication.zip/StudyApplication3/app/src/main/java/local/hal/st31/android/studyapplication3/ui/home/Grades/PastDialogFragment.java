package local.hal.st31.android.studyapplication3.ui.home.Grades;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.fragment.app.DialogFragment;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import local.hal.st31.android.studyapplication3.R;

public class PastDialogFragment extends DialogFragment {
    View view;
    private int questionFlg = 0;
    private int replyAFlg = 0;
    private int replyBFlg = 0;
    private int replyCFlg = 0;
    private int replyDFlg = 0;
    private int replyEFlg = 0;
    private int replyFFlg = 0;
    private int replyGFlg = 0;
    private int myReplyAFlg = 0;
    private int myReplyBFlg = 0;
    private int myReplyCFlg = 0;
    private int myReplyDFlg = 0;
    private int myReplyEFlg = 0;
    private int myReplyFFlg = 0;
    private int myReplyGFlg = 0;
    private TextView textReplyAnswerA;
    private TextView textReplyAnswerB;
    private TextView textReplyAnswerC;
    private TextView textReplyAnswerD;
    private TextView textReplyAnswerE;
    private TextView textReplyAnswerF;
    private TextView textReplyAnswerG;
    private TextView myReplyAnswerA;
    private TextView myReplyAnswerB;
    private TextView myReplyAnswerC;
    private TextView myReplyAnswerD;
    private TextView myReplyAnswerE;
    private TextView myReplyAnswerF;
    private TextView myReplyAnswerG;
    private ArrayList<TextView> dialogChoose = new ArrayList<>();
    private ArrayList<TextView> dialogMyChoose = new ArrayList<>();
    private ArrayList<TextView> dialogChooseAnswer = new ArrayList<>();
    private ArrayList<TextView> dialogMyChooseAnswer = new ArrayList<>();
    private TextView dialogChooseB;
    private TextView dialogChooseC;
    private TextView dialogChooseD;
    private TextView dialogChooseE;
    private TextView dialogChooseF;
    private TextView dialogChooseG;
    private TextView dialogMyChooseA;
    private TextView dialogMyChooseB;
    private TextView dialogMyChooseC;
    private TextView dialogMyChooseD;
    private TextView dialogMyChooseE;
    private TextView dialogMyChooseF;
    private TextView dialogMyChooseG;

    private int explanationFlg = 0;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        this.view = view;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState){
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.past_dialog_fragment, null, false);
        textReplyAnswerA = view.findViewById(R.id.correctSolutionAnswerA);
        textReplyAnswerB = view.findViewById(R.id.correctSolutionAnswerB);
        textReplyAnswerC = view.findViewById(R.id.correctSolutionAnswerC);
        textReplyAnswerD = view.findViewById(R.id.correctSolutionAnswerD);
        textReplyAnswerE = view.findViewById(R.id.correctSolutionAnswerE);
        textReplyAnswerF = view.findViewById(R.id.correctSolutionAnswerF);
        textReplyAnswerG = view.findViewById(R.id.correctSolutionAnswerG);
        myReplyAnswerA = view.findViewById(R.id.myReplyAnswerA);
        myReplyAnswerB = view.findViewById(R.id.myReplyAnswerB);
        myReplyAnswerC = view.findViewById(R.id.myReplyAnswerC);
        myReplyAnswerD = view.findViewById(R.id.myReplyAnswerD);
        myReplyAnswerE = view.findViewById(R.id.myReplyAnswerE);
        myReplyAnswerF = view.findViewById(R.id.myReplyAnswerF);
        myReplyAnswerG = view.findViewById(R.id.myReplyAnswerG);
        dialogChooseB = view.findViewById(R.id.dialogChooseB);
        dialogChooseC = view.findViewById(R.id.dialogChooseC);
        dialogChooseD = view.findViewById(R.id.dialogChooseD);
        dialogChooseE = view.findViewById(R.id.dialogChooseE);
        dialogChooseF = view.findViewById(R.id.dialogChooseF);
        dialogChooseG = view.findViewById(R.id.dialogChooseG);
        dialogMyChooseA = view.findViewById(R.id.dialogMyChooseA);
        dialogMyChooseB = view.findViewById(R.id.dialogMyChooseB);
        dialogMyChooseC = view.findViewById(R.id.dialogMyChooseC);
        dialogMyChooseD = view.findViewById(R.id.dialogMyChooseD);
        dialogMyChooseE = view.findViewById(R.id.dialogMyChooseE);
        dialogMyChooseF = view.findViewById(R.id.dialogMyChooseF);
        dialogMyChooseG = view.findViewById(R.id.dialogMyChooseG);
        //テキストを配列に入れる
        dialogChoose.add(view.findViewById(R.id.dialogChooseA));
        dialogChoose.add(view.findViewById(R.id.dialogChooseB));
        dialogChoose.add(view.findViewById(R.id.dialogChooseC));
        dialogChoose.add(view.findViewById(R.id.dialogChooseD));
        dialogChoose.add(view.findViewById(R.id.dialogChooseE));
        dialogChoose.add(view.findViewById(R.id.dialogChooseF));
        dialogChoose.add(view.findViewById(R.id.dialogChooseG));
        dialogMyChoose.add(view.findViewById(R.id.dialogMyChooseA));
        dialogMyChoose.add(view.findViewById(R.id.dialogMyChooseB));
        dialogMyChoose.add(view.findViewById(R.id.dialogMyChooseC));
        dialogMyChoose.add(view.findViewById(R.id.dialogMyChooseD));
        dialogMyChoose.add(view.findViewById(R.id.dialogMyChooseE));
        dialogMyChoose.add(view.findViewById(R.id.dialogMyChooseF));
        dialogMyChoose.add(view.findViewById(R.id.dialogMyChooseG));
        dialogChooseAnswer.add(view.findViewById(R.id.correctSolutionAnswerA));
        dialogChooseAnswer.add(view.findViewById(R.id.correctSolutionAnswerB));
        dialogChooseAnswer.add(view.findViewById(R.id.correctSolutionAnswerC));
        dialogChooseAnswer.add(view.findViewById(R.id.correctSolutionAnswerD));
        dialogChooseAnswer.add(view.findViewById(R.id.correctSolutionAnswerE));
        dialogChooseAnswer.add(view.findViewById(R.id.correctSolutionAnswerF));
        dialogChooseAnswer.add(view.findViewById(R.id.correctSolutionAnswerG));
        dialogMyChooseAnswer.add(view.findViewById(R.id.myReplyAnswerA));
        dialogMyChooseAnswer.add(view.findViewById(R.id.myReplyAnswerB));
        dialogMyChooseAnswer.add(view.findViewById(R.id.myReplyAnswerC));
        dialogMyChooseAnswer.add(view.findViewById(R.id.myReplyAnswerD));
        dialogMyChooseAnswer.add(view.findViewById(R.id.myReplyAnswerE));
        dialogMyChooseAnswer.add(view.findViewById(R.id.myReplyAnswerF));
        dialogMyChooseAnswer.add(view.findViewById(R.id.myReplyAnswerG));
        TextView textQuestion = view.findViewById(R.id.question);
        TextView textReply = view.findViewById(R.id.correctSolution);
        TextView textMyReply = view.findViewById(R.id.myReply);
        View border = view.findViewById(R.id.border2);
        TextView textExplanation = view.findViewById(R.id.explanation);
        // 値を受け取る
        String question = getArguments().getString("question", null);
        String jsonChoose = getArguments().getString("choose");
        String jsonMissChoose = getArguments().getString("missChoose");
        String explanation = getArguments().getString("explanation", null);
        int none = getArguments().getInt("none", 0);

        Map<String, String> choose = null;
        Map<String, String> missChoose = null;
        //インスタンス化
        ObjectMapper mapper = new ObjectMapper();

        try {
            // jsonからmapに変換
            choose = mapper.readValue(jsonChoose, new TypeReference<Map<String, String>>() {
            });
            missChoose = mapper.readValue(jsonMissChoose, new TypeReference<Map<String, String>>() {
            });
        } catch (Exception e) {
            // エラー！
            e.printStackTrace();
        }

        Activity parent = getActivity();
        AlertDialog.Builder builder = new AlertDialog.Builder(parent);
        TextView titleView = new TextView(getActivity());
        titleView.setText(R.string.pastTitle);
        titleView.setTextSize(24);
        titleView.setTextColor(Color.WHITE);
        titleView.setGravity(Gravity.CENTER);
        titleView.setPadding(20, 20, 20, 20);
        if(missChoose == null && none != 1){
            //正解だった場合
            titleView.setBackgroundColor(getResources().getColor(R.color.alertRed));
        }else if(none == 1){
            //解いていない問題だった場合
            titleView.setBackgroundColor(getResources().getColor(R.color.alertGlay));
        }else{
            titleView.setBackgroundColor(getResources().getColor(R.color.alertBlue));
        }
        builder.setCustomTitle(titleView);

        textQuestion.setText(question);
        reply(choose, missChoose);
        textReply.setText(R.string.dialog_answer);
        if(missChoose != null){
            //間違えた場合
            myReply(missChoose);
            textMyReply.setText(R.string.dialog_myanswer);
        }else{
            textMyReply.setVisibility(View.GONE);
            border.setVisibility(View.GONE);
        }

        /**
         * 省略制御
         */
        textExplanation.setText(explanation);
        textQuestion.setOnClickListener((View v) -> {
            if(questionFlg == 0){
                textQuestion.setSingleLine(false);
                questionFlg = 1;
            }else{
                textQuestion.setSingleLine(true);
                questionFlg = 0;
            }
        });
        textReplyAnswerA.setOnClickListener((View v) -> {
            if(replyAFlg == 0){
                textReplyAnswerA.setSingleLine(false);
                replyAFlg = 1;
            }else{
                textReplyAnswerA.setSingleLine(true);
                replyAFlg = 0;
            }
        });
        textReplyAnswerB.setOnClickListener((View v) -> {
            if(replyBFlg == 0){
                textReplyAnswerB.setSingleLine(false);
                replyBFlg = 1;
            }else{
                textReplyAnswerB.setSingleLine(true);
                replyBFlg = 0;
            }
        });
        textReplyAnswerC.setOnClickListener((View v) -> {
            if(replyCFlg == 0){
                textReplyAnswerC.setSingleLine(false);
                replyCFlg = 1;
            }else{
                textReplyAnswerC.setSingleLine(true);
                replyCFlg = 0;
            }
        });
        textReplyAnswerD.setOnClickListener((View v) -> {
            if(replyDFlg == 0){
                textReplyAnswerD.setSingleLine(false);
                replyDFlg = 1;
            }else{
                textReplyAnswerD.setSingleLine(true);
                replyDFlg = 0;
            }
        });
        textReplyAnswerE.setOnClickListener((View v) -> {
            if(replyEFlg == 0){
                textReplyAnswerE.setSingleLine(false);
                replyEFlg = 1;
            }else{
                textReplyAnswerE.setSingleLine(true);
                replyEFlg = 0;
            }
        });
        textReplyAnswerF.setOnClickListener((View v) -> {
            if(replyFFlg == 0){
                textReplyAnswerF.setSingleLine(false);
                replyFFlg = 1;
            }else{
                textReplyAnswerF.setSingleLine(true);
                replyFFlg = 0;
            }
        });
        textReplyAnswerG.setOnClickListener((View v) -> {
            if(replyGFlg == 0){
                textReplyAnswerG.setSingleLine(false);
                replyGFlg = 1;
            }else{
                textReplyAnswerG.setSingleLine(true);
                replyGFlg = 0;
            }
        });
        myReplyAnswerA.setOnClickListener((View v) -> {
            if(myReplyAFlg == 0){
                myReplyAnswerA.setSingleLine(false);
                myReplyAFlg = 1;
            }else{
                myReplyAnswerA.setSingleLine(true);
                myReplyAFlg = 0;
            }
        });
        myReplyAnswerB.setOnClickListener((View v) -> {
            if(myReplyBFlg == 0){
                myReplyAnswerB.setSingleLine(false);
                myReplyBFlg = 1;
            }else{
                myReplyAnswerB.setSingleLine(true);
                myReplyBFlg = 0;
            }
        });
        myReplyAnswerC.setOnClickListener((View v) -> {
            if(myReplyCFlg == 0){
                myReplyAnswerC.setSingleLine(false);
                myReplyCFlg = 1;
            }else{
                myReplyAnswerC.setSingleLine(true);
                myReplyCFlg = 0;
            }
        });
        myReplyAnswerD.setOnClickListener((View v) -> {
            if(myReplyDFlg == 0){
                myReplyAnswerD.setSingleLine(false);
                myReplyDFlg = 1;
            }else{
                myReplyAnswerD.setSingleLine(true);
                myReplyDFlg = 0;
            }
        });
        myReplyAnswerE.setOnClickListener((View v) -> {
            if(myReplyEFlg == 0){
                myReplyAnswerE.setSingleLine(false);
                myReplyEFlg = 1;
            }else{
                myReplyAnswerE.setSingleLine(true);
                myReplyEFlg = 0;
            }
        });
        myReplyAnswerF.setOnClickListener((View v) -> {
            if(myReplyFFlg == 0){
                myReplyAnswerF.setSingleLine(false);
                myReplyFFlg = 1;
            }else{
                myReplyAnswerF.setSingleLine(true);
                myReplyFFlg = 0;
            }
        });
        myReplyAnswerG.setOnClickListener((View v) -> {
            if(myReplyGFlg == 0){
                myReplyAnswerG.setSingleLine(false);
                myReplyGFlg = 1;
            }else{
                myReplyAnswerG.setSingleLine(true);
                myReplyGFlg = 0;
            }
        });
        textExplanation.setOnClickListener((View v) -> {
            if(explanationFlg == 0){
                textExplanation.setSingleLine(false);
                explanationFlg = 1;
            }else{
                textExplanation.setSingleLine(true);
                explanationFlg = 0;
            }
        });
        builder.setView(view);

        builder.setNeutralButton(R.string.btnCancel, new DialogButtonClickListener());
        return builder.create();
    }

    /**
     * ダイアログのボタンが押されたときの処理が記述されたメンバクラス。
     */
    private class DialogButtonClickListener implements DialogInterface.OnClickListener{
        @Override
        public void onClick(DialogInterface dialog, int which){
        }
    }

    /**
     * 答えの出力処理
     * @param reply
     */
    private void reply(Map<String, String> reply, Map<String, String> myReply){
        //非表示処理
        int replyCount = 0;
        if(reply.size() < 7){
            textReplyAnswerG.setVisibility(View.GONE);
            dialogChooseG.setVisibility(View.GONE);
        }
        if(reply.size() < 6){
            textReplyAnswerF.setVisibility(View.GONE);
            dialogChooseF.setVisibility(View.GONE);
        }
        if(reply.size() < 5){
            textReplyAnswerE.setVisibility(View.GONE);
            dialogChooseE.setVisibility(View.GONE);
        }
        if(reply.size() < 4){
            textReplyAnswerD.setVisibility(View.GONE);
            dialogChooseD.setVisibility(View.GONE);
        }
        if(reply.size() < 3){
            textReplyAnswerC.setVisibility(View.GONE);
            dialogChooseC.setVisibility(View.GONE);
        }
        if(reply.size() < 2){
            textReplyAnswerB.setVisibility(View.GONE);
            dialogChooseB.setVisibility(View.GONE);
        }
        if(myReply == null){
            myReplyAnswerA.setVisibility(View.GONE);
            myReplyAnswerB.setVisibility(View.GONE);
            myReplyAnswerC.setVisibility(View.GONE);
            myReplyAnswerD.setVisibility(View.GONE);
            myReplyAnswerE.setVisibility(View.GONE);
            myReplyAnswerF.setVisibility(View.GONE);
            myReplyAnswerG.setVisibility(View.GONE);
            dialogMyChooseA.setVisibility(View.GONE);
            dialogMyChooseB.setVisibility(View.GONE);
            dialogMyChooseC.setVisibility(View.GONE);
            dialogMyChooseD.setVisibility(View.GONE);
            dialogMyChooseE.setVisibility(View.GONE);
            dialogMyChooseF.setVisibility(View.GONE);
            dialogMyChooseG.setVisibility(View.GONE);
        }

        //回答を表示する処理
        for (Map.Entry<String, String> entry : reply.entrySet()) {
            if(entry.getKey().equals("")){
                dialogChoose.get(replyCount).setText(entry.getValue());
            }else{
                dialogChooseAnswer.get(replyCount).setText(entry.getValue());
                dialogChoose.get(replyCount).setText(entry.getKey());
            }
            replyCount++;
        }
    }

    /**
     * 自分の回答の出力処理
     * @param myReply
     */
    private void myReply(Map<String, String> myReply){
        //非表示処理
        int myReplyCount = 0;
        if(myReply.size() < 7){
            myReplyAnswerG.setVisibility(View.GONE);
            dialogMyChooseG.setVisibility(View.GONE);
        }
        if(myReply.size() < 6){
            myReplyAnswerF.setVisibility(View.GONE);
            dialogMyChooseF.setVisibility(View.GONE);
        }
        if(myReply.size() < 5){
            myReplyAnswerE.setVisibility(View.GONE);
            dialogMyChooseE.setVisibility(View.GONE);
        }
        if(myReply.size() < 4){
            myReplyAnswerD.setVisibility(View.GONE);
            dialogMyChooseD.setVisibility(View.GONE);
        }
        if(myReply.size() < 3){
            myReplyAnswerC.setVisibility(View.GONE);
            dialogMyChooseC.setVisibility(View.GONE);
        }
        if(myReply.size() < 2){
            myReplyAnswerB.setVisibility(View.GONE);
            dialogMyChooseB.setVisibility(View.GONE);
        }

        //回答を表示する処理
        for (Map.Entry<String, String> entry : myReply.entrySet()) {
            if(entry.getKey().equals("")){
                dialogMyChoose.get(myReplyCount).setText(entry.getValue());
            }else{
                dialogMyChooseAnswer.get(myReplyCount).setText(entry.getValue());
                dialogMyChoose.get(myReplyCount).setText(entry.getKey());
            }
            myReplyCount++;
        }
    }
}

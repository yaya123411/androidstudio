package local.hal.st31.android.studyapplication3.Database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;

public class CanvasDAO {
    /**
     * 特定のメモ帳に保存してあるキャンパス情報を取得
     * @param db
     * @param memoId
     * @return
     */
    public static ArrayList<Canvas> findIdByPK(SQLiteDatabase db, long memoId) {
        ArrayList<Canvas> arrayList = new ArrayList<Canvas>();
        String sql = "SELECT * FROM canvas WHERE memoId = '" + memoId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        Canvas result = null;
        for (int i = 0; i < cursor.getCount(); i++) {
            int idxStartGetX = cursor.getColumnIndex("startGetX");
            String startGetX = cursor.getString(idxStartGetX);
            int idxStartGetY = cursor.getColumnIndex("startGetY");
            String startGetY = cursor.getString(idxStartGetY);
            int idxFinishGetX = cursor.getColumnIndex("finishGetX");
            String finishGetX = cursor.getString(idxFinishGetX);
            int idxFinishGetY = cursor.getColumnIndex("finishGetY");
            String finishGetY = cursor.getString(idxFinishGetY);
            int idxColor = cursor.getColumnIndex("color");
            String color = cursor.getString(idxColor);

            result = new Canvas();
            result.setMemoId(memoId);
            result.setStartGetX(Float.parseFloat(startGetX));
            result.setStartGetY(Float.parseFloat(startGetY));
            result.setFinishGetX(Float.parseFloat(finishGetX));
            result.setFinishGetY(Float.parseFloat(finishGetY));
            result.setColor(Integer.parseInt(color));
            arrayList.add(result);
            cursor.moveToNext();
        }
        return arrayList;
    }

    /**
     * キャンパスデータを追加するメソッド
     * @param db
     * @param memoId
     * @param startGetX
     * @param startGetY
     * @param finishGetX
     * @param finishGetY
     * @param color
     * @return
     */
    public static long insert(SQLiteDatabase db, long memoId, float startGetX, float startGetY, float finishGetX, float finishGetY, Integer color) {
        String canvasSql = "INSERT INTO canvas (memoId, startGetX, startGetY, finishGetX, finishGetY, color) VALUES (?, ?, ?, ?, ?, ?)";
        SQLiteStatement canvasStmt = db.compileStatement(canvasSql);
        canvasStmt.bindLong(1, memoId);
        canvasStmt.bindString(2, String.valueOf(startGetX));
        canvasStmt.bindString(3, String.valueOf(startGetY));
        canvasStmt.bindString(4, String.valueOf(finishGetX));
        canvasStmt.bindString(5, String.valueOf(finishGetY));
        canvasStmt.bindString(6, String.valueOf(color));
        long insertedId = canvasStmt.executeInsert();
        return insertedId;
    }

    /**
     * キャンパスデータを変更するメソッド
     * @param db
     * @param memoId
     * @param color
     * @return
     */
    public static long update(SQLiteDatabase db, long memoId, float startGetX, float startGetY, float finishGetX, float finishGetY, Integer color){
        String canvasSql = "INSERT INTO canvas (memoId, startGetX, startGetY, finishGetX, finishGetY, color) VALUES (?, ?, ?, ?, ?, ?)";
        SQLiteStatement canvasStmt = db.compileStatement(canvasSql);
        canvasStmt.bindLong(1, memoId);
        canvasStmt.bindString(2, String.valueOf(startGetX));
        canvasStmt.bindString(3, String.valueOf(startGetY));
        canvasStmt.bindString(4, String.valueOf(finishGetX));
        canvasStmt.bindString(5, String.valueOf(finishGetY));
        canvasStmt.bindString(6, String.valueOf(color));
        long insertedId = canvasStmt.executeInsert();
        return insertedId;
    }

    /**
     * キャンバスを削除するメソッド
     * @param db
     * @param memoId
     * @return
     */
    public static int delete(SQLiteDatabase db, long memoId) {
        String sql = "DELETE FROM canvas WHERE memoId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, memoId);
        int result = stmt.executeUpdateDelete();
        return result;
    }
}

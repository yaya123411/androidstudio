package local.hal.st31.android.studyapplication3.ui.download;

import static android.app.Activity.RESULT_OK;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.ParcelFileDescriptor;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;

import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Pattern;

import local.hal.st31.android.studyapplication3.Database.CorrectSolutionProblemDAO;
import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.FlashcardDAO;
import local.hal.st31.android.studyapplication3.Database.FlashcardInterrupt;
import local.hal.st31.android.studyapplication3.Database.FlashcardInterruptDAO;
import local.hal.st31.android.studyapplication3.Database.FlashcardTitle;
import local.hal.st31.android.studyapplication3.Database.FlashcardTitleDAO;
import local.hal.st31.android.studyapplication3.Database.GradesDAO;
import local.hal.st31.android.studyapplication3.Database.MistakeProblemDAO;
import local.hal.st31.android.studyapplication3.Database.ProblemDAO;
import local.hal.st31.android.studyapplication3.Database.ProblemInterrupt;
import local.hal.st31.android.studyapplication3.Database.ProblemInterruptDAO;
import local.hal.st31.android.studyapplication3.Database.TitleList;
import local.hal.st31.android.studyapplication3.Database.TitleListDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.OCR;
import local.hal.st31.android.studyapplication3.ui.home.Flashcard.FlashcardFragment;
import local.hal.st31.android.studyapplication3.ui.home.Flashcard.FlashcardListFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemMake.ProblemAddFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemQuestion.ProblemFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemQuestion.ProblemTopFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link DownloadFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class DownloadFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    private int formulaFlg = 0;
    //任意の識別番号
    private static final int REQUEST_CODE = 12345;
    //ocr
    private static final int REQUEST_CODE_PICK_CONTENT = 0;
    private OCR _ocr;
    private AlertDialog alertDialog;
    private EditText editResult;
    private int changeFlg = 0;
    public TextView textResult;
    View view;

    //フラグメントを呼び出す
    public static DownloadFragment newInstance(){
        DownloadFragment DownloadFragment = new DownloadFragment();

        return DownloadFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        editor.putString("menu", "");
        editor.commit();

        View view = inflater.inflate(R.layout.fragment_download,
                container, false);

        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        return view;
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        _ocr = new OCR(getActivity().getApplicationContext());
    }

    @Override
    public void onResume() {
        super.onResume();

        Switch shareFormulaSwitch = view.findViewById(R.id.downloadFormulaSwitch);
        shareFormulaSwitch.setChecked(false);
        shareFormulaSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            TextView downloadTitle = view.findViewById(R.id.downloadTitle);
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    //スイッチがオンの時
                    formulaFlg = 1;
                    if(changeFlg == 0){
                        //問題切り替えボタンが押されていた場合
                        problemList(1);
                    }else{
                        //単語帳切り替えボタンが押されていた場合
                        flashcardList(1);
                    }
                    downloadTitle.setText("公式");
                } else {
                    //スイッチがオフの時
                    formulaFlg = 0;
                    if(changeFlg == 0){
                        //問題切り替えボタンが押されていた場合
                        problemList(0);
                    }else{
                        //単語帳切り替えボタンが押されていた場合
                        flashcardList(0);
                    }
                    downloadTitle.setText("非公式");
                }
            }
        });

        Button changeButton = view.findViewById(R.id.changeButton);
        TextView changeText = view.findViewById(R.id.downloadModeTitle);
        changeButton.setOnClickListener((View v) -> {
            //切り替えボタンが押された場合
            if(changeFlg == 0){
                //単語帳一覧ボタンが押された場合
                changeText.setText("単語帳一覧");
                changeButton.setText("問題一覧に切り替え");
                flashcardList(formulaFlg);
                changeFlg = 1;
            }else{
                //問題ボタンが押された場合
                problemList(formulaFlg);
                changeText.setText("問題一覧");
                changeButton.setText("単語帳に切り替え");
                changeFlg = 0;
            }
        });
        problemList(0);
    }

    /**
     * ダイアログで問題のタイトルを追加or変更する
     * @param idNo 追加or変更を識別(追加＝0、変更＝1以上) 変更の場合は変更する行のIDが入る
     */
    public void FlashcardTitleEditDialog(long idNo){
        //ダイアログ作成
        //データベース接続
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_problem_title, null, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        textResult = dialogView.findViewById(R.id.textResult);
        editResult = dialogView.findViewById(R.id.editResult);
        builder.setView(dialogView);

        textResult.setVisibility(View.INVISIBLE);
        editResult.setVisibility(View.GONE);

        TextView dialogProblemBtnAdd = dialogView.findViewById(R.id.dialogProblemBtnAdd);
        TextView btnCansel = dialogView.findViewById(R.id.btnCansel);
        TextView textFlashcardTitle = dialogView.findViewById(R.id.textFlashcardTitle);
        EditText etProblemTitle = dialogView.findViewById(R.id.etFlashcardTitle);
        EditText etEditTime = dialogView.findViewById(R.id.etEditTime);

        TitleList result = TitleListDAO.findIdByPK(db, idNo);
        etProblemTitle.setText(result.getTitle());
        etEditTime.setText(result.getTime());
        dialogProblemBtnAdd.setText(R.string.btnEdit);
        textFlashcardTitle.setText(R.string.textProblemEdit);

        //ダイアログ出力
        alertDialog = builder.show();

        dialogProblemBtnAdd.setOnClickListener(parts -> {
            //追加ボタンが押された場合
            int flg = 0;
            String msg = "";

            String strTitle = etProblemTitle.getText().toString();
            String strEditTime = etEditTime.getText().toString();

            if(strTitle.equals("")){
                etProblemTitle.setError("値を入力してください");
                flg = 1;
            }else{
                flg = 0;
            }
            if(strTitle.equals("")){
                etProblemTitle.setError("値を入力してください");
                flg = 1;
            }
            if(strEditTime.contains(":")){
                etEditTime.setError("不要な文字列が含まれています「:」");
                flg = 1;
            }else if(!Pattern.matches("^-?[0-9]*.?[0-9]+$", strEditTime)){
                etEditTime.setError("数字以外が入力されています");
                flg = 1;
            }

            if(flg == 0){
                //入力チェックがOKだった場合
                //保存領域をオープンさせる
                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = myPrefs.edit();

                int formula = FlashcardTitleDAO.formulaMarkFindByTitldId(db, idNo);
                TitleListDAO.update(db, myPrefs.getLong("titleId",0), strTitle, Integer.parseInt(strEditTime));
                msg = "変更しました";

                Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                if(changeFlg == 0){
                    problemList(formula);
                }
                alertDialog.dismiss();
            }
        });
        btnCansel.setOnClickListener(parts -> {
            //キャンセルボタンが押された場合
            alertDialog.dismiss();
        });
    }

    /**
     * 問題のリストがクリックされた時のリスナクラス
     */
    private class ProblemListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            Cursor item = (Cursor) parent.getItemAtPosition(position);
            int idxId = item.getColumnIndex("_id");
            long idNo = item.getLong(idxId);

            //データベース接続
            _helper = new DatabaseHelper(getActivity());
            SQLiteDatabase db = _helper.getWritableDatabase();

            //タイトルIDを保存する
            SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = myPrefs.edit();

            editor.putLong("titleId", idNo);
            editor.commit();

            String count = ProblemDAO.countProblem(db, id);

            if(Integer.parseInt(count) == 0){
                //問題が登録されていない場合
                Toast.makeText(getActivity(), R.string.textProblemQuestionErrMsg, Toast.LENGTH_SHORT).show();
            }else{
                editor.putLong("titleId", idNo);
                editor.commit();

                //始めようとしている単語帳が中断している単語帳であるかを調べる
                ProblemInterrupt result = null;
                try {
                    result = ProblemInterruptDAO.findIdByPK(db, myPrefs.getLong("titleId",0));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                if(result == null){
                    //中断データがなかった場合
                    editor.putInt("downloadFlg", 1);
                    editor.commit();
                    migrate(ProblemTopFragment.newInstance(idNo));
                }else {
                    //ダイアログ生成
                    AlertDialog.Builder mydialog = new AlertDialog.Builder(getActivity());
                    mydialog.setTitle(R.string.flashcardDialogMsg);
                    TextView textMsg = new TextView(getActivity());

                    textMsg.setText(Integer.parseInt(result.getPage()) + "/" + count + "\n" + result.getUpdateTime());
                    textMsg.setGravity(Gravity.CENTER);
                    textMsg.setTextSize(16);
                    mydialog.setView(textMsg);

                    String[] choices = {};
                    choices = new String[]{"続きから", "最初から", "キャンセル"};

                    ProblemInterrupt finalResult = result;
                    mydialog.setItems(choices, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //問題数
                            editor.putString("count", count);
                            if (which == 0) {
                                //続きからを選択した場合
                                //回答を代入するjsonデータを送る
                                editor.putString("reply", finalResult.getJson());
                                //現在のページ
                                editor.putInt("now", Integer.parseInt(finalResult.getPage())-1);
                                editor.putString("count", count);
//                                editor.putInt("time", finalResult.getTime());
                                editor.putLong("alltime", (long) (finalResult.getTime() * 1000 * 60));
                                editor.putInt("downloadFlg", 1);
                                editor.commit();

                                //問題リストを取得
                                ArrayList<String> problemList = ProblemDAO.ProblemIdAll(db, myPrefs.getLong("titleId",0));
                                migrate(ProblemFragment.newInstance(problemList, Long.parseLong(String.valueOf(0)), 0));
                            } else if(which == 1) {
                                //最初からを選択した場合
                                editor.putInt("downloadFlg", 1);
                                editor.commit();
                                migrate(ProblemTopFragment.newInstance(idNo));
                            }
                        }
                    });
                    mydialog.show();
                }
            }
        }
    }

    /**
     * 単語帳のリストがクリックされた時のリスナクラス
     */
    private class FlashcardListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            Cursor item = (Cursor) parent.getItemAtPosition(position);
            int idxId = item.getColumnIndex("_id");
            long idNo = item.getLong(idxId);

            //保存領域に接続
            SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = myPrefs.edit();

            editor.putLong("titleId", idNo);
            editor.putLong("downloadId", idNo);
            editor.commit();

            //データベース接続
            _helper = new DatabaseHelper(getActivity());
            SQLiteDatabase db = _helper.getWritableDatabase();

            //単語数を取得
            String count = FlashcardDAO.countFlashcard(db, idNo, myPrefs.getInt("rememberFlg",0));

            //始めようとしている単語帳が中断している単語帳であるかを調べる
            FlashcardInterrupt result = null;
            try {
                result = FlashcardInterruptDAO.findIdByPK(db, myPrefs.getLong("titleId",0));
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if(result == null){
                //始めようとしている単語帳が中断している単語帳ではない場合
                if(Integer.parseInt(count) == 0){
                    //単語が追加されていない場合
                    Toast.makeText(getActivity(), "単語が追加されていません", Toast.LENGTH_SHORT).show();
                }else{
                    LayoutInflater inflater = getActivity().getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.dialog_setting, null, false);
                    //ダイアログ作成
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setView(dialogView);

                    Switch automaticSwitch = dialogView.findViewById(R.id.automaticSwitch);
                    Switch rememberSwitch = dialogView.findViewById(R.id.rememberSwitch);

                    editor.putInt("automaticFlg", 0);
                    editor.putInt("rememberFlg", 0);
                    editor.commit();

                    //チェックボックスが押された場合
                    automaticSwitch.setOnClickListener(parts -> {
                        if (automaticSwitch.isChecked()) {
                            //チェック入れた場合
                            editor.putInt("automaticFlg", 1);
                        } else {
                            //チェック外した場合
                            editor.putInt("automaticFlg", 0);
                        }
                        editor.commit();
                    });

                    //チェックボックスが押された場合
                    rememberSwitch.setOnClickListener(parts -> {
                        if (rememberSwitch.isChecked()) {
                            //チェック入れた場合
                            editor.putInt("rememberFlg", 1);
                        } else {
                            //チェック外した場合
                            editor.putInt("rememberFlg", 0);
                        }
                        editor.commit();
                    });

                    builder.setPositiveButton(R.string.btnStart, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //ダイアログのスタートボタンが押された場合
                            //単語数を取得
                            String count = FlashcardDAO.countFlashcard(db, idNo, myPrefs.getInt("rememberFlg",0));
                            if(Integer.parseInt(count) == 0){
                                //単語が全て覚えたにチェックが付けられている場合
                                Toast.makeText(getActivity(), "全て暗記済みです", Toast.LENGTH_SHORT).show();
                            }else{
                                ArrayList<String> flashcardId = FlashcardDAO.flashcardIdAll(db, myPrefs.getLong("titleId",0), myPrefs.getInt("rememberFlg",0));
                                //問題数
                                editor.putString("count", count);
                                //現在のページ
                                editor.putInt("now", 0);
                                //ダウンロードされた問題だった場合のフラグ(ダウンロードされていた場合=1、そうでない場合=0)
                                editor.putInt("downloadFlg", 1);
                                editor.commit();

                                migrate(FlashcardFragment.newInstance(flashcardId));
                            }
                        }
                    });

                    builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });

                    //ダイアログ出力
                    builder.create().show();
                }
            }else {
                ArrayList<String> flashcardId = FlashcardDAO.flashcardIdAll(db, myPrefs.getLong("titleId",0), myPrefs.getInt("rememberFlg",0));
                FlashcardInterrupt FlashcardInterruptResult = null;
                try {
                    FlashcardInterruptResult = FlashcardInterruptDAO.findIdByPK(db, myPrefs.getLong("titleId",0));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                //ダイアログ生成
                AlertDialog.Builder mydialog = new AlertDialog.Builder(getActivity());
                mydialog.setTitle(R.string.flashcardDialogMsg);
                TextView textMsg = new TextView(getActivity());

                textMsg.setText(Integer.parseInt(FlashcardInterruptResult.getPage())+1 + "/" + count + "\n" + FlashcardInterruptResult.getUpdateTime());
                textMsg.setGravity(Gravity.CENTER);
                textMsg.setTextSize(16);
                mydialog.setView(textMsg);

                String[] choices = {};
                choices = new String[]{"続きから", "最初から", "キャンセル"};

                FlashcardInterrupt finalFlashcardInterruptResult = FlashcardInterruptResult;
                mydialog.setItems(choices, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //問題数
                        editor.putString("count", count);
                        if (which == 0) {
                            //続きからを選択した場合
                            editor.putInt("rememberFlg", finalFlashcardInterruptResult.getSettingRememberFlg());
                            //現在のページ
                            editor.putInt("now", Integer.parseInt(finalFlashcardInterruptResult.getPage()));
                            //ダウンロードされた問題だった場合のフラグ(ダウンロードされていた場合=1、そうでない場合=0)
                            editor.putInt("downloadFlg", 1);
                            editor.commit();

//                                        back();
                            migrate(FlashcardFragment.newInstance(flashcardId));
                        } else if(which == 1) {
                            //最初からを選択した場合
                            //現在のページ
                            editor.putInt("now", 0);
                            //ダウンロードされた問題だった場合のフラグ(ダウンロードされていた場合=1、そうでない場合=0)
                            editor.putInt("downloadFlg", 1);
                            editor.commit();

//                                        back();
                            migrate(FlashcardFragment.newInstance(flashcardId));
                        }
                    }
                });
                mydialog.show();
            }
        }
    }

    /**
     * 問題のリストビューのカスタムビューバインダークラス。
     */
    private class ProblemCustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch(view.getId()) {
                case R.id.uploadImage:
                    ImageView updoad = (ImageView)view;
                    updoad.setVisibility(View.INVISIBLE);
                    return true;
                case R.id.edit:
                    ImageView edit = (ImageView)view;
                    long id = Long.parseLong(cursor.getString(columnIndex));

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)edit.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)edit.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }

                    edit.setOnClickListener((View v) -> {
                        //編集ボタンが押された場合
                        String[] choices = new String[]{"タイトル編集", "問題一覧"};

                        //ダイアログ作成
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setItems(choices, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if(which == 0){
                                    //タイトル編集ボタンが押された場合
                                    FlashcardTitleEditDialog(id);
                                }else if(which == 1){
                                    //問題一覧ボタンが押された場合
                                    SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                                    SharedPreferences.Editor editor = myPrefs.edit();
                                    editor.putLong("titleId", id);
                                    editor.commit();
                                    migrate(ProblemAddFragment.newInstance());
                                }
                            }
                        });
                        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        //ダイアログ出力
                        builder.show();
                    });
                    return true;
                case R.id.btnDelete:
                    ImageView deleteBtn = (ImageView)view;
                    id = Long.parseLong(cursor.getString(columnIndex));
                    deleteBtn.setOnClickListener((View v) -> {
                        //削除ボタンが押された場合
                        LayoutInflater inflater = getActivity().getLayoutInflater();
                        View dialogView = inflater.inflate(R.layout.dialog_delete_check, null, false);
                        //ダイアログ作成
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setView(dialogView);

                        builder.setPositiveButton(R.string.dialogDeleteTitle, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                _helper = new DatabaseHelper(getActivity());
                                SQLiteDatabase db = _helper.getWritableDatabase();
                                String msg = "";

                                //問題タイトルを削除
                                TitleListDAO.delete(db, id);
                                //問題を削除
                                ProblemDAO.problemTitledelete(db, id);
                                //中間履歴があれば削除
                                ProblemInterruptDAO.deleteByDownloadId(db, id);
                                //成績を削除する
                                GradesDAO.delete(db, id);
                                //正解の成績を削除する
                                CorrectSolutionProblemDAO.deleteByTitleId(db, id);
                                //不正解の成績を削除する
                                MistakeProblemDAO.deleteByTitleId(db, id);

                                if(changeFlg == 0){
                                    //問題切り替えが押されていた場合
                                    if(formulaFlg == 0){
                                        //公式のスイッチがoffの場合
                                        problemList(0);
                                    }else{
                                        problemList(1);
                                    }
                                }
                                msg = "削除が完了しました";
                                Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                            }
                        });

                        builder.setNeutralButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });

                        //ダイアログ出力
                        builder.create().show();
                    });

                    return true;
            }
            return false;
        }
    }

    /**
     * 単語帳のリストビューのカスタムビューバインダークラス。
     */
    private class FlashcardCustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch(view.getId()) {
                case R.id.uploadImage:
                    ImageView updoad = (ImageView)view;
                    updoad.setVisibility(View.INVISIBLE);
                    return true;
                case R.id.edit:
                    ImageView edit = (ImageView)view;
                    long id = Long.parseLong(cursor.getString(columnIndex));

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)edit.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)edit.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }

                    edit.setOnClickListener((View v) -> {
                        //編集ボタンが押された場合
                        String[] choices = new String[]{"タイトル編集", "単語帳一覧"};

                        //ダイアログ作成
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setItems(choices, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if(which == 0){
                                    //タイトル編集が押された場合
                                    //データベース接続
                                    _helper = new DatabaseHelper(getActivity());
                                    SQLiteDatabase db = _helper.getWritableDatabase();

                                    //ダイアログ作成
                                    LayoutInflater inflater = getActivity().getLayoutInflater();
                                    View dialogView = inflater.inflate(R.layout.dialog_flashcard_title, null, false);
                                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                    builder.setView(dialogView);

                                    EditText etFlashcardTitle = dialogView.findViewById(R.id.etFlashcardTitle);
                                    editResult = dialogView.findViewById(R.id.editResult);
                                    TextView dialogFlashcardBtnAdd = dialogView.findViewById(R.id.dialogProblemBtnAdd);
                                    textResult = dialogView.findViewById(R.id.textResult);

                                    //音声、ocr結果を非表示
                                    textResult.setVisibility(View.INVISIBLE);
                                    editResult.setVisibility(View.GONE);

                                    if(id != 0){
                                        //タイトル編集ボタンが押された場合
                                        FlashcardTitle result = FlashcardTitleDAO.findIdByPK(db, id);
                                        TextView textDialogProblemTitle = dialogView.findViewById(R.id.textFlashcardTitle);

                                        textDialogProblemTitle.setText("タイトル編集");
                                        dialogFlashcardBtnAdd.setText(R.string.btnEdit);
                                        etFlashcardTitle.setText(result.getTitle());
                                    }
                                    TextView btnCansel = dialogView.findViewById(R.id.btnCansel);

                                    //ダイアログ出力
                                    alertDialog = builder.show();

                                    dialogFlashcardBtnAdd.setOnClickListener(parts -> {
                                        //追加or変更ボタンが押された場合
                                        String msg = "";
                                        int flg = 0;
                                        String strTitle = etFlashcardTitle.getText().toString();
                                        if(strTitle.equals("")){
                                            msg = "タイトルを入力してください";
                                            flg = 1;
                                        }
                                        if(flg == 0){
                                            FlashcardTitleDAO.update(db, id, strTitle);

                                            if(changeFlg == 1){
                                                //単語帳切り替えボタンが押されていた場合
                                                if(formulaFlg == 0){
                                                    //公式のスイッチがoffの場合
                                                    flashcardList(0);
                                                }else{
                                                    flashcardList(1);
                                                }
                                            }

                                            msg = "変更しました";
                                        }
                                        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                                        alertDialog.dismiss();
                                    });
                                    btnCansel.setOnClickListener(parts -> {
                                        //キャンセルボタンが押された場合
                                        alertDialog.dismiss();
                                    });
                                }else if(which == 1){
                                    //単語帳一覧が押された場合
                                    SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                                    SharedPreferences.Editor editor = myPrefs.edit();
                                    editor.putLong("titleId", id);
                                    editor.commit();
                                    migrate(FlashcardListFragment.newInstance());
                                }
                            }
                        });
                        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        //ダイアログ出力
                        builder.show();
                    });
                    return true;
                case R.id.btnDelete:
                    ImageView deleteBtn = (ImageView)view;
                    id = Long.parseLong(cursor.getString(columnIndex));
                    deleteBtn.setOnClickListener((View v) -> {
                        //削除ボタンが押された場合
                        LayoutInflater inflater = getActivity().getLayoutInflater();
                        View dialogView = inflater.inflate(R.layout.dialog_delete_check, null, false);
                        //ダイアログ作成
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setView(dialogView);

                        builder.setPositiveButton(R.string.dialogDeleteTitle, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //削除ボタンが押された場合
                                SQLiteDatabase db = _helper.getWritableDatabase();
                                String msg = "";
                                FlashcardTitleDAO.delete(db, id);
                                FlashcardDAO.deleteByDownload(db, id);
                                //中間履歴があれば削除
                                FlashcardInterruptDAO.deleteByDownloadId(db, id);

                                if(changeFlg == 1){
                                    //単語帳切り替えボタンが押されていた場合
                                    if(formulaFlg == 0){
                                        //公式のスイッチがoffの場合
                                        flashcardList(0);
                                    }else{
                                        flashcardList(0);
                                    }
                                }
                                msg = "削除が完了しました";
                                Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                            }
                        });

                        builder.setNeutralButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });

                        //ダイアログ出力
                        builder.create().show();
                    });
                    return true;
            }
            return false;
        }
    }

    //問題リストを表示
    public void problemList(int formula){
        _helper = new DatabaseHelper(this.getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

        ListView problemList = view.findViewById(R.id.dialogReportList);
        TextView count = view.findViewById(R.id.titleCount8);
        problemList.setOnItemClickListener(new ProblemListItemClickListener());

        //問題を表示
        Cursor downloadProblemCursor = TitleListDAO.allDownload(db, myPrefs.getString("userId",""), formula);
        String[] problemFrom = {"title", "_id", "_id", "_id"};
        int[] problemTo = {R.id.uploadTitle, R.id.uploadImage, R.id.edit, R.id.btnDelete};
        SimpleCursorAdapter problemAdapter = new SimpleCursorAdapter(this.getActivity(), R.layout.upload, downloadProblemCursor, problemFrom, problemTo, 0);
        problemAdapter.setViewBinder(new ProblemCustomViewBinder());
        problemList.setAdapter(problemAdapter);
        count.setText(downloadProblemCursor.getCount() + "件検出");
    }

    //単語帳リストを表示
    public void flashcardList(int formula){
        _helper = new DatabaseHelper(this.getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

        ListView flashcardList = view.findViewById(R.id.dialogReportList);
        TextView count = view.findViewById(R.id.titleCount8);
        flashcardList.setOnItemClickListener(new FlashcardListItemClickListener());

        //単語帳を表示
        Cursor flashcardTitleList = FlashcardTitleDAO.findDownload(db, myPrefs.getString("userId",""), formula);
        String[] flashcardFrom = {"title", "_id", "_id", "_id"};
        int[] flashcardTo = {R.id.uploadTitle, R.id.uploadImage, R.id.edit, R.id.btnDelete};
        SimpleCursorAdapter flashcardAdapter = new SimpleCursorAdapter(this.getActivity(), R.layout.upload, flashcardTitleList, flashcardFrom, flashcardTo, 0);
        flashcardAdapter.setViewBinder(new FlashcardCustomViewBinder());
        flashcardList.setAdapter(flashcardAdapter);
        count.setText(flashcardTitleList.getCount() + "件検出");
    }

    //音声認識が終わると自動で呼び出されるメソッド
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        EditText result = alertDialog.findViewById(R.id.editResult);
        textResult.setVisibility(View.VISIBLE);
        editResult.setVisibility(View.VISIBLE);

        if(requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            //マイクボタンが押された場合
            //data から音声認識の結果を取り出す（リスト形式で）
            ArrayList<String> kekka = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

            //認識結果が一つ以上ある場合はテキストビューに結果を表示する
            if (kekka.size() > 0) {
                //一番最初にある認識結果を表示する
                result.setText(kekka.get(0));
            } else {
                //何らかの原因で音声認識に失敗した場合はエラーメッセージを表示
                result.setText("音声の認識に失敗しました…");
            }
        }else if(requestCode == REQUEST_CODE_PICK_CONTENT){
            //カメラボタンの写真を選択するボタンが押された場合
            String ocrString;
            if(resultCode == RESULT_OK && data != null){
                Bitmap bitmap = null;
                if(Build.VERSION.SDK_INT < 19){
                    try{
                        InputStream in = getActivity().getContentResolver().openInputStream(data.getData());
                        bitmap = BitmapFactory.decodeStream(in);
                        try{
                            if(in != null){ in.close(); }
                        }catch(IOException e){
                            e.printStackTrace();
                        }
                    }catch(FileNotFoundException e){
                        e.printStackTrace();
                    }
                }else{
                    Uri uri = data.getData();
                    try{
                        ParcelFileDescriptor parcelFileDescriptor = getActivity().getContentResolver().openFileDescriptor(uri, "r");
                        if(parcelFileDescriptor != null){
                            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
                            bitmap = BitmapFactory.decodeFileDescriptor(fileDescriptor);
                            parcelFileDescriptor.close();
                        }

                    }catch(IOException e){
                        e.printStackTrace();
                    }
                }
                if(bitmap != null){
                    ocrString = _ocr.getString(getActivity().getApplicationContext(), bitmap);
                }else{
                    ocrString = "bitmap is null";
                }
            }else{
                ocrString = "something wrong?";
            }
            result.setText(ocrString);
        }
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}
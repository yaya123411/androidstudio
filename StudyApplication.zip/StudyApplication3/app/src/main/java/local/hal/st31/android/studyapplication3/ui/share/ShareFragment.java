package local.hal.st31.android.studyapplication3.ui.share;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.UiThread;
import androidx.appcompat.app.AlertDialog;
import androidx.core.os.HandlerCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.FlashcardDAO;
import local.hal.st31.android.studyapplication3.Database.FlashcardTitle;
import local.hal.st31.android.studyapplication3.Database.FlashcardTitleDAO;
import local.hal.st31.android.studyapplication3.Database.MemoDAO;
import local.hal.st31.android.studyapplication3.Database.ProblemDAO;
import local.hal.st31.android.studyapplication3.Database.TitleList;
import local.hal.st31.android.studyapplication3.Database.TitleListDAO;
import local.hal.st31.android.studyapplication3.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ShareFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ShareFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    private int formulaFlg = 0;
    private View view;
    /**
     * ログに記載するタグ用の文字列。
     */
    protected static final String DEBUG_TAG = "Post2DB";
    /**
     * post先のURL。
     */
    private static final String FLASHCARD_URL = "http://yaya8976.php.xdomain.jp/android/studyApplication/flashcard.php";
    private static final String PROBLEM_URL = "http://yaya8976.php.xdomain.jp/android/studyApplication/problem.php";
    private List<Map<String, String>> flashcardTitleList = new ArrayList<>();
    private List<Map<String, String>> flashcardList = new ArrayList<>();
    private List<Map<String, String>> problemTitleList = new ArrayList<>();
    private List<Map<String, String>> problemList = new ArrayList<>();
    private int listPosition;
    private int changeFlg = 0;
    private Map<String, Integer> listCount = new HashMap<>();
    private Map<String, Integer> childCount = new HashMap<>();

    //フラグメントを呼び出す
    public static ShareFragment newInstance(){
// Fragemnt01 インスタンス生成
        ShareFragment ShareFragment = new ShareFragment();

        return ShareFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        editor.putString("menu", "共有");
        editor.commit();
        setHasOptionsMenu(true);

        View view = inflater.inflate(R.layout.fragment_share,
                container, false);

        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        return view;
    }

    //メニューが押された場合
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        boolean returnVal = true;
        int itemId = item.getItemId();
        switch(itemId) {
            case R.id.menuReload:
                reload();
                break;
        }
        return returnVal;
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;
    }

    @Override
    public void onResume() {
        super.onResume();
        Switch shareFormulaSwitch = view.findViewById(R.id.shareFormulaSwitch);
        shareFormulaSwitch.setChecked(false);
        shareFormulaSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            TextView shareTitle = view.findViewById(R.id.shareTitle);
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    formulaFlg = 1;
                    if(changeFlg == 0){
                        //問題切り替えボタンが押されていた場合
                        problemList(1);
                    }else{
                        //単語帳切り替えボタンが押されていた場合
                        flashcardList(1);
                    }
                    shareTitle.setText("公式");
                } else {
                    formulaFlg = 0;
                    if(changeFlg == 0){
                        //問題切り替えボタンが押されていた場合
                        problemList(0);
                    }else{
                        //単語帳切り替えボタンが押されていた場合
                        flashcardList(0);
                    }
                    shareTitle.setText("非公式");
                }
            }
        });

        Button changeButton = view.findViewById(R.id.changeButton);
        TextView changeText = view.findViewById(R.id.downloadTitle);
        changeButton.setOnClickListener((View v) -> {
            //切り替えボタンが押された場合
            if(changeFlg == 0){
                //単語帳一覧ボタンが押された場合
                changeText.setText("単語帳一覧");
                changeButton.setText("問題一覧に切り替え");
                flashcardList(formulaFlg);
                changeFlg = 1;
            }else{
                //問題ボタンが押された場合
                problemList(formulaFlg);
                changeText.setText("問題一覧");
                changeButton.setText("単語帳に切り替え");
                changeFlg = 0;
            }
        });
        problemList(0);
    }

    /**
     * 問題のリストビューのカスタムビューバインダークラス。
     */
    private class ProblemCustomViewBinder implements SimpleAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Object data, String textRepresentation) {

            _helper = new DatabaseHelper(getActivity());
            SQLiteDatabase db = _helper.getWritableDatabase();

            switch(view.getId()) {
                case R.id.downloadNum:
                    TextView downloadNum = view.findViewById(R.id.downloadNum);
                    if(Integer.parseInt((String) data) != 0){
                        //一人以上ダウンロードしているならば
                        downloadNum.setText("人数:"+Integer.parseInt((String) data));
                    }else{
                        //誰もダウンロードしていないならば
                        downloadNum.setText("人数:"+"0");
                    }

                    return true;
                case R.id.userId:
                    TextView userId = view.findViewById(R.id.userId);

                    userId.setText(String.valueOf(data));
                    return true;
                case R.id.shareImage:
                    ImageView imageView = (ImageView)view;

                    //ダウンロードしてあるかどうか(してなければnull)
                    TitleList titleList = TitleListDAO.downloadDone(db, Long.parseLong((String) data));
                    if(titleList != null){
                        //既にダウンロードしている問題の場合
                        imageView.setVisibility(View.INVISIBLE);
                    }else{
                        //ダウンロードしていない問題の場合
                        imageView.setVisibility(View.VISIBLE);
                    }

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(listCount.get((String) data) % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)imageView.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)imageView.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }
                    return true;
                case R.id.formulaImage:
                    imageView = (ImageView)view;
                    if(data.equals("0")){
                        //公式だった場合
                        imageView.setVisibility(View.INVISIBLE);
                    }else{
                        //一般だった場合
                        imageView.setVisibility(View.VISIBLE);
                    }
                    return true;
            }
            return false;
        }
    }

    /**
     * 単語帳のリストビューのカスタムビューバインダークラス。
     */
    private class FlashcardCustomViewBinder implements SimpleAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Object data, String textRepresentation) {
            ImageView imageView;
            _helper = new DatabaseHelper(getActivity());
            SQLiteDatabase db = _helper.getWritableDatabase();
            switch(view.getId()) {
                case R.id.downloadNum:
                    TextView downloadNum = view.findViewById(R.id.downloadNum);
                    if(data.equals("0")){
                        //誰もダウンロードしていないならば
                        downloadNum.setText("人数:"+"0");
                    }else{
                        //一人以上ダウンロードしているならば
                        downloadNum.setText("人数:"+data);
                    }
                    return true;
                case R.id.userId:
                    TextView userId = view.findViewById(R.id.userId);

                    userId.setText((String) data);
                    return true;
                case R.id.shareImage:
                    imageView = (ImageView)view;
                    FlashcardTitle flashcardId = FlashcardTitleDAO.downloadDone(db, Long.parseLong((String) data));
                    if(flashcardId != null){
                        //既にダウンロードしている単語帳の場合
                        imageView.setVisibility(View.INVISIBLE);
                    }else{
                        //ダウンロードしていない単語帳の場合
                        imageView.setVisibility(View.VISIBLE);
                    }

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(listCount.get(String.valueOf(data)) % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)imageView.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)imageView.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }
                    return true;
                case R.id.formulaImage:
                    imageView = (ImageView)view;

                    if(data.equals("0")){
                        //公式だった場合
                        imageView.setVisibility(View.INVISIBLE);
                    }else{
                        //一般だった場合
                        imageView.setVisibility(View.VISIBLE);
                    }
                    return true;
            }
            return false;
        }
    }

    /**
     * 問題のリストがクリックされた時のリスナクラス
     */
    private class ProblemListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            listPosition = position;
            sendPastData(formulaFlg, "problem", Long.parseLong(problemTitleList.get(position).get("_id")), "reference");
        }
    }

    /**
     * 単語帳のリストがクリックされた時のリスナクラス
     */
    private class FlashcardListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            listPosition = position;
            sendPastData(formulaFlg, "flashcard", Long.parseLong(flashcardTitleList.get(position).get("_id")), "reference");
        }
    }

    /**
     * 問題のダイアログ作成
     */
    public void ProblemListDialog(){
        //タイトルIDを保存する
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        editor.putLong("titleId", listPosition);
        editor.commit();

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_download, null, false);
        TextView textUserName = dialogView.findViewById(R.id.dialogUserId);
        TextView textProblemTitle = dialogView.findViewById(R.id.flashcardTitle);
        TextView textMsg = dialogView.findViewById(R.id.textMsg);

        textUserName.setText(problemTitleList.get(listPosition).get("userId"));
        textProblemTitle.setText(problemTitleList.get(listPosition).get("title"));
        if(problemTitleList.get(listPosition).get("msg").equals("")){
            //メッセージが登録されていない場合
            textMsg.setText("良い問題ができました。\nダウンロードしてみてください。");
        }else{
            textMsg.setText(problemTitleList.get(listPosition).get("msg"));
        }

        //ダイアログのリストを取得
        ListView dialogProblemList = dialogView.findViewById(R.id.dialogReportList);
        TextView style = dialogView.findViewById(R.id.dialogFront);
        TextView  question = dialogView.findViewById(R.id.dialogBack);

        style.setText("形式");
        question.setText("問題");

        String[] from = {"choice", "question", "_id"};
        int[] to = {R.id.left, R.id.right, R.id.id};
        SimpleAdapter adapter = new SimpleAdapter(getActivity(), problemList, R.layout.list_two_center, from, to);
        adapter.setViewBinder(new ProblemDialogCustomViewBinder());
        dialogProblemList.setAdapter(adapter);

        //ダイアログ作成
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(dialogView);

        TitleList problemTitleId = TitleListDAO.downloadDone(db, Long.parseLong(problemTitleList.get(listPosition).get("_id")));
        if(problemTitleId == null) {
            //ダウンロードしてなかった場合
            builder.setPositiveButton(R.string.dialogDownload, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //ダイアログのダウンロードボタンが押された場合
                    problemDownload();
                    if(formulaFlg == 0){
                        //公式のスイッチがoffの場合
                        problemList(0);
                    }else{
                        problemList(1);
                    }
                    Toast.makeText(getActivity(), R.string.dialogDownloadMsg, Toast.LENGTH_SHORT).show();
                }
            });
        }

        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //キャンセルボタンが押された場合
            }
        });
        //ダイアログ出力
        builder.show();
    }

    /**
     * 単語帳のダイアログ作成
     */
    public void FlashcardListDialog(){
        //タイトルIDを保存する
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        editor.putLong("titleId", listPosition);
        editor.commit();

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_download, null, false);
        TextView textUserName = dialogView.findViewById(R.id.dialogUserId);
        TextView textProblemTitle = dialogView.findViewById(R.id.flashcardTitle);
        TextView textMsg = dialogView.findViewById(R.id.textMsg);

        textUserName.setText(flashcardTitleList.get(listPosition).get("userId"));
        textProblemTitle.setText(flashcardTitleList.get(listPosition).get("title"));
        textMsg.setText(flashcardTitleList.get(listPosition).get("msg"));
        if(flashcardTitleList.get(listPosition).get("msg").equals("")){
            //メッセージが登録されていない場合
            textMsg.setText("良い単語帳ができました。\nダウンロードしてみてください。");
        }else{
            textMsg.setText(flashcardTitleList.get(listPosition).get("msg"));
        }

        //ダイアログのリストを取得
        ListView dialogFlashcardList = dialogView.findViewById(R.id.dialogReportList);

        String[] from = {"front", "back", "_id"};
        int[] to = {R.id.left, R.id.right, R.id.id};
        SimpleAdapter adapter = new SimpleAdapter(getActivity(), flashcardList, R.layout.list_two_center, from, to);
        adapter.setViewBinder(new FlashcardDialogCustomViewBinder());
        dialogFlashcardList.setAdapter(adapter);

        //ダイアログ作成
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(dialogView);

        FlashcardTitle flashcardTitleId = FlashcardTitleDAO.downloadDone(db, Long.parseLong(flashcardTitleList.get(listPosition).get("_id")));
        if(flashcardTitleId == null){
            //ダウンロードしてなかった場合
            builder.setPositiveButton(R.string.dialogDownload, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //ダイアログのダウンロードボタンが押された場合
                    flashcardDownload();
                    if(formulaFlg == 0){
                        //公式のスイッチがoffの場合
                        flashcardList(0);
                    }else{
                        flashcardList(1);
                    }
                    Toast.makeText(getActivity(), R.string.dialogDownloadMsg, Toast.LENGTH_SHORT).show();
                }
            });
        }

        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //キャンセルボタンが押された場合
            }
        });
        //ダイアログ出力
        builder.show();
    }

    /**
     * 問題のリストビューのカスタムビューバインダークラス。
     */
    private class ProblemDialogCustomViewBinder implements SimpleAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Object o, String s) {
            switch (view.getId()) {
                case R.id.left:
                    TextView textStyle = view.findViewById(R.id.left);
                    if(String.valueOf(o).equals("on")){
                        //選択式
                        textStyle.setText("選択式");
                    }else{
                        //記述式
                        textStyle.setText("記述式");
                    }
                    return true;
                case R.id.right:
                    TextView textQuestion = view.findViewById(R.id.right);
                    textQuestion.setText(String.valueOf(o));
                    return true;
                case R.id.id:
                    TextView id = view.findViewById(R.id.id);
                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(childCount.get(String.valueOf(o)) % 2 == 0){
                        ((ViewGroup)id.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)id.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }
                    return true;
            }
            return false;
        }
    }

    /**
     * 単語帳のダイアログのリストビューのカスタムビューバインダークラス。
     */
    private class FlashcardDialogCustomViewBinder implements SimpleAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Object o, String s) {
            switch (view.getId()) {
                case R.id.left:
                    TextView textStyle = view.findViewById(R.id.left);
                    textStyle.setText(String.valueOf(o));
                    return true;
                case R.id.right:
                    TextView textQuestion = view.findViewById(R.id.right);
                    textQuestion.setText(String.valueOf(o));
                    return true;
                case R.id.id:
                    TextView id = view.findViewById(R.id.id);
                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(childCount.get(String.valueOf(o)) % 2 == 0){
                        ((ViewGroup)id.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)id.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }
                    return true;
            }
            return false;
        }
    }

    /**
     * 問題リスト表示
     * @param formula 公式の人かを識別
     */
    public void problemList(int formula){
        sendPastData(formula, "problemTitle", 0, "reference");
    }

    /**
     * 単語帳リスト表示
     * @param formula 公式の人かを識別
     */
    public void flashcardList(int formula){
        sendPastData(formula, "flashcardTitle", 0, "reference");
    }

    //問題をダウンロードする
    public void problemDownload(){
        //タイトルIDを保存する
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        editor.putLong("downloadId", Long.parseLong(problemTitleList.get(listPosition).get("_id")));
        editor.commit();
        //問題タイトル情報を追加
        long newProblemTitleId = TitleListDAO.shareProblemTitleInsert(db, myPrefs.getString("userId",""), Long.parseLong(problemTitleList.get(listPosition).get("_id")), problemTitleList.get(listPosition).get("title"), Integer.parseInt(problemTitleList.get(listPosition).get("formula")), Integer.parseInt(problemTitleList.get(listPosition).get("time")));
        //単語帳情報を追加
        for(int i=0; i<problemList.size(); i++){
            ProblemDAO.shareProblemInsert(db, myPrefs.getString("userId",""), newProblemTitleId, problemList.get(i).get("question"), problemList.get(i).get("choice"), problemList.get(i).get("choiceA"), problemList.get(i).get("choiceB"), problemList.get(i).get("choiceC"), problemList.get(i).get("choiceD"), problemList.get(i).get("choiceE"), problemList.get(i).get("choiceF"), problemList.get(i).get("choiceG"), problemList.get(i).get("reply"), problemList.get(i).get("explanation"));
        }

        //ダウンロード人数を更新
        sendPastData(formulaFlg, "problem", Long.parseLong(problemTitleList.get(listPosition).get("_id")), "update");
    }

    //単語帳をダウンロードする
    public void flashcardDownload(){
        //タイトルIDを保存する
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        editor.putLong("downloadId", Long.parseLong(flashcardTitleList.get(0).get("_id")));
        editor.commit();
        //単語帳タイトル情報を追加
        long newFlashcardTitleId = FlashcardTitleDAO.shareFlashcardTitleInsert(db, myPrefs.getString("userId",""), Long.parseLong(flashcardTitleList.get(listPosition).get("_id")), flashcardTitleList.get(listPosition).get("title"), Integer.parseInt(flashcardTitleList.get(listPosition).get("formula")));
        //単語帳情報を追加
        for(int i=0; i<flashcardList.size(); i++){
            FlashcardDAO.shareFlashcardInsert(db, myPrefs.getString("userId",""), newFlashcardTitleId, flashcardList.get(i).get("front"), flashcardList.get(i).get("back"));
        }
        //ダウンロード人数を更新
        sendPastData(formulaFlg, "flashcard", Long.parseLong(flashcardTitleList.get(listPosition).get("_id")), "update");
    }

    //--------------------------------------------------------非同期処理(単語帳)------------------------------------------------------------
    /**
     * 非同期でサーバにポストを開始するメソッド
     * @param formula
     */
    @UiThread
    private void sendPastData(int formula, String style, long downloadId, String action){
        Looper mainLooper = Looper.getMainLooper();
        Handler handler = HandlerCompat.createAsync(mainLooper);
        BackgroundExecutor backgroundPostAccess = new BackgroundExecutor(handler, formula, style, downloadId, action);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.submit(backgroundPostAccess);
    }

    /**
     * 非同期でサーバにポストするためのクラス。
     */
    private class BackgroundExecutor implements Runnable {
        /**
         * ハンドラオブジェクト。
         */
        private final Handler _handler;
        private final String _formula;
        private final String _style;
        private final long _downloadId;
        private final String _action;

        /**
         * コンストラクタ。
         * 非同期でサーバにポストするのに必要な情報を取得する。
         * @param handler
         * @param formula
         */
        public BackgroundExecutor(Handler handler, int formula, String style, long downloadId, String action){
            _handler = handler;
            _formula = String.valueOf(formula);
            _style = style;
            _downloadId = downloadId;
            _action = action;
        }

        @Override
        public void run() {
            String postData = "formula=" + _formula + "&style=" + _style + "&titleId=" + _downloadId + "&action=" + _action;
            HttpURLConnection con = null;
            String err = "";
            InputStream is = null;
            String result = "";
            boolean success = false;
            URL url = null;

            try {
                if(_style.equals("flashcardTitle") || _style.equals("flashcard")){
                    //単語帳のサーバーに飛ぶ
                    url = new URL(FLASHCARD_URL);
                }else{
                    //問題のサーバーに飛ぶ
                    url = new URL(PROBLEM_URL);
                }
                con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setConnectTimeout(5000);
                con.setReadTimeout(5000);
                con.setDoOutput(true);
                OutputStream os = con.getOutputStream();
                os.write(postData.getBytes());
                os.flush();
                os.close();
                int status = con.getResponseCode();
                if(status != 200){
                    throw new IOException("ステータスコード:" + status);
                }
                is = con.getInputStream();

                result = is2String(is);
                success = true;
            }
            catch (SocketTimeoutException ex){
                err = getString(R.string.msg_err_timeout);
                Log.e(DEBUG_TAG, "タイムアウト", ex);
            }
            catch (MalformedURLException ex){
                err = getString(R.string.msg_err_send);
                Log.e(DEBUG_TAG, "URL変換失敗", ex);
            }
            catch (IOException ex){
                err = getString(R.string.msg_err_send);
                Log.e(DEBUG_TAG, "通信失敗", ex);
            }
            finally {
                if(con != null){
                    con.disconnect();
                }
                try {
                    if(is != null){
                        is.close();
                    }
                }
                catch (IOException ex){
                    Log.e(DEBUG_TAG, "InputStream開放失敗", ex);
                }
            }

            if(_style.equals("problemTitle")){
                //問題リストをいじりたい場合
                PostProblemTitleExecutor postExecutor = new PostProblemTitleExecutor(result, err, success);
                _handler.post(postExecutor);
            }else if(_style.equals("problem")){
                //問題をいじりたい場合
                PostProblemExecutor postExecutor = new PostProblemExecutor(result, err, success);
                _handler.post(postExecutor);
            }else if(_style.equals("flashcardTitle")){
                //単語帳リストをいじりたい場合
                PostFlashcardTitleExecutor postExecutor = new PostFlashcardTitleExecutor(result, err, success);
                _handler.post(postExecutor);
            }else if(_style.equals("flashcard")){
                //単語帳をいじりたい場合
                PostFlashcardExecutor postExecutor = new PostFlashcardExecutor(result, err, success);
                _handler.post(postExecutor);
            }
        }

        /**
         * 問題リストにおいて非同期でホストした後にUIスレッドでその情報を表示するためのクラス。
         */
        private class PostProblemTitleExecutor implements Runnable {
            /**
             * 取得に失敗した場合は、その内容を表す文字列。
             */
            private final String _err;
            /**
             * 取得した文字列情報。
             */
            private String _result;
            /**
             * 通信に成功し、無事データを取得したかどうかを表す値。
             */
            private final boolean _success;

            /**
             * コンストラクタ。
             *
             * @param result 取得した文字列情報
             * @param succes 通信に成功し、無事データを取得したかどうかを表す値。
             */
            PostProblemTitleExecutor(String result, String err, boolean succes){
                _result = result;
                _err = err;
                _success = succes;
            }

            @UiThread
            @Override
            public void run() {
                String errMessage = _err;
                if(_success){
                    List<Map<String, String>> list = new ArrayList<>();
                    try {
                        JSONArray array = new JSONArray(_result);
                        for(int i=0; i < array.length(); i++) {
                            Map<String, String> record = new HashMap<>();
                            JSONObject jObject = array.getJSONObject(i);
                            record.put("_id", String.valueOf(jObject.get("_id")));
                            record.put("userId", String.valueOf(jObject.get("userId")));
                            record.put("title", String.valueOf(jObject.get("title")));
                            record.put("time", String.valueOf(jObject.get("time")));
                            record.put("num", String.valueOf(jObject.get("num")));
                            record.put("formula", String.valueOf(jObject.get("formula")));
                            record.put("msg", String.valueOf(jObject.get("msg")));
                            list.add(record);
                            listCount.put(String.valueOf(jObject.get("_id")), i);
                        }
                        problemTitleList = list;
                        ListView problemList = view.findViewById(R.id.dialogReportList);
                        TextView count = view.findViewById(R.id.titleCount9);

                        problemList.setOnItemClickListener(new ProblemListItemClickListener());
                        //問題を表示
                        try{
                            //エラーが発生しなかった場合
                            String[] problemFrom = {"userId", "title", "num", "_id", "formula"};
                            int[] problemTo = {R.id.userId, R.id.shareProblemFlashcardTitle, R.id.downloadNum, R.id.shareImage, R.id.formulaImage};
                            SimpleAdapter problemAdapter = new SimpleAdapter(getActivity(), list, R.layout.share_problemlist, problemFrom, problemTo);
                            problemAdapter.setViewBinder(new ProblemCustomViewBinder());
                            problemList.setAdapter(problemAdapter);
                            count.setText(array.length() + "件検出");
                        }catch (NullPointerException e){
                            e.printStackTrace();
                        }
                    }
                    catch (JSONException ex){
                        Log.e(DEBUG_TAG, "JSON解析失敗", ex);
                    }
                }
            }
        }

        /**
         * 問題において非同期でホストした後にUIスレッドでその情報を表示するためのクラス。
         */
        private class PostProblemExecutor implements Runnable{
            /**
             * 取得に失敗した場合は、その内容を表す文字列。
             */
            private final String _err;
            /**
             * 取得した文字列情報。
             */
            private String _result;
            /**
             * 通信に成功し、無事データを取得したかどうかを表す値。
             */
            private final boolean _success;

            /**
             * コンストラクタ。
             *
             * @param result 取得した文字列情報
             * @param succes 通信に成功し、無事データを取得したかどうかを表す値。
             */
            PostProblemExecutor(String result, String err, boolean succes){
                _result = result;
                _err = err;
                _success = succes;
            }

            @UiThread
            @Override
            public void run(){
                String errMessage = _err;
                if(_success){
                    List<Map<String, String>> list = new ArrayList<>();
                    try {
                        JSONArray array = new JSONArray(_result);
                        for(int i=0; i < array.length(); i++) {
                            Map<String, String> record = new HashMap<>();
                            JSONObject jObject = array.getJSONObject(i);
                            record.put("_id", String.valueOf(jObject.get("_id")));
                            record.put("question", String.valueOf(jObject.get("question")));
                            record.put("choice", String.valueOf(jObject.get("choice")));
                            record.put("choiceA", String.valueOf(jObject.get("choiceA")));
                            record.put("choiceB", String.valueOf(jObject.get("choiceB")));
                            record.put("choiceC", String.valueOf(jObject.get("choiceC")));
                            record.put("choiceD", String.valueOf(jObject.get("choiceD")));
                            record.put("choiceE", String.valueOf(jObject.get("choiceE")));
                            record.put("choiceF", String.valueOf(jObject.get("choiceF")));
                            record.put("choiceG", String.valueOf(jObject.get("choiceG")));
                            record.put("reply", String.valueOf(jObject.get("reply")));
                            record.put("explanation", String.valueOf(jObject.get("explanation")));
                            childCount.put(String.valueOf(jObject.get("_id")), i);

                            list.add(record);
                        }
                        problemList = list;
                        ProblemListDialog();
                    }
                    catch (JSONException ex){
                        Log.e(DEBUG_TAG, "JSON解析失敗", ex);
                    }
                }
            }
        }

        /**
         * 単語帳リストにおいて非同期でホストした後にUIスレッドでその情報を表示するためのクラス。
         */
        private class PostFlashcardTitleExecutor implements Runnable {
            /**
             * 取得に失敗した場合は、その内容を表す文字列。
             */
            private final String _err;
            /**
             * 取得した文字列情報。
             */
            private String _result;
            /**
             * 通信に成功し、無事データを取得したかどうかを表す値。
             */
            private final boolean _success;

            /**
             * コンストラクタ。
             *
             * @param result 取得した文字列情報
             * @param succes 通信に成功し、無事データを取得したかどうかを表す値。
             */
            PostFlashcardTitleExecutor(String result, String err, boolean succes){
                _result = result;
                _err = err;
                _success = succes;
            }

            @UiThread
            @Override
            public void run() {
                String errMessage = _err;
                if(_success){
                    List<Map<String, String>> list = new ArrayList<>();
                    try {
                        JSONArray array = new JSONArray(_result);
                        for(int i=0; i < array.length(); i++) {
                            Map<String, String> record = new HashMap<>();
                            JSONObject jObject = array.getJSONObject(i);
                            record.put("_id", String.valueOf(jObject.get("_id")));
                            record.put("userId", String.valueOf(jObject.get("userId")));
                            record.put("title", String.valueOf(jObject.get("title")));
                            record.put("num", String.valueOf(jObject.get("num")));
                            record.put("formula", String.valueOf(jObject.get("formula")));
                            record.put("msg", String.valueOf(jObject.get("msg")));
                            listCount.put(String.valueOf(jObject.get("_id")), i);
                            list.add(record);
                        }
                        flashcardTitleList = list;
                        ListView flashcardList = view.findViewById(R.id.dialogReportList);
                        TextView count = view.findViewById(R.id.titleCount9);

                        flashcardList.setOnItemClickListener(new FlashcardListItemClickListener());
                        //単語帳を表示
                        String[] flashcardFrom = {"userId", "title", "num", "_id", "formula"};
                        int[] flashcardTo = {R.id.userId, R.id.shareProblemFlashcardTitle, R.id.downloadNum, R.id.shareImage, R.id.formulaImage};
                        SimpleAdapter flashcardAdapter = new SimpleAdapter(getActivity(), list, R.layout.share_problemlist, flashcardFrom, flashcardTo);
                        flashcardAdapter.setViewBinder(new FlashcardCustomViewBinder());
                        flashcardList.setAdapter(flashcardAdapter);
                        count.setText(array.length() + "件検出");
                    }
                    catch (JSONException ex){
                        Log.e(DEBUG_TAG, "JSON解析失敗", ex);
                    }
                }
            }
        }

        /**
         * 単語帳において非同期でホストした後にUIスレッドでその情報を表示するためのクラス。
         */
        private class PostFlashcardExecutor implements Runnable{
            /**
             * 取得に失敗した場合は、その内容を表す文字列。
             */
            private final String _err;
            /**
             * 取得した文字列情報。
             */
            private String _result;
            /**
             * 通信に成功し、無事データを取得したかどうかを表す値。
             */
            private final boolean _success;

            /**
             * コンストラクタ。
             *
             * @param result 取得した文字列情報
             * @param succes 通信に成功し、無事データを取得したかどうかを表す値。
             */
            PostFlashcardExecutor(String result, String err, boolean succes){
                _result = result;
                _err = err;
                _success = succes;
            }

            @UiThread
            @Override
            public void run(){
                String errMessage = _err;
                if(_success){
                    List<Map<String, String>> list = new ArrayList<>();
                    try {
                        JSONArray array = new JSONArray(_result);
                        for(int i=0; i < array.length(); i++) {
                            Map<String, String> record = new HashMap<>();
                            JSONObject jObject = array.getJSONObject(i);
                            record.put("_id", String.valueOf(jObject.get("_id")));
                            record.put("front", String.valueOf(jObject.get("front")));
                            record.put("back", String.valueOf(jObject.get("back")));
                            list.add(record);
                            childCount.put(String.valueOf(jObject.get("_id")), i);
                        }
                        flashcardList = list;
                        FlashcardListDialog();
                    }
                    catch (JSONException ex){
                        Log.e(DEBUG_TAG, "JSON解析失敗", ex);
                    }
                }
            }
        }

        /**
         * InputStreamオブジェクトを文字列に変換するメソッド。変換文字コードはUTF-8。
         *
         * @param is 変換対象のInputStreamオブジェクト。
         * @return 変換された文字列。
         * @throws IOException 変換に失敗した時に発生。
         */
        private String is2String(InputStream is) throws IOException{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuffer sb = new StringBuffer();
            char[] b = new char[1024];
            int line;
            while (0 <= (line = reader.read(b))){
                sb.append(b, 0, line);
            }
            return sb.toString();
        }
    }

    public void reload() {
        back();
        migrate(ShareFragment.newInstance());
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
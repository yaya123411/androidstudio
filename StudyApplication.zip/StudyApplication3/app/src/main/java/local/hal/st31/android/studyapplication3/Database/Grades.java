package local.hal.st31.android.studyapplication3.Database;

import java.math.BigDecimal;

public class Grades {
    /**
     * id
     */
    private long _id;
    /**
     * ユーザーID
     */
    private String _userId;
    /**
     * タイトルID
     */
    private long _titleId;
    /**
     * 正解率
     */
    private int _correctSolutionRate;
    /**
     * 正解数
     */
    private int _correctSolutionNum;
    /**
     * 回答時間
     */
    private Double _time;
    /**
     * 回答日時
     */
    private String _data;
    /**
     * 最大スコア
     */
    private int _maxScore;
    /**
     * 最小スコア
     */
    private int _minScore;
    /**
     * 平均スコア
     */
    private BigDecimal _avgScore;
    /**
     * 同じタイトルを解いた回数
     */
    private int _count;

    //以下アクセサメソッド

    public long getId(){
        return _id;
    }
    public void setId(long id){
        _id = id;
    }
    public String getUserId(){
        return _userId;
    }
    public void setUserId(String userId){
        _userId = userId;
    }
    public long getTitleId(){
        return _titleId;
    }
    public void setTitleId(long titleId){
        _titleId = titleId;
    }
    public int getCorrectSolutionRate(){
        return _correctSolutionRate;
    }
    public void setCorrectSolutionRate(int correctSolutionRate){
        _correctSolutionRate = correctSolutionRate;
    }
    public int getCorrectSolutionNum(){
        return _correctSolutionNum;
    }
    public void setCorrectSolutionNum(int correctSolutionNum){
        _correctSolutionNum = correctSolutionNum;
    }
    public Double getTime(){
        return _time;
    }
    public void setTime(Double time){
        _time = time;
    }
    public String getData(){
        return _data;
    }
    public void setData(String data){
        _data = data;
    }
    public int getMaxScore(){
        return _maxScore;
    }
    public void setMaxScore(int maxScore){
        _maxScore = maxScore;
    }
    public int getMinScore(){
        return _minScore;
    }
    public void setMinScore(int minScore){
        _minScore = minScore;
    }
    public BigDecimal getAvgScore(){
        return _avgScore;
    }
    public void setAvgScore(BigDecimal averageScore){
        _avgScore = averageScore;
    }
    public int getCount(){
        return _count;
    }
    public void setCount(int count){
        _count = count;
    }
}

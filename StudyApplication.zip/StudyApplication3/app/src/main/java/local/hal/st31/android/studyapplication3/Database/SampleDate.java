package local.hal.st31.android.studyapplication3.Database;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;

public class SampleDate {
    public static void insert(SQLiteDatabase db){
        /**
         * 管理者（公式）を一人追加する
         * 一般ユーザーを一人追加する
         */
        String[] userSql = {
                "INSERT INTO user (_userId, userName, password, formulaFlg) VALUES ('kanrisyasplatoon', 'Splatoon(スプラトゥーン)', 'test1234', 1)",
                "INSERT INTO user (_userId, userName, password, formulaFlg) VALUES ('yaya', 'やや', 'test1234', 0)"
        };

        for (String value : userSql) {
            SQLiteStatement stmt = db.compileStatement(value);
            stmt.executeInsert();
        }

        /**
         * 問題タイトルを4つ追加する
         */
        String[] problemTitleSql = {
                "INSERT INTO titleLists (userId, downloadId, title, time, uploadFlg, formulaFlg, updateTime) VALUES ('yaya', 0, '基本情報技術者試験', 10, 0, 0, datetime('now'))",
                "INSERT INTO titleLists (userId, downloadId, title, time, uploadFlg, formulaFlg, updateTime) VALUES ('yaya', 0, '応用情報技術者試験', 20, 0, 0, datetime('now'))",
                "INSERT INTO titleLists (userId, downloadId, title, time, uploadFlg, formulaFlg, updateTime) VALUES ('yaya', 0, 'スプラトゥーンクイズ', 30, 0, 0, datetime('now'))",
                "INSERT INTO titleLists (userId, downloadId, title, time, uploadFlg, formulaFlg, updateTime) VALUES ('kanrisyasplatoon', 0, 'スプラトゥーン２のクイズ', 10, 1, 1, datetime('now'))"
        };
        ArrayList<Long> problemTitleId = new ArrayList<>();
        for (String s : problemTitleSql) {
            SQLiteStatement stmt = db.compileStatement(s);
            long insertedId = stmt.executeInsert();
            problemTitleId.add(insertedId);
        }

        /**
         * 問題を12個追加する
         */
        String[] problemSql = {
                "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", '8ビットの値の全ビットを反転する操作はどれか', 'on', '16進表記 FF のビット列と排他的論理和をとる', '16進表記 00 のビット列と論理和をとる', '16進表記 00 のビット列と排他的論理和をとる', '16進表記 FF のビット列と論理和をとる', '', '', '', 'ア', '「ビットを反転する」とは、ビット列のうち1の部分を0にし、0の部分を1にすることです。各論理演算の特性を踏まえて答えを導きましょう', datetime('now'))",
                "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", '1GHzのクロックで動作するCPUがある。このCPUは，機械語の1命令を平均0.8クロックで実行できることが分かっている。このCPUは1秒間に平均何万命令を実行できるか', 'on', '125000', '80000', '250', '125', '', '', '', 'ア', '1GHzのCPUは、1秒間に109回のクロックが発生することになります。1命令を平均0.8クロックで実行できるので、1秒間のクロック発生数を0.8で除すことで1秒間当たりの命令実行回数を求められます', datetime('now'))",
                "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", '次に示す接続のうち，デイジーチェーン接続と呼ばれる接続方法はどれか', 'on', 'Thunderbolt接続コネクタが2口ある4kディスプレイ2台を，PCのThunderbolt接続ポートから1台目のディスプレイにケーブルで接続し，さらに，1台目のディスプレイと2台目のディスプレイとの間をケーブルで接続する', 'PCと計測機器とをRS-232Cで接続し，PCとプリンタとをUSBを用いて接続する', 'キーボード，マウス，プリンタをUSBハブにつなぎ，USBハブとPCとを接続する', '数台のネットワークカメラ及びPCをネットワークハブに接続する', '', '', '', 'ア', 'デイジーチェーン接続は、パラレル転送規格のSCSI(スカジー)などで用いられる接続方法で、「PC－周辺機器－周辺機器」というように、PCを起点として複数の周辺機器を直列で(数珠つなぎのように)接続する方法です', datetime('now'))",
                "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", 'aを正の整数とし，b＝a^2とする。aを2進数で表現するとnビットであるとき，bを2進数で表現すると最大で何ビットになるか。', 'on', '2n', 'n+1', 'n^2', '2^n', '', '', '', 'ア', '一般化すると b＝2a の関係式が成立するので、aがnであるときのbを表す式は「2n」になります。', datetime('now'))",
                "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", 'XMLにおいて，XML宣言中で符号化宣言を省略できる文字コードはどれか', 'on', 'UTF-16', 'EUC-JP', 'ISO-2022-JP', 'Shift-JIS', '', '', '', 'ア', 'XMLの仕様によると、XMLのデフォルト文字コードはUTF-8であり、UTF-8とUTF-16は符号化宣言を必要としないとされています。符号化宣言がない場合、XMLプロセッサは文書先頭のBOM(Byte Order Mark)を見て、BOMがなければUTF-8として、BOMがあればUTF-16として処理することになっています', datetime('now'))",
                "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", 'ディープラーニングの学習にGPUを用いる利点として，適切なものはどれか', 'on', '行列演算ユニットを用いて，行列演算を高速に実行できる', '各プロセッサコアが独立して異なるプログラムを実行し，異なるデータを処理できる', '浮動小数点演算ユニットをコプロセッサとして用い，浮動小数点演算ができる', '分岐予測を行い，パイプラインの利用効率を高めた処理を実行できる', '', '', '', 'ア', 'GPU(Graphics Processing Unit)を用いる利点です', datetime('now'))",
                "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", '人気ゲーム「スプラトゥーン」のレギュラーマッチ・ガチマッチは1チーム何人で闘う？', 'on', '4人', '5人', '6人', '7人', '8人', '', '', 'ア', 'スプラトゥーンは4対4の計8人で闘います', datetime('now'))",
                "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", '人気ゲーム「スプラトゥーン２」のスペシャルウエポンで一定時間の間、相手からの攻撃を防ぐアーマーを張るといえば？', 'off', '', '', '', '', '', '', '', 'インクアーマー', '一定時間相手のインクを防ぐことができます', datetime('now'))",
                "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", '人気ゲーム「スプラトゥーン２」で「52ガロン」に付いているスペシャルウエポンといえば？', 'on', 'イカスフィア', 'メガホンレーザー', '', '', '', '', '', 'ア', 'ガロンにはイカスフィア、ハイパープレッサー、ナイスダマの3つの武器が存在します。メガホンレーザーがついているガロンはスプラトゥーン1、スプラトゥーン3で実装されています', datetime('now'))",
                "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) " +
                        "VALUES ('kanrisyasplatoon', " + problemTitleId.get(3) + ", 'この中で新たに追加されたバトルはどれ', 'on', 'ガチホコバトル', 'ガチヤグラバトル', 'ガチアサリバトル', 'ガチエリアバトル', '', '', '', 'ウ', 'ガチホコバトルは１の時に新たに追加され、ガチアサリバトルは２の時に新たに追加された。それ以外はもともと存在するバトルルールだ', datetime('now'))",
                "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) " +
                        "VALUES ('kanrisyasplatoon', " + problemTitleId.get(3) + ", 'スプラトゥーン２において、存在しないスペシャルはなに？', 'on', 'ジェットパック', 'ナイスダマ', 'ダイオウイカ', 'インクアーマー', '', '', '', 'ウ', 'ダイオウイカはスプラトゥーン１のスペシャルです', datetime('now'))",
                "INSERT INTO problems (userId, titleId, question, choice, choiceA, choiceB, choiceC, choiceD, choiceE, choiceF, choiceG, reply, explanation, updateTime) " +
                        "VALUES ('kanrisyasplatoon', " + problemTitleId.get(3) + ", 'スプラトゥーン２において、なくなったギアはどれ', 'on', 'マーキングガード', 'リベンジ', 'ステルスジャンプ', 'イカニンジャ', '', '', '', 'ア', 'マーキングガードはスプラトゥーン２では存在しません', datetime('now'))"
        };
        ArrayList<Long> problemId = new ArrayList<>();
        for (String s : problemSql) {
            SQLiteStatement stmt = db.compileStatement(s);
            long id = stmt.executeInsert();
            problemId.add(id);
        }

        /**
         * 単語帳タイトルを4つ追加する
         */
        String[] flashcardTitleSql = {
                "INSERT INTO flashcardTitle (userId, downloadId, title, formulaFlg, uploadFlg, updateTime) VALUES ('yaya', 0, 'スプラトゥーンの用語集', 0, 0, datetime('now'))",
                "INSERT INTO flashcardTitle (userId, downloadId, title, formulaFlg, uploadFlg, updateTime) VALUES ('yaya', 0, '応用情報技術者試験の用語集', 0, 0, datetime('now'))",
                "INSERT INTO flashcardTitle (userId, downloadId, title, formulaFlg, uploadFlg, updateTime) VALUES ('kanrisyasplatoon', 0, 'スプラトゥーン知識', 1, 1, datetime('now'))"
        };
        ArrayList<Long> flashcardTitleId = new ArrayList<>();
        for (String s : flashcardTitleSql) {
            SQLiteStatement stmt = db.compileStatement(s);
            long insertedId = stmt.executeInsert();
            flashcardTitleId.add(insertedId);
        }

        /**
         * 単語帳を9個追加する
         */
        String[] flashcardSql = {
                "INSERT INTO flashcard (userId, flashcardTitleId, front, back, remember, updateTime) " +
                        "VALUES ('yaya', " + flashcardTitleId.get(0) + ", '裏どり', '敵味方が攻防している前線から見て、反対側のルートを確保することを指します', '0', datetime('now'))",
                "INSERT INTO flashcard (userId, flashcardTitleId, front, back, remember, updateTime) " +
                        "VALUES ('yaya', " + flashcardTitleId.get(0) + ", '潜伏', 'ZLボタンで味方インクに潜んでいる状態のことを指します', '0', datetime('now'))",
                "INSERT INTO flashcard (userId, flashcardTitleId, front, back, remember, updateTime) " +
                        "VALUES ('yaya', " + flashcardTitleId.get(0) + ", '雷神ステップ', 'すばやく動き回るテクニックのことを指します', '0', datetime('now'))",
                "INSERT INTO flashcard (userId, flashcardTitleId, front, back, remember, updateTime) " +
                        "VALUES ('yaya', " + flashcardTitleId.get(1) + ", 'アウトソーシング', '自社の業務の一部又は業務のすべてを外部へ委託すること。専門的な知識・技能が必要となる業務を、その業務を得意とする業者へ外注することで人材育成や設備投資のコストが低減されるメリットがある。', '0', datetime('now'))",
                "INSERT INTO flashcard (userId, flashcardTitleId, front, back, remember, updateTime) " +
                        "VALUES ('yaya', " + flashcardTitleId.get(1) + ", 'アジャイル', '「俊敏な」「すばやい」という意味の英単語で、ソフトウェアを迅速かつ適応的にソフトウェア開発を行う軽量な開発手法の総称。 開発プロジェクトを短期間に区切り、その期間内に「要件定義」～「テスト」「運用」までの開発工程を一通り行い、一部分の機能を完成させるという作業を繰り返すことで段階的にシステムを開発していくモデル。', '0', datetime('now'))",
                "INSERT INTO flashcard (userId, flashcardTitleId, front, back, remember, updateTime) " +
                        "VALUES ('yaya', " + flashcardTitleId.get(1) + ", 'アローダイアグラム', 'プロジェクトの各作業間の関連性や順序関係を視覚的に表現する図。作業の前後関係を分析することで時間的に余裕のない一連の作業(クリティカルパス)を洗い出すことができるためプロジェクトのスケジュール管理に使用される。PERT図とも呼ばれる。', '0', datetime('now'))",
                "INSERT INTO flashcard (userId, flashcardTitleId, front, back, remember, updateTime) " +
                        "VALUES ('kanrisyasplatoon', " + flashcardTitleId.get(2) + ", 'スプラシューターのスペシャルは？', 'スーパーチャクチ', '0', datetime('now'))",
                "INSERT INTO flashcard (userId, flashcardTitleId, front, back, remember, updateTime) " +
                        "VALUES ('kanrisyasplatoon', " + flashcardTitleId.get(2) + ", 'わかばシューターのスペシャルは？', 'インクアーマー', '0', datetime('now'))",
                "INSERT INTO flashcard (userId, flashcardTitleId, front, back, remember, updateTime) " +
                        "VALUES ('kanrisyasplatoon', " + flashcardTitleId.get(2) + ", 'スプラマニューバーのスペシャルは？', 'マルチミサイル', '0', datetime('now'))"
        };
        for (String s : flashcardSql) {
            SQLiteStatement stmt = db.compileStatement(s);
            stmt.executeInsert();
        }

        /**
         * 成績を9個追加する
         */
        String[] gradesSql = {
                "INSERT INTO grades (userId, titleId, downloadId, count, correctSolutionRate, correctSolutionNum, time, data) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", 0, 1, 33, 1, 0.13, datetime('now'))",
                "INSERT INTO grades (userId, titleId, downloadId, count, correctSolutionRate, correctSolutionNum, time, data) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", 0, 2, 100, 3, 0.13, datetime('now'))",
                "INSERT INTO grades (userId, titleId, downloadId, count, correctSolutionRate, correctSolutionNum, time, data) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", 0, 3, 0, 0, 0.13, datetime('now'))",
                "INSERT INTO grades (userId, titleId, downloadId, count, correctSolutionRate, correctSolutionNum, time, data) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", 0, 1, 33, 1, 0.13, datetime('now'))",
                "INSERT INTO grades (userId, titleId, downloadId, count, correctSolutionRate, correctSolutionNum, time, data) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", 0, 2, 100, 3, 0.13, datetime('now'))",
                "INSERT INTO grades (userId, titleId, downloadId, count, correctSolutionRate, correctSolutionNum, time, data) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", 0, 3, 0, 0, 0.13, datetime('now'))",
                "INSERT INTO grades (userId, titleId, downloadId, count, correctSolutionRate, correctSolutionNum, time, data) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", 0, 1, 33, 1, 0.13, datetime('now'))",
                "INSERT INTO grades (userId, titleId, downloadId, count, correctSolutionRate, correctSolutionNum, time, data) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", 0, 2, 100, 3, 0.13, datetime('now'))",
                "INSERT INTO grades (userId, titleId, downloadId, count, correctSolutionRate, correctSolutionNum, time, data) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", 0, 3, 0, 0, 0.13, datetime('now'))"
        };
        for (String s : gradesSql) {
            SQLiteStatement stmt = db.compileStatement(s);
            stmt.executeInsert();
        }

        /**
         * 正解の問題を追加する
         */
        String[] correctSolutionProblemSql = {
                "INSERT INTO correctSolutionProblem (userId, titleId, problemId, downloadId, count, reply) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", " + problemId.get(0) + ", 0, 1, 'ア')",
                "INSERT INTO correctSolutionProblem (userId, titleId, problemId, downloadId, count, reply) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", " + problemId.get(0) + ", 0, 2, 'ア')",
                "INSERT INTO correctSolutionProblem (userId, titleId, problemId, downloadId, count, reply) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", " + problemId.get(1) + ", 0, 2, 'ア')",
                "INSERT INTO correctSolutionProblem (userId, titleId, problemId, downloadId, count, reply) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", " + problemId.get(2) + ", 0, 2, 'ア')",
                "INSERT INTO correctSolutionProblem (userId, titleId, problemId, downloadId, count, reply) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", " + problemId.get(3) + ", 0, 1, 'ア')",
                "INSERT INTO correctSolutionProblem (userId, titleId, problemId, downloadId, count, reply) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", " + problemId.get(3) + ", 0, 2, 'ア')",
                "INSERT INTO correctSolutionProblem (userId, titleId, problemId, downloadId, count, reply) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", " + problemId.get(4) + ", 0, 2, 'ア')",
                "INSERT INTO correctSolutionProblem (userId, titleId, problemId, downloadId, count, reply) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", " + problemId.get(5) + ", 0, 2, 'ア')",
                "INSERT INTO correctSolutionProblem (userId, titleId, problemId, downloadId, count, reply) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", " + problemId.get(6) + ", 0, 1, 'ア')",
                "INSERT INTO correctSolutionProblem (userId, titleId, problemId, downloadId, count, reply) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", " + problemId.get(6) + ", 0, 2, 'ア')",
                "INSERT INTO correctSolutionProblem (userId, titleId, problemId, downloadId, count, reply) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", " + problemId.get(7) + ", 0, 2, 'ア')",
                "INSERT INTO correctSolutionProblem (userId, titleId, problemId, downloadId, count, reply) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", " + problemId.get(8) + ", 0, 2, 'ア')",
        };
        for (String s : correctSolutionProblemSql) {
            SQLiteStatement stmt = db.compileStatement(s);
            stmt.executeInsert();
        }

        /**
         * 不正解の問題を追加する
         */
        String[] mistakeProblemSql = {
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", " + problemId.get(1) + ", 0, 1, 'ア', 'ウ', 0)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", " + problemId.get(2) + ", 0, 1, 'ア', '', 1)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", " + problemId.get(0) + ", 0, 3, 'ア', 'イ', 0)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", " + problemId.get(1) + ", 0, 3, 'ア', 'ウ', 0)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(0) + ", " + problemId.get(2) + ", 0, 3, 'ア', '', 1)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", " + problemId.get(4) + ", 0, 1, 'ア', 'ウ', 0)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", " + problemId.get(5) + ", 0, 1, 'ア', '', 1)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", " + problemId.get(3) + ", 0, 3, 'ア', 'イ', 0)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", " + problemId.get(4) + ", 0, 3, 'ア', 'ウ', 0)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(1) + ", " + problemId.get(5) + ", 0, 3, 'ア', '', 1)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", " + problemId.get(7) + ", 0, 1, 'インクアーマー', 'アーマー', 0)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", " + problemId.get(8) + ", 0, 1, 'ア', '', 1)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", " + problemId.get(6) + ", 0, 3, 'ア', 'イ', 0)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", " + problemId.get(7) + ", 0, 3, 'インクアーマー', 'バリア', 0)",
                "INSERT INTO mistakeProblem (userId, titleId, problemId, downloadId, count, reply, myReply, notAnswereFlg) " +
                        "VALUES ('yaya', " + problemTitleId.get(2) + ", " + problemId.get(8) + ", 0, 3, 'ア', '', 1)",
        };
        for (String s : mistakeProblemSql) {
            SQLiteStatement stmt = db.compileStatement(s);
            stmt.executeInsert();
        }

        /**
         * メモ帳を追加する
         */
        String[] memoSql = {
                "INSERT INTO memo (userId, title, note, date) " +
                        "VALUES ('yaya', '計算用', '1+1=2', datetime('now'))"
        };
        for (String s : memoSql) {
            SQLiteStatement stmt = db.compileStatement(s);
            stmt.executeInsert();
        }
    }
}

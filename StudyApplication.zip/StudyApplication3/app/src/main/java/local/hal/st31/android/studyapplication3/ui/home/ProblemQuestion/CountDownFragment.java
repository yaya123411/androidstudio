package local.hal.st31.android.studyapplication3.ui.home.ProblemQuestion;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.ProblemDAO;
import local.hal.st31.android.studyapplication3.Database.TitleList;
import local.hal.st31.android.studyapplication3.Database.TitleListDAO;
import local.hal.st31.android.studyapplication3.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CountDownFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CountDownFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;

    //フラグメントを呼び出す
    public static CountDownFragment newInstance(ArrayList<String> problemList){
// Fragemnt01 インスタンス生成
        CountDownFragment CountDownFragment = new CountDownFragment();

        Bundle args = new Bundle();
        args.putStringArrayList("problemList", problemList);
        CountDownFragment.setArguments(args);

        return CountDownFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "");
        editor.commit();
        setHasOptionsMenu(true);

        return inflater.inflate(R.layout.fragment_count_down,
                container, false);
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        new CountDownTimer(1000*4, 100) {

            @Override
            public void onTick(long millisUntilFinished) {
                int time = (int)millisUntilFinished /1000;
                if(time == 0){
                    ((TextView)view.findViewById(R.id.textCount)).setText("スタート");
                }else{
                    ((TextView)view.findViewById(R.id.textCount)).setText(String.valueOf(time));
                }
            }

            @Override
            public void onFinish() {
                Bundle args = getArguments();

                back();
                migrate(ProblemFragment.newInstance(args.getStringArrayList("problemList"), Long.parseLong(String.valueOf(0)), 0));
            }
        }.start();
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
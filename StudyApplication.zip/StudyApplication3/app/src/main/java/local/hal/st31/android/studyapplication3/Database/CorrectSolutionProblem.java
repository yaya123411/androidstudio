package local.hal.st31.android.studyapplication3.Database;

public class CorrectSolutionProblem {
    /**
     * id
     */
    private long _id;
    /**
     * ユーザーID
     */
    private String _userId;
    /**
     * タイトルID
     */
    private long _titleId;
    /**
     * 問題番号
     */
    private long _problemId;
    /**
     * 同じタイトルで何回目の問題化を格納
     */
    private Integer _count;
    /**
     * 回答スタイル
     */
    private String _choice;
    /**
     * 記述式の答え
     */
    private String _choiceA;
    /**
     * 問題
     */
    private String _question;
    /**
     * 答え
     */
    private String _reply;
    /**
     * 解説
     */
    private String _explanation;

    //以下アクセサメソッド

    public long getId(){
        return _id;
    }
    public void setId(long id){
        _id = id;
    }
    public String getUserId(){
        return _userId;
    }
    public void setUserId(String userId){
        _userId = userId;
    }
    public long getTitleId(){
        return _titleId;
    }
    public void setTitleId(long titleId){
        _titleId = titleId;
    }
    public Integer getCount(){
        return _count;
    }
    public void setCount(Integer count){
        _count = count;
    }
    public long getProblemId(){
        return _problemId;
    }
    public void setProblemId(long problemId){
        _problemId = problemId;
    }
    public String getChoice(){
        return _choice;
    }
    public void setChoice(String choice){
        _choice = choice;
    }
    public String getChoiceA(){
        return _choiceA;
    }
    public void setChoiceA(String choiceA){
        _choiceA = choiceA;
    }
    public String getQuestion(){
        return _question;
    }
    public void setQuestion(String question){
        _question = question;
    }
    public String getReply(){
        return _reply;
    }
    public void setReply(String reply){
        _reply = reply;
    }
    public String getExplanation(){
        return _explanation;
    }
    public void setExplanation(String explanation){
        _explanation = explanation;
    }
}

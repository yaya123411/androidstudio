package local.hal.st31.android.studyapplication3.ui.home.Flashcard;

import static android.app.Activity.RESULT_OK;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.UiThread;
import androidx.annotation.WorkerThread;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.core.os.HandlerCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;

import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.FlashcardDAO;
import local.hal.st31.android.studyapplication3.Database.FlashcardInterrupt;
import local.hal.st31.android.studyapplication3.Database.FlashcardInterruptDAO;
import local.hal.st31.android.studyapplication3.Database.FlashcardTitle;
import local.hal.st31.android.studyapplication3.Database.FlashcardTitleDAO;
import local.hal.st31.android.studyapplication3.Database.User;
import local.hal.st31.android.studyapplication3.Database.UserDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.OCR;
import local.hal.st31.android.studyapplication3.ui.home.Memo.MemoTopFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FlashcardTopFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FlashcardTopFragment extends Fragment {
    /**
     * 新規登録モードを表す定数フィールド。
     */
    static final int MODE_INSERT = 1;
    /**
     * 更新モードを表す定数フィールド。
     */
    static final int MODE_UPDATE = 2;
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    /**
     * 入力チェックフラグ
     */
    private int flg = 0;
    //任意の識別番号
    private static final int REQUEST_CODE = 12345;
    //ocr
    private static final int REQUEST_CODE_PICK_CONTENT = 0;
    private OCR _ocr;
    private String serch = "",sort = "",where = "";
    View view;
    private AlertDialog.Builder builder;
    /**
     * ログに記載するタグ用の文字列。
     */
    protected static final String DEBUG_TAG = "Post2DB";
    /**
     * post先のURL。
     */
    private static final String ACCESS_URL = "http://yaya8976.php.xdomain.jp/android/studyApplication/flashcard.php";

    //フラグメントを呼び出す
    public static FlashcardTopFragment newInstance(){
// Fragemnt01 インスタンス生成
        FlashcardTopFragment FlashcardTopFragment = new FlashcardTopFragment();
        return FlashcardTopFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_flashcard_top,
                container, false);
        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "単語帳タイトルリスト");
        editor.commit();
        setHasOptionsMenu(true);

        return view;
    }

    //---------------------------------------メニューを出力する------------------------------------

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        //保存領域に接続
        SharedPreferences myPrefs = this.getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

        MenuItem menuItem = menu.findItem(R.id.menuSeach);
        SearchView searchView = (SearchView) menuItem.getActionView();

//        SearchView searchView = (SearchView) MenuItemCompat.getActionView(menuItem);
        searchView.setSubmitButtonEnabled(false);

        if (!myPrefs.getString("serch","").equals("")) {
            // TextView.setTextみたいなもの
            searchView.setQuery(myPrefs.getString("serch",""), false);
        }

        searchView.setOnQueryTextListener(this.onQueryTextListener);

        super.onCreateOptionsMenu(menu, inflater);
//        inflater.inflate(R.menu.option_menu_second, menu);
    }

    //メニューが押された場合
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();
        Cursor cursor;

        boolean returnVal = true;
        int itemId = item.getItemId();
        switch(itemId){
            case R.id.menuUpdate:
                //更新順
                sort = "更新順";
                break;
            case R.id.menuNew:
                //新しい順
                sort = "新しい順";
                break;
            case R.id.menuOld:
                //古い順
                sort = "古い順";
                break;
            case R.id.menuUpload:
                //アップロードされてる
                where = "アップロードされてる";
                break;
            case R.id.menuNotupload:
                //アップロードされていない
                where = "アップロードされていない";
                break;
            case R.id.menuReset:
                //リセット
                serch = "";
                where = "";
                sort = "";
                break;
        }

        cursor = FlashcardTitleDAO.findSeach(db, myPrefs.getString("userId", ""), serch, where, sort, myPrefs.getInt("downloadFlg", 0));
        list(cursor);
        return returnVal;
    }

    private SearchView.OnQueryTextListener onQueryTextListener = new SearchView.OnQueryTextListener() {

        @Override
        public boolean onQueryTextSubmit(String searchWord) {
            //検索ボタンが押された後に反映
            return true;
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            //入力した直後に反映
            //保存領域に接続
            try {
                //保存領域に接続
                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = myPrefs.edit();
                _helper = new DatabaseHelper(getActivity());
                SQLiteDatabase db = _helper.getWritableDatabase();
                Cursor cursor;

                serch = newText;
                cursor = FlashcardTitleDAO.findSeach(db, myPrefs.getString("userId", ""), serch, where, sort, myPrefs.getInt("downloadFlg", 0));
                list(cursor);
            }catch (NullPointerException e){
                e.printStackTrace();
            }
            return false;
        }
    };

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        ListView problemList = view.findViewById(R.id.dialogReportList);
        problemList.setOnItemClickListener(new ListItemClickListener());

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        //メモボタンが押された場合
        FloatingActionButton memo = view.findViewById(R.id.flashcardTopMemo);
        memo.setOnClickListener((View v) -> {
            migrate(MemoTopFragment.newInstance());
        });

        //戻るボタンが押された場合
        ImageView btnBack = view.findViewById(R.id.flashcardTopBack);
        btnBack.setOnClickListener((View v) -> {
            editor.putString("menu", "");
            editor.commit();
            back();
        });

        //タイトル作成ボタンが押された場合
        Button btnAdd = view.findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener((View v) -> {
            //ダイアログを表示
            titleDialog(0);
        });

        _ocr = new OCR(getActivity().getApplicationContext());
    }

    @Override
    public void onResume() {
        super.onResume();

        //タイトルIDを保存する
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        //データベース接続
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        Cursor cursor = FlashcardTitleDAO.findAll(db, myPrefs.getString("userId", null));

        list(cursor);
    }

    /**
     * リストがクリックされた時のリスナクラス
     */
    private class ListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            Cursor item = (Cursor) parent.getItemAtPosition(position);
            int idxId = item.getColumnIndex("_id");
            long idNo = item.getLong(idxId);

            //タイトルIDを保存する
            SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = myPrefs.edit();

            //データベース接続
            _helper = new DatabaseHelper(getActivity());
            SQLiteDatabase db = _helper.getWritableDatabase();

            editor.putLong("titleId", idNo);
            editor.putLong("flashcardId", idNo);
            editor.commit();

            //単語数を取得
            String count = FlashcardDAO.countFlashcard(db, idNo, myPrefs.getInt("rememberFlg",0));

            //始めようとしている単語帳が中断している単語帳であるかを調べる
            FlashcardInterrupt result = null;
            try {
                result = FlashcardInterruptDAO.findIdByPK(db, myPrefs.getLong("titleId",0));
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if(result == null){
                //始めようとしている単語帳が中断している単語帳ではない場合
                if(Integer.parseInt(count) == 0){
                    //単語が追加されていない場合
                    Toast.makeText(getActivity(), "単語が追加されていません", Toast.LENGTH_SHORT).show();
                }else{
                    LayoutInflater inflater = getActivity().getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.dialog_setting, null, false);
                    //ダイアログ作成
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setView(dialogView);

                    Switch automaticSwitch = dialogView.findViewById(R.id.automaticSwitch);
                    Switch rememberSwitch = dialogView.findViewById(R.id.rememberSwitch);

                    editor.putInt("automaticFlg", 0);
                    editor.putInt("rememberFlg", 0);
                    editor.commit();

                    //チェックボックスが押された場合
                    automaticSwitch.setOnClickListener(parts -> {
                        if (automaticSwitch.isChecked()) {
                            //チェック入れた場合
                            editor.putInt("automaticFlg", 1);
                        } else {
                            //チェック外した場合
                            editor.putInt("automaticFlg", 0);
                        }
                        editor.commit();
                    });

                    //チェックボックスが押された場合
                    rememberSwitch.setOnClickListener(parts -> {
                        if (rememberSwitch.isChecked()) {
                            //チェック入れた場合
                            editor.putInt("rememberFlg", 1);
                        } else {
                            //チェック外した場合
                            editor.putInt("rememberFlg", 0);
                        }
                        editor.commit();
                    });

                    builder.setPositiveButton(R.string.btnStart, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //単語数を取得
                            String count = FlashcardDAO.countFlashcard(db, idNo, myPrefs.getInt("rememberFlg",0));
                            if(Integer.parseInt(count) == 0){
                                //単語が全て覚えたにチェックが付けられている場合
                                Toast.makeText(getActivity(), "全て暗記済みです", Toast.LENGTH_SHORT).show();
                                editor.putInt("rememberFlg", 0);
                                editor.commit();
                            }else{
                                ArrayList<String> flashcardId = FlashcardDAO.flashcardIdAll(db, myPrefs.getLong("titleId",0), myPrefs.getInt("rememberFlg",0));
                                //問題数
                                editor.putString("count", count);
                                //現在のページ
                                editor.putInt("now", 0);
                                editor.commit();

                                back();
                                migrate(FlashcardFragment.newInstance(flashcardId));
                            }
                        }
                    });

                    builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });

                    //ダイアログ出力
                    builder.create().show();
                }
            }else {
                //中断履歴があるならば
                ArrayList<String> flashcardId = FlashcardDAO.flashcardIdAll(db, myPrefs.getLong("titleId",0), myPrefs.getInt("rememberFlg",0));
                FlashcardInterrupt FlashcardInterruptResult = null;
                try {
                    FlashcardInterruptResult = FlashcardInterruptDAO.findIdByPK(db, myPrefs.getLong("titleId",0));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                //ダイアログ生成
                AlertDialog.Builder mydialog = new AlertDialog.Builder(getActivity());
                mydialog.setTitle(R.string.flashcardDialogMsg);
                TextView textMsg = new TextView(getActivity());

                textMsg.setText(Integer.parseInt(FlashcardInterruptResult.getPage())+1 + "/" + count + "\n" + FlashcardInterruptResult.getUpdateTime());
                textMsg.setGravity(Gravity.CENTER);
                textMsg.setTextSize(16);
                mydialog.setView(textMsg);

                String[] choices = {};
                choices = new String[]{"続きから", "最初から", "キャンセル"};

                FlashcardInterrupt finalFlashcardInterruptResult = FlashcardInterruptResult;
                mydialog.setItems(choices, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //問題数
                        editor.putString("count", count);
                        //単語帳IDを取得
                        if (which == 0) {
                            //続きからを選択した場合
                            //現在のページ
                            editor.putInt("rememberFlg", finalFlashcardInterruptResult.getSettingRememberFlg());
                            editor.putInt("now", Integer.parseInt(finalFlashcardInterruptResult.getPage()));
                            editor.commit();

                            back();
                            migrate(FlashcardFragment.newInstance(flashcardId));
                        } else if(which == 1) {
                            //最初からを選択した場合
                            //現在のページ
                            editor.putInt("now", 0);
                            editor.commit();

                            back();
                            migrate(FlashcardFragment.newInstance(flashcardId));
                        }
                    }
                });
                mydialog.show();
            }
        }
    }

    /**
     * 単語帳リストのリストビューのカスタムビューバインダークラス。
     */
    private class CustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch(view.getId()) {
                case R.id.uploadImage:
                    //アップロードボタンが押された場合
                    _helper = new DatabaseHelper(getActivity());
                    SQLiteDatabase db = _helper.getWritableDatabase();
                    //保存領域に接続
                    SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

                    FlashcardTitle titleList = FlashcardTitleDAO.findIdByPK(db, Long.parseLong(cursor.getString(columnIndex)));
                    ImageView update = view.findViewById(R.id.uploadImage);
                    long id = Long.parseLong(cursor.getString(columnIndex));
                    ImageView imageView = (ImageView)view;

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)imageView.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)imageView.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }

                    if(titleList.getUploadFlg() == 1){
                        //アップロードされていれば
                        imageView.setVisibility(View.INVISIBLE);
                    }else{
                        update.setOnClickListener((View v) -> {
                            //追加されている単語帳の個数を取得する
                            String flashcardCount = FlashcardDAO.countFlashcard(db, id, myPrefs.getInt("rememberFlg",0));

                            if(Integer.parseInt(flashcardCount) != 0){
                                //単語が1つ以上追加されていた場合
                                //ユーザー名を取得する
                                User userName = UserDAO.findUserIdByPK(db, myPrefs.getString("userId",""));
                                //タイトルを取得する
                                FlashcardTitle flashcardTitle = FlashcardTitleDAO.findIdByPK(db, id);

                                LayoutInflater inflater = getActivity().getLayoutInflater();
                                View dialogView = inflater.inflate(R.layout.flashcard_top_dialog, null, false);
                                TextView textUserName = dialogView.findViewById(R.id.dialogUserId);
                                TextView textFlashcardTitle = dialogView.findViewById(R.id.flashcardTitle);

                                textUserName.setText(userName.getUserName());
                                textFlashcardTitle.setText(flashcardTitle.getTitle());

                                //ダイアログのリストを取得
                                ListView dialogFlashcardList = dialogView.findViewById(R.id.dialogReportList);
                                TextView count = dialogView.findViewById(R.id.titleCount5);

                                Cursor cursors = FlashcardDAO.findTitleAll(db, id);
                                String[] from = {"front", "back"};
                                int[] to = {R.id.left, R.id.right};
                                SimpleCursorAdapter adapter = new SimpleCursorAdapter(getActivity(), R.layout.list_two_center, cursors, from, to, 0);
                                adapter.setViewBinder(new DialogCustomViewBinder());
                                dialogFlashcardList.setAdapter(adapter);
                                count.setText(cursors.getCount() + "件");

                                //ダイアログ作成
                                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setView(dialogView);

                                builder.setPositiveButton(R.string.dialogUpload, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        EditText etMsg = dialogView.findViewById(R.id.etMsg);
                                        String strMsg = etMsg.getText().toString();

                                        FlashcardTitleDAO.updateUpload(db, id);
                                        //単語のタイトル情報を取得
                                        FlashcardTitle title = FlashcardTitleDAO.findIdByPK(db, id);
                                        //単語帳を取得
                                        ArrayList<Map<String, String>> map = FlashcardDAO.findByTitleId(db, id);

                                        //インスタンス化
                                        ObjectMapper mapper = new ObjectMapper();
                                        String jsonReply = "";
                                        try {
                                            // mapをjson文字列に変換します。
                                            jsonReply = mapper.writeValueAsString(map);
                                        } catch (Exception e) {
                                            // エラー!
                                            e.printStackTrace();
                                        }

                                        sendPastData(id, strMsg, myPrefs.getString("userId", null), title.getTitle(), title.getFormulaFlg(), jsonReply);
                                        Cursor cursor = FlashcardTitleDAO.findAll(db, myPrefs.getString("userId", null));
                                        list(cursor);
                                        Toast.makeText(getActivity(), "アップロードが完了しました", Toast.LENGTH_SHORT).show();
                                    }
                                });

                                builder.setNeutralButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                    }
                                });

                                //ダイアログ出力
                                AlertDialog alertDialog = builder.create();
                                alertDialog.setCanceledOnTouchOutside(false);
                                alertDialog.show();
                            }else{
                                Toast.makeText(getActivity(), "中身が空です", Toast.LENGTH_SHORT).show();
                            }
                        });
                        imageView.setVisibility(View.VISIBLE);
                    }
                    return true;
                case R.id.edit:
                    ImageView edit = view.findViewById(R.id.edit);
                    id = Long.parseLong(cursor.getString(columnIndex));
                    edit.setOnClickListener((View v) -> {
                        //編集ボタンが押された場合
                        String[] choices = new String[]{"タイトル編集", "単語帳一覧"};

                        //ダイアログ作成
                        builder = new AlertDialog.Builder(getActivity());
                        builder.setItems(choices, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if(which == 0){
                                    //タイトル編集が押された場合
                                    //ダイアログを表示
                                    titleDialog(id);
                                }else if(which == 1){
                                    //単語帳一覧が押された場合
                                    SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                                    SharedPreferences.Editor editor = myPrefs.edit();
                                    editor.putLong("titleId", id);
                                    editor.commit();
                                    migrate(FlashcardListFragment.newInstance());
                                }
                            }
                        });
                        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        //ダイアログ出力
                        builder.show();
                    });
                    return true;
                case R.id.btnDelete:
                    ImageView deleteBtn = view.findViewById(R.id.btnDelete);
                    id = Long.parseLong(cursor.getString(columnIndex));

                    deleteBtn.setOnClickListener((View v) -> {
                        //削除ボタンが押された場合
                        LayoutInflater inflater = getActivity().getLayoutInflater();
                        View dialogView = inflater.inflate(R.layout.dialog_delete_check, null, false);
                        //ダイアログ作成
                        builder = new AlertDialog.Builder(getActivity());
                        builder.setView(dialogView);

                        builder.setPositiveButton(R.string.dialogDeleteTitle, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                _helper = new DatabaseHelper(getActivity());
                                SQLiteDatabase db = _helper.getWritableDatabase();
                                //保存領域に接続
                                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

                                String msg = "";
                                FlashcardTitleDAO.delete(db, id);
                                FlashcardDAO.flashcardTitledelete(db, id);
                                Cursor cursor = FlashcardTitleDAO.findAll(db, myPrefs.getString("userId", null));
                                list(cursor);
                                msg = "削除が完了しました";
                                Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                            }
                        });

                        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });

                        //ダイアログ出力
                        builder.create().show();
                    });
                    return true;
            }
            return false;
        }
    }

    /**
     * 単語帳のリストビューのカスタムビューバインダークラス。
     */
    private class DialogCustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch (view.getId()) {
                case R.id.right:
                    TextView right = (TextView)view;
                    right.setText(cursor.getString(columnIndex));

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)right.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)right.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }
                    return true;
                case R.id.left:
                    TextView left = (TextView)view;
                    left.setText(cursor.getString(columnIndex));
                    return true;
            }
            return false;
        }
    }

    //リストを出力するメソッド
    private void list(Cursor cursor){
        ListView problemList = view.findViewById(R.id.dialogReportList);
        TextView count = view.findViewById(R.id.titleCount6);

        String[] from = {"title", "_id", "_id", "_id"};
        int[] to = {R.id.uploadTitle, R.id.uploadImage, R.id.edit, R.id.btnDelete};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(getActivity(), R.layout.upload, cursor, from, to, 0);
        adapter.setViewBinder(new CustomViewBinder());
        problemList.setAdapter(adapter);
        count.setText(cursor.getCount() + "件検出");
    }

    //タイトルダイアログの作成メソッド
    public void titleDialog(long idNo){
        //データベース接続
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

        //ダイアログ作成
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_flashcard_title, null, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(dialogView);

        EditText etFlashcardTitle = dialogView.findViewById(R.id.etFlashcardTitle);
        TextView dialogFlashcardBtnAdd = dialogView.findViewById(R.id.dialogProblemBtnAdd);

        if(idNo != 0){
            //タイトル編集ボタンが押された場合
            FlashcardTitle result = FlashcardTitleDAO.findIdByPK(db, idNo);
            TextView textDialogProblemTitle = dialogView.findViewById(R.id.textFlashcardTitle);

            textDialogProblemTitle.setText("タイトル編集");
            dialogFlashcardBtnAdd.setText("変更");
            etFlashcardTitle.setText(result.getTitle());
        }
        TextView btnCansel = dialogView.findViewById(R.id.btnCansel);

        //ダイアログ出力
        AlertDialog dialog = builder.show();

        dialogFlashcardBtnAdd.setOnClickListener(parts -> {
            //追加or変更ボタンが押された場合
            String strTitle = etFlashcardTitle.getText().toString();
            if(strTitle.equals("")){
                etFlashcardTitle.setError("値を入力してください");
                flg = 1;
            }else{
                flg = 0;
            }
            if(flg == 0){

                //公式かを識別する
                int formula = UserDAO.formulaMarkFindByPK(db, myPrefs.getString("userId", null));
                if(idNo != 0){
                    //変更ボタンが押された場合
                    FlashcardTitleDAO.update(db, idNo, strTitle);
                    Toast.makeText(getActivity(), "変更しました", Toast.LENGTH_SHORT).show();
                }else{
                    //追加ボタンが押された場合
                    FlashcardTitleDAO.insert(db, myPrefs.getString("userId", null), strTitle, formula);
                    Toast.makeText(getActivity(), "追加しました", Toast.LENGTH_SHORT).show();
                }

                dialog.dismiss();
                Cursor cursor = FlashcardTitleDAO.findAll(db, myPrefs.getString("userId", null));
                list(cursor);
            }
        });
        btnCansel.setOnClickListener(parts -> {
            //キャンセルボタンが押された場合
            dialog.dismiss();
        });
    }

    /**
     * 非同期でサーバにポストを開始するメソッド
     * @param msg
     * @param title
     * @param formula
     * @param flashcardJson
     */
    @UiThread
    private void sendPastData(long id, String msg, String userId, String title, int formula, String flashcardJson){
        Looper mainLooper = Looper.getMainLooper();
        Handler handler = HandlerCompat.createAsync(mainLooper);
        BackgroundExecutor backgroundPostAccess = new BackgroundExecutor(handler, id, msg, userId, title, formula, flashcardJson);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.submit(backgroundPostAccess);
    }

    /**
     * 非同期でサーバにポストするためのクラス。
     */
    private class BackgroundExecutor implements Runnable{
        /**
         * ハンドラオブジェクト。
         */
        private final Handler _handler;
        /**
         * アップロードメッセージ
         */
        private final Long _id;
        private final String _msg;
        private final String _userId;
        private final String _title;
        private final String _formula;
        private final String _flashcardJson;

        /**
         * コンストラクタ。
         * 非同期でサーバにポストするのに必要な情報を取得する。
         * @param handler
         * @param msg
         */
        public BackgroundExecutor(Handler handler, Long id, String msg, String userId, String title, int formula, String flashcardJson){
            _handler = handler;
            _id = id;
            _msg = msg;
            _userId = userId;
            _title = title;
            _formula = String.valueOf(formula);
            _flashcardJson = flashcardJson;
        }

        @WorkerThread
        @Override
        public void run(){
            String postData = "titleId=" + _id + "&msg=" + _msg + "&userId=" + _userId + "&title=" + _title + "&formula=" + _formula + "&flashcardJson=" + _flashcardJson + "&action=edit";
            HttpURLConnection con = null;
            String err = "";

            try {
                URL url = new URL(ACCESS_URL);
                con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setConnectTimeout(5000);
                con.setReadTimeout(5000);
                con.setDoOutput(true);
                OutputStream os = con.getOutputStream();
                os.write(postData.getBytes());
                os.flush();
                os.close();
                int status = con.getResponseCode();
                if(status != 200){
                    throw new IOException("ステータスコード:" + status);
                }
            }
            catch (SocketTimeoutException ex){
                err = getString(R.string.msg_err_timeout);
                Log.e(DEBUG_TAG, "タイムアウト", ex);
            }
            catch (MalformedURLException ex){
                err = getString(R.string.msg_err_send);
                Log.e(DEBUG_TAG, "URL変換失敗", ex);
            }
            catch (IOException ex){
                err = getString(R.string.msg_err_send);
                Log.e(DEBUG_TAG, "通信失敗", ex);
            }
            finally {
                if(con != null){
                    con.disconnect();
                }
            }
        }
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
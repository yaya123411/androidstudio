package local.hal.st31.android.studyapplication3.Database;

public class FlashcardInterrupt {
    /**
     * id
     */
    private long _id;
    /**
     * 中断したページ
     */
    private String _page;
    /**
     * 覚えたかのフラグ
     */
    private int _settingRememberFlg;
    /**
     * 中断した時間
     */
    private String _updateTime;

    //以下アクセサメソッド

    public long getId(){
        return _id;
    }
    public void setId(long id){
        _id = id;
    }
    public String getPage(){
        return _page;
    }
    public void setPage(String page){
        _page = page;
    }
    public int getSettingRememberFlg(){
        return _settingRememberFlg;
    }
    public void setSettingRememberFlg(int settingRememberFlg){
        _settingRememberFlg = settingRememberFlg;
    }
    public String getUpdateTime(){
        return _updateTime;
    }
    public void setUpdateTime(String updateTime){
        _updateTime = updateTime;
    }
}

package local.hal.st31.android.studyapplication3;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;

import androidx.appcompat.app.ActionBar;
import androidx.constraintlayout.helper.widget.Carousel;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import local.hal.st31.android.studyapplication3.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //ナビゲーションドロワーレイアウト
        setSupportActionBar(binding.appBarMain.toolbar);
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_share, R.id.nav_download, R.id.nav_account)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //保存領域に接続
        SharedPreferences myPrefs = getSharedPreferences("save", MODE_PRIVATE);
        ActionBar actionBar = getSupportActionBar();

        if(myPrefs.getString("menu","").equals("ログイン")){
            //ログイン(LoginFragment)のメニュー
            if (actionBar != null) {
                //actionバーを消す
                actionBar.hide();
            }
        }else if(myPrefs.getString("menu","").equals("アカウント")){
            //アカウント(AccountFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_account, menu);
            if (actionBar != null) {
                actionBar.show();
            }
        }else if(myPrefs.getString("menu","").equals("問題タイトルリスト")){
            //問題タイトルリスト(ProblemMakeFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_problem_make, menu);
        }else if(myPrefs.getString("menu","").equals("問題リスト")){
            //問題リスト(ProblemAddFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_problem_add, menu);
        }else if(myPrefs.getString("menu","").equals("問題編集")){
            //問題編集(ProblemAddEditFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_audio_camera, menu);
        }else if(myPrefs.getString("menu","").equals("問題出題")){
            //問題出題(ProblemFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_problem, menu);
        }else if(myPrefs.getString("menu","").equals("問題出題2画面メモリスト")){
            //問題出題のメモ帳リストの拡大表示(ProblemFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_problem_two, menu);
        }else if(myPrefs.getString("menu","").equals("問題出題2画面メモ編集")){
            //問題出題2画面メモ編集画面(ProblemFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_problem_memo_edit_two, menu);
        }else if(myPrefs.getString("menu","").equals("問題出題2画面キャンバス")){
            //問題出題2画面キャンバス画面(ProblemFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_problem_canvas_two, menu);
        }else if(myPrefs.getString("menu","").equals("問題出題拡大表示メモリスト")){
            //問題出題のメモ帳リストの縮小表示(ProblemFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_problem_memo_list, menu);
        }else if(myPrefs.getString("menu","").equals("問題出題拡大表示メモ編集")){
            //問題出題のメモ帳リストの縮小表示(ProblemFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_problem_memo_edit, menu);
        }else if(myPrefs.getString("menu","").equals("問題出題拡大表示キャンバス")){
            //問題出題のメモ帳リストの縮小表示(ProblemFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_problem_canvas, menu);
        }else if(myPrefs.getString("menu","").equals("単語帳タイトルリスト")){
            //単語帳タイトルリスト(FlashcardTopFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_flashcard_top, menu);
        }else if(myPrefs.getString("menu","").equals("単語帳リスト")){
            //単語帳リスト(FlashcardListFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_problem_add, menu);
        }else if(myPrefs.getString("menu","").equals("単語帳")){
            //単語帳(FlashcardFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_problem, menu);
        }else if(myPrefs.getString("menu","").equals("成績タイトル一覧")){
            //成績タイトル一覧(GradesTopFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_grades_top, menu);
        }else if(myPrefs.getString("menu","").equals("成績一覧")){
            //成績一覧(GradesDetailedFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_grades_detailed, menu);
        }else if(myPrefs.getString("menu","").equals("成績詳細")){
            //成績詳細(GradesMoreDetailedFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_grades_more_detailed, menu);
        }else if(myPrefs.getString("menu","").equals("メモ帳タイトルリスト")){
            //メモ帳タイトルリスト(MemoTopFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_memo_list, menu);
        }else if(myPrefs.getString("menu","").equals("メモ帳編集")){
            //成績詳細(GradesMoreDetailedFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_memo_edit, menu);
        }if(myPrefs.getString("menu","").equals("キャンバス")){
            //成績詳細(GradesMoreDetailedFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_canvas, menu);
        }if(myPrefs.getString("menu","").equals("共有")){
            //共有(ShareFragment)のメニュー
            getMenuInflater().inflate(R.menu.menu_share, menu);
        }else{
            getMenuInflater().inflate(R.menu.menu_default, menu);
            if (actionBar != null) {
                //actionバーを出現させる
                actionBar.show();
            }
        }
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}
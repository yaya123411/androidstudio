package local.hal.st31.android.studyapplication3.Database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FlashcardDAO {
    /**
     * 単語の全てのデータを取得するメソッド
     * @param db
     * @return
     */
    public static Cursor findAll(SQLiteDatabase db, String userId) {
        String sql = "SELECT * FROM flashcard WHERE userId = '" + userId + "' ORDER BY updateTime DESC";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * 特定の単語のデータを取得するメソッド
     * @param db
     * @param id
     * @return
     */
    public static Flashcard findIdByPK(SQLiteDatabase db, long id) {
        String sql = "";
        sql = "SELECT * FROM flashcard WHERE _id = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);
        Flashcard result = null;
        if (cursor.moveToFirst()) {
            int idxId = cursor.getColumnIndex("_id");
            String flashcardId = cursor.getString(idxId);
            int idxFront = cursor.getColumnIndex("front");
            String front = cursor.getString(idxFront);
            int idxBack = cursor.getColumnIndex("back");
            String back = cursor.getString(idxBack);
            int idxRemember = cursor.getColumnIndex("remember");
            String remember = cursor.getString(idxRemember);

            result = new Flashcard();
            result.setId(id);
            result.setFront(front);
            result.setBack(back);
            result.setRemember(Integer.parseInt(remember));
        }
        return result;
    }

    /**
     * 単語を追加するメソッド
     * @param db
     * @param userId
     * @param flashcardTitleId
     * @param front
     * @param back
     * @return
     */
    public static long insert(SQLiteDatabase db, String userId, long flashcardTitleId, String front, String back) {
        String sql = "INSERT INTO flashcard (userId, flashcardTitleId, front, back, remember, updateTime) VALUES (?, ?, ?, ?, 0, datetime('now'))";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, userId);
        stmt.bindLong(2, flashcardTitleId);
        stmt.bindString(3, front);
        stmt.bindString(4, back);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * 単語を更新するメソッド
     * @param db
     * @param flashcardId
     * @param front
     * @param back
     * @return
     */
    public static int update(SQLiteDatabase db, long flashcardId, String front, String back) {
        String sql = "UPDATE flashcard SET front = ?, back = ?, updateTime = datetime('now') WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, front);
        stmt.bindString(2, back);
        stmt.bindLong(3, flashcardId);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }

    /**
     * 単語を削除するメソッド
     * @param db
     * @param problemId
     * @return
     */
    public static int delete(SQLiteDatabase db, long problemId) {
        String sql = "DELETE FROM flashcard WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, problemId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    /**
     * 単語数を取得
     * @param db
     * @param flashcardTitleId
     * @return
     */
    public static String countFlashcard(SQLiteDatabase db, long flashcardTitleId ,int rememberFlg) {
        //id=_id
        String sql = "";
        if(rememberFlg == 0){
            //覚えたからも出題する
            sql = "SELECT COUNT(*) as count FROM flashcard WHERE flashcardTitleId = '" + flashcardTitleId + "'";
        }else{
            //覚えたを省く
            sql = "SELECT COUNT(*) as count FROM flashcard WHERE flashcardTitleId = '" + flashcardTitleId + "' and remember = 0";
        }
        Cursor cursor = db.rawQuery(sql, null);
        String result = null;
        if (cursor.moveToFirst()) {
            int idxCount = cursor.getColumnIndex("count");
            result = cursor.getString(idxCount);
        }
        //無かった場合0が返ってくる
        return result;
    }

    /**
     * 単語帳を取得するメソッド
     * @param db
     * @param flashcardTitleId
     * @return
     */
    public static Cursor findTitleAll(SQLiteDatabase db, long flashcardTitleId) {
        String sql = "";
        //ダウンロードして得た単語帳だった場合
        sql = "SELECT * FROM flashcard WHERE flashcardTitleId = '" + flashcardTitleId + "' ORDER BY updateTime DESC";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * アップロードボタンが押された単語帳リストの単語帳をまとめるメソッド
     * @param db
     * @param flashcardTitleId
     * @return
     */
    public static ArrayList<Map<String, String>> findByTitleId(SQLiteDatabase db, long flashcardTitleId) {
        String sql = "";
        ArrayList<Map<String, String>> result = new ArrayList<>();
        sql = "SELECT front,back FROM flashcard WHERE flashcardTitleId = '" + flashcardTitleId + "' ORDER BY updateTime DESC";
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        for (int i = 0; i < cursor.getCount(); i++) {
            Map<String, String> record = new HashMap<>();
            record.put("front", cursor.getString(0));
            record.put("back", cursor.getString(1));
            result.add(record);
            cursor.moveToNext();
        }
        return result;
    }

    public static ArrayList<String> flashcardIdAll(SQLiteDatabase db, long flashcardTitleId, int rememberFlg){
        String sql = "";
        if(rememberFlg == 0){
            //覚えたからも出題する
            sql = "SELECT _id FROM flashcard WHERE flashcardTitleId = '" + flashcardTitleId + "'";
        }else{
            //覚えたを省く
            sql = "SELECT _id FROM flashcard WHERE flashcardTitleId = '" + flashcardTitleId + "' and remember = 0";
        }
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        ArrayList<String> list = new ArrayList<>();
        for (int i = 0; i < cursor.getCount(); i++) {
            list.add(cursor.getString(0));
            cursor.moveToNext();
        }
        return list;
    }

    //-----------------------------------------ダウンロード------------------------------------
    //ダウンロードした単語帳を単語帳テーブルに追加する
    //flashcardTitleIdはchildId
    public static long shareFlashcardInsert(SQLiteDatabase db, String userId, long flashcardTitleId, String front, String back){
        String sql = "INSERT INTO flashcard (userId, flashcardTitleId, front, back, remember, updateTime) VALUES (?, ?, ?, ?, 0, datetime('now'))";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, userId);
        stmt.bindLong(2, flashcardTitleId);
        stmt.bindString(3, front);
        stmt.bindString(4, back);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * ダウンロードした単語帳のデータを取得
     * @param db
     * @param downloadId
     * @return
     */
    public static ArrayList<Flashcard> downloadAddFlashcardTitle(SQLiteDatabase db, long downloadId){
        ArrayList<Flashcard> arrayList = new ArrayList<>();
        String sql = "SELECT flashcard.flashcardTitleId,flashcard.front, flashcard.back, flashcard.updateTime FROM download LEFT OUTER JOIN flashcard ON download.parentTitleId = flashcard.flashcardTitleId WHERE download._id = '" + downloadId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        CharSequence[] list = new CharSequence[cursor.getCount()];
        Flashcard result = null;
        cursor.moveToFirst();
        for (int i = 0; i < list.length; i++) {
            String flashcardTitleId = cursor.getString(0);
            String front = cursor.getString(1);
            String back = cursor.getString(2);
            String updateTime = cursor.getString(3);

            result = new Flashcard();
            result.setFlashcardTitleId(Long.parseLong(String.valueOf(flashcardTitleId)));
            result.setFront(front);
            result.setBack(back);
            result.setUpdateTime(updateTime);
            arrayList.add(result);
            cursor.moveToNext();
        }
        return arrayList;
    }

    public static int titleIdUpdate(SQLiteDatabase db, long downloadId, long titleId) {
        String sql = "UPDATE flashcard SET flashcardTitleId = ? WHERE downloadId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, titleId);
        stmt.bindLong(2, downloadId);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }

    /**
     * 単語帳のタイトルが削除された時のメソッド
     * @param db
     * @param flashcardTitle
     * @return
     */
    public static int flashcardTitledelete(SQLiteDatabase db, long flashcardTitle) {
        String sql = "DELETE FROM flashcard WHERE flashcardTitleId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, flashcardTitle);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    /**
     * ダウンロード済みの単語帳をすべて削除する
     * @param db
     * @param downloadId
     * @return
     */
    public static int deleteByDownload(SQLiteDatabase db, long downloadId) {
        String sql = "DELETE FROM flashcard WHERE flashcardTitleId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, downloadId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    //------------------------------覚えた-----------------------------------
    /**
     * 覚えたにチェックを入れられた場合のメソッド
     * @param db
     * @param flashcardId
     * @param rememberFlg
     * @return
     */
    public static int rememberUpdate(SQLiteDatabase db, long flashcardId ,int rememberFlg) {
        String sql = "UPDATE flashcard SET remember = ? WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, rememberFlg);
        stmt.bindLong(2, flashcardId);
        int insertedId = stmt.executeUpdateDelete();
        return insertedId;
    }

    //--------------------------------------------メニュー---------------------------------
    public static Cursor findSerch(SQLiteDatabase db, long flashcardTitleId, String serch, String sort, int downloadFlg){
        String sql = "";
        String where = "";
        String orderBy = "";

        if(!serch.equals("")){
            //検索
            where = " AND front like '%" + serch + "%'";
        }
        if(downloadFlg == 0){
            where += " AND downloadId = 0";
        }else{
            where += " AND downloadId <> 0";
        }
        if(!sort.equals("")){
            //並び替え
            if(sort.equals("更新順")) {
                orderBy = " ORDER BY updateTime DESC";
            }else if(sort.equals("新しい順")){
                orderBy = " ORDER BY _id DESC";
            }else if(sort.equals("古い順")){
                orderBy = " ORDER BY _id ASC";
            }
        }else{
            orderBy = " ORDER BY updateTime DESC";
        }

        sql = "SELECT * FROM flashcard WHERE flashcardTitleId = '" + flashcardTitleId + "'" + where + orderBy;
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }
}


package local.hal.st31.android.studyapplication3.Database;

public class Memo {
    /**
     * id
     */
    private long _id;
    /**
     * タイトル
     */
    private String _title;
    /**
     * 内容
     */
    private String _note;
    /**
     * 更新日
     */
    private String _date;

    //以下アクセサメソッド

    public long getId(){
        return _id;
    }
    public void setId(long id){
        _id = id;
    }
    public String getTitle(){
        return _title;
    }
    public void setTitle(String title){
        _title = title;
    }
    public String getNote(){
        return _note;
    }
    public void setNote(String note){
        _note = note;
    }
    public String getDate(){
        return _date;
    }
    public void setDate(String date){
        _date = date;
    }
}


package local.hal.st31.android.studyapplication3.ui.home.Memo;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import local.hal.st31.android.studyapplication3.Database.Canvas;
import local.hal.st31.android.studyapplication3.Database.CanvasDAO;
import local.hal.st31.android.studyapplication3.Database.CanvasLineDAO;
import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.Memo;
import local.hal.st31.android.studyapplication3.Database.MemoDAO;
import local.hal.st31.android.studyapplication3.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CanvasFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CanvasFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    View view;
    CanvasView cv;

    //フラグメントを呼び出す
    public static CanvasFragment newInstance(Long idNo){
// Fragemnt01 インスタンス生成
        CanvasFragment CanvasFragment = new CanvasFragment();

        // Bundle にパラメータを設定
        Bundle args = new Bundle();
        args.putLong("idNo", idNo);
        CanvasFragment.setArguments(args);

        return CanvasFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        Bundle args = getArguments();

        View view = inflater.inflate(R.layout.fragment_canvas,
                container, false);

        this.view = view;
        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        cv = (CanvasView) view.findViewById(R.id.canvas_view);

        ArrayList<Long> canvasId = CanvasLineDAO. findCanvasId(db, args.getLong("idNo"));
        ArrayList<Canvas> result = CanvasDAO.findIdByPK(db, args.getLong("idNo"));
        ArrayList<ArrayList<Float>> resultLine = CanvasLineDAO.findIdByPK(db, canvasId);
        if(result.size() != 0){
            ArrayList<Integer> ArrayColor = new ArrayList<>();  // カラーリスト
            ArrayList<ArrayList<Float>> coordinateParent = new ArrayList<>(); //座標を保存する

            for (int i=0; i<result.size(); i++){
                ArrayList<Float> coordinateChaild = new ArrayList<>();

                coordinateChaild.add(result.get(i).getStartGetX());
                coordinateChaild.add(result.get(i).getStartGetY());
                coordinateChaild.add(result.get(i).getFinishGetX());
                coordinateChaild.add(result.get(i).getFinishGetY());

                coordinateParent.add(coordinateChaild);
                ArrayColor.add(result.get(i).getColor());
            }
            CanvasView.setCoordinate(coordinateParent);
            CanvasView.setColorList(ArrayColor);
            CanvasView.setLine(resultLine);
        }

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "キャンバス");
        editor.commit();
        setHasOptionsMenu(true);

        return view;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        ImageView pen = (ImageView) view.findViewById(R.id.pen);
        Integer color;
        boolean returnVal = true;
        int itemId = item.getItemId();
        switch(itemId) {
            case R.id.menuBack:
                //一つ戻るボタンが押された場合
                color = cv.oneReturn();
                if(color == Color.BLACK){
                    //ペンの色が黒の場合
                    pen.setColorFilter(Color.parseColor("#000000"), PorterDuff.Mode.SRC_IN);
                }else if(color == Color.BLUE){
                    //ペンの色が青の場合
                    pen.setColorFilter(Color.parseColor("#0000ff"), PorterDuff.Mode.SRC_IN);
                }else if(color == Color.GREEN){
                    //ペンの色が緑の場合
                    pen.setColorFilter(Color.parseColor("#008000"), PorterDuff.Mode.SRC_IN);
                }else if(color == Color.YELLOW){
                    //ペンの色が黄色の場合
                    pen.setColorFilter(Color.parseColor("#ffff00"), PorterDuff.Mode.SRC_IN);
                }else if(color == Color.RED){
                    //ペンの色が赤の場合
                    pen.setColorFilter(Color.parseColor("#ff0000"), PorterDuff.Mode.SRC_IN);
                }
                break;
            case R.id.menuAdvance:
                //一つ進むボタンが押された場合
                cv.oneAdvance();
                break;
            case R.id.menuSave:
                //保存ボタンが押された場合
                _helper = new DatabaseHelper(getActivity());
                SQLiteDatabase db = _helper.getWritableDatabase();

                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = myPrefs.edit();

                Bundle args = getArguments();

                ArrayList<ArrayList<Float>> coordinateParent = CanvasView.getCoordinate();
                ArrayList<ArrayList<Float>> lineParent = CanvasView.getLine();
                ArrayList<Integer> colorList = CanvasView.getColorList();

                if(args.getLong("idNo") != 0){
                    editor.putLong("memoTitleId", args.getLong("idNo"));
                    editor.commit();
                }

                Memo memo = MemoDAO.findIdByPK(db, myPrefs.getLong("memoTitleId", 0));

                if(memo == null){
                    //新規登録するならば
                    //ダイアログ作成
                    LayoutInflater inflater = getActivity().getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.dialog_flashcard_title, null, false);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setView(dialogView);

                    TextView dialogCanvasBtnAdd = dialogView.findViewById(R.id.dialogProblemBtnAdd);
                    TextView btnCansel = dialogView.findViewById(R.id.btnCansel);
                    EditText etCanvasTitle = dialogView.findViewById(R.id.etFlashcardTitle);

                    //ダイアログ出力
                    AlertDialog dialog = builder.show();

                    dialogCanvasBtnAdd.setOnClickListener(parts -> {
                        //追加ボタンが押された場合
                        int flg = 0;
                        String strTitle = etCanvasTitle.getText().toString();
                        if(strTitle.equals("")){
                            etCanvasTitle.setError("値を入力してください");
                            flg = 1;
                        }else{
                            flg = 0;
                        }
                        if(flg == 0){
                            long memoId = MemoDAO.insert(db, myPrefs.getString("userId", null), strTitle, "");
                            for(int i=0; i<coordinateParent.size(); i++){
                                long canvasId = CanvasDAO.insert(db, memoId, coordinateParent.get(i).get(0), coordinateParent.get(i).get(1), coordinateParent.get(i).get(2), coordinateParent.get(i).get(3), colorList.get(i));
                                for(int j=0; j<lineParent.get(i).size()/2; j++){
                                    CanvasLineDAO.insert(db, canvasId, memoId, lineParent.get(i).get(j*2), lineParent.get(i).get(j*2+1));
                                }
                            }
                            editor.putLong("memoAction", 2);
                            editor.putLong("memoTitleId", memoId);
                            editor.commit();

                            dialog.dismiss();
                            Toast.makeText(this.getActivity(), "保存しました", Toast.LENGTH_SHORT).show();
                        }
                    });
                    btnCansel.setOnClickListener(parts -> {
                        //キャンセルボタンが押された場合
                        dialog.dismiss();
                    });
                }else{
                    //上書き保存をするならば
                    CanvasDAO.delete(db, myPrefs.getLong("memoTitleId", 0));
                    CanvasLineDAO.deleteByMemoId(db, myPrefs.getLong("memoTitleId", 0));
                    for(int i=0; i<coordinateParent.size(); i++){
                        long canvasId = CanvasDAO.update(db, myPrefs.getLong("memoTitleId", 0), coordinateParent.get(i).get(0), coordinateParent.get(i).get(1), coordinateParent.get(i).get(2), coordinateParent.get(i).get(3), colorList.get(i));
                        for(int j=0; j<lineParent.get(i).size()/2; j++){
                            CanvasLineDAO.update(db, canvasId, myPrefs.getLong("memoTitleId", 0), lineParent.get(i).get(j*2), lineParent.get(i).get(j*2+1));
                        }
                    }
                    Toast.makeText(this.getActivity(), "保存しました", Toast.LENGTH_SHORT).show();
                }
                break;
        }
        return returnVal;
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        //-- Button関連
        ImageView btnClear = (ImageView) view.findViewById(R.id.clear);
        ImageView pen = (ImageView) view.findViewById(R.id.pen);
        ImageView btnRed = (ImageView) view.findViewById(R.id.red);
        ImageView btnYellow = (ImageView) view.findViewById(R.id.yellow);
        ImageView btnGreen = (ImageView) view.findViewById(R.id.green);
        ImageView btnBlue = (ImageView) view.findViewById(R.id.blue);
        ImageView btnBlack = (ImageView) view.findViewById(R.id.black);

        cv.penColor(Color.BLACK);

        pen.setColorFilter(Color.parseColor("#000000"), PorterDuff.Mode.SRC_IN);
        //- 動作設定
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv.allDelete();
            }
        });

        //- 動作設定
        btnRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv.penColor(Color.RED);
                pen.setColorFilter(Color.parseColor("#ff0000"), PorterDuff.Mode.SRC_IN);
            }
        });

        //- 動作設定
        btnYellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv.penColor(Color.YELLOW);
                pen.setColorFilter(Color.parseColor("#ffff00"), PorterDuff.Mode.SRC_IN);
            }
        });

        //- 動作設定
        btnGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv.penColor(Color.GREEN);
                pen.setColorFilter(Color.parseColor("#008000"), PorterDuff.Mode.SRC_IN);
            }
        });

        //- 動作設定
        btnBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv.penColor(Color.BLUE);
                pen.setColorFilter(Color.parseColor("#0000ff"), PorterDuff.Mode.SRC_IN);
            }
        });

        //- 動作設定
        btnBlack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv.penColor(Color.BLACK);
                pen.setColorFilter(Color.parseColor("#000000"), PorterDuff.Mode.SRC_IN);
            }
        });

        //戻るボタンが押された場合
        ImageView btnBack = view.findViewById(R.id.canvasBack);
        btnBack.setOnClickListener((View v) -> {
            editor.putString("menu", "");
            editor.commit();
            back();
        });
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
package local.hal.st31.android.studyapplication3.ui.home;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.helper.widget.Carousel;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.SampleDate;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.account.LoginFragment;
import local.hal.st31.android.studyapplication3.ui.home.Flashcard.FlashcardTopFragment;
import local.hal.st31.android.studyapplication3.ui.home.Grades.GradesTopFragment;
import local.hal.st31.android.studyapplication3.ui.home.Memo.MemoTopFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemMake.ProblemMakeFragment;

public class HomeFragment extends Fragment {
    View view;
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    int title[] = {
            R.string.btn_problem_make,
            R.string.btn_flashcard,
            R.string.btn_grades
    };

    int image[] = {
            R.drawable.problem,
            R.drawable.flashcard,
            R.drawable.grades
    };

    int colors[] = {
            Color.parseColor("#9C4B8F"),
            Color.parseColor("#945693"),
            Color.parseColor("#8C6096")
    };

    int backgroundColors[] = {
            Color.parseColor("#79cece"),
            Color.parseColor("#67afa9"),
            Color.parseColor("#ffcd44")
    };

    public ArrayList<View> textViews = new ArrayList<>();
    int numImages;
    //フラグメントを呼び出す
    public static HomeFragment newInstance(){
// Fragemnt01 インスタンス生成
        HomeFragment HomeFragment = new HomeFragment();

        return HomeFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view;

        //SharedPreferencesで保存した値の取得
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        view = inflater.inflate(R.layout.fragment_home,
                container, false);

        //ダウンロードされた問題だった場合のフラグ(ダウンロードされていた場合=1、そうでない場合=0)
        editor.putInt("downloadFlg", 0);
        editor.putString("menu", "ホーム");
        editor.commit();
        setHasOptionsMenu(true);

        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });
        this.view = view;

        ImageView imageView = view.findViewById(R.id.image);
        imageView.setImageResource(image[0]);
        view.findViewById(R.id.parent).setBackgroundColor(backgroundColors[0]);
        view.findViewById(R.id.image).startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.home));
        TextView textView = (TextView) view.findViewById(R.id.imageView2);
        textView.setTextSize(25.0f);

        setupCarousel();

        return view;
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //保存領域に接続
        SharedPreferences myPrefs = this.getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

        if(myPrefs.getString("userId",null) == null){
            //ログインしていなかった場合
            migrate(LoginFragment.newInstance());
        }

        Button imageView0 = view.findViewById(R.id.imageView0);
        if(imageView0 != null){
            imageView0.setOnClickListener((View v) -> {
                if(imageView0.getText().toString().equals("問題出題")){
                    migrate(ProblemMakeFragment.newInstance());
                }else if(imageView0.getText().toString().equals("単語帳")){
                    migrate(FlashcardTopFragment.newInstance());
                }else if(imageView0.getText().toString().equals("成績")){
                    migrate(GradesTopFragment.newInstance());
                }
            });
        }
        Button imageView1 = view.findViewById(R.id.imageView1);
        if(imageView1 != null){
            imageView1.setOnClickListener((View v) -> {
                if(imageView1.getText().toString().equals("問題出題")){
                    migrate(ProblemMakeFragment.newInstance());
                }else if(imageView1.getText().toString().equals("単語帳")){
                    migrate(FlashcardTopFragment.newInstance());
                }else if(imageView1.getText().toString().equals("成績")){
                    migrate(GradesTopFragment.newInstance());
                }
            });
        }
        Button imageView2 = view.findViewById(R.id.imageView2);
        if(imageView2 != null){
            imageView2.setOnClickListener((View v) -> {
                if(imageView2.getText().toString().equals("問題出題")){
                    migrate(ProblemMakeFragment.newInstance());
                }else if(imageView2.getText().toString().equals("単語帳")){
                    migrate(FlashcardTopFragment.newInstance());
                }else if(imageView2.getText().toString().equals("成績")){
                    migrate(GradesTopFragment.newInstance());
                }
            });
        }
        Button imageView3 = view.findViewById(R.id.imageView3);
        if(imageView3 != null){
            imageView3.setOnClickListener((View v) -> {
                if(imageView3.getText().toString().equals("問題出題")){
                    migrate(ProblemMakeFragment.newInstance());
                }else if(imageView3.getText().toString().equals("単語帳")){
                    migrate(FlashcardTopFragment.newInstance());
                }else if(imageView3.getText().toString().equals("成績")){
                    migrate(GradesTopFragment.newInstance());
                }
            });
        }
        Button imageView4 = view.findViewById(R.id.imageView4);
        if(imageView4 != null){
            imageView4.setOnClickListener((View v) -> {
                if(imageView4.getText().toString().equals("問題出題")){
                    migrate(ProblemMakeFragment.newInstance());
                }else if(imageView4.getText().toString().equals("単語帳")){
                    migrate(FlashcardTopFragment.newInstance());
                }else if(imageView4.getText().toString().equals("成績")){
                    migrate(GradesTopFragment.newInstance());
                }
            });
        }
        //メモボタンが押された場合
        FloatingActionButton memo = view.findViewById(R.id.memo);
        if(memo != null){
            memo.setOnClickListener((View v) -> {
                migrate(MemoTopFragment.newInstance());
            });
        }
    }

    private void setupCarousel() {
        Carousel carousel = view.findViewById(R.id.carousel);
        if (carousel == null) {
            return;
        }
        numImages = title.length;

        carousel.setAdapter(new Carousel.Adapter() {
            @Override
            public int count() {
                return numImages;
            }

            @Override
            public void populate(View view, int index) {
                TextView textView = (TextView) view;
                textView.setText(title[index]);
                textView.setBackgroundColor(colors[index]);
                textViews.add(view);
            }

            @Override
            public void onNewItem(int index) {
                ImageView imageView = view.findViewById(R.id.image);
                imageView.setImageResource(image[index]);
                for(int i=0; i<5; i++){
                    if(((TextView)textViews.get(i)).getText().toString().equals(getString(title[index]))){
                        TextView textView = (TextView) textViews.get(i);
//                        textView.setTextSize(20.0f);
                        ValueAnimator animator = ValueAnimator.ofFloat(40.0f, 70.0f);
//                        animator.setDuration(duration);
                        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                            @Override
                            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                                float animatedValue = (float) valueAnimator.getAnimatedValue();
                                textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, animatedValue);
                            }
                        });
                        animator.start();
                        view.findViewById(R.id.parent).setBackgroundColor(backgroundColors[index]);
                    }
                }
            }
        });
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
package local.hal.st31.android.studyapplication3.Database;

public class MistakeProblem {
    /**
     * id
     */
    private long _id;
    /**
     * ユーザーID
     */
    private String _userId;
    /**
     * タイトルID
     */
    private long _titleId;
    /**
     * 問題番号
     */
    private long _problemId;
    /**
     * 同じタイトルで何回目の問題化を格納
     */
    private Integer _count;
    /**
     * 問題
     */
    private String _question;
    /**
     * 答え
     */
    private String _reply;
    /**
     * 回答スタイル
     */
    private String _choice;
    /**
     * 記述式の答え
     */
    private String _choiceA;
    private String _choiceB;
    private String _choiceC;
    private String _choiceD;
    private String _choiceE;
    private String _choiceF;
    private String _choiceG;
    /**
     * 自分の回答
     */
    private String _myReply;
    /**
     * 解説
     */
    private String _explanation;

    //以下アクセサメソッド

    public long getId(){
        return _id;
    }
    public void setId(long id){
        _id = id;
    }
    public String getUserId(){
        return _userId;
    }
    public void setUserId(String userId){
        _userId = userId;
    }
    public long getTitleId(){
        return _titleId;
    }
    public void setTitleId(long titleId){
        _titleId = titleId;
    }
    public Integer getCount(){
        return _count;
    }
    public void setCount(Integer count){
        _count = count;
    }
    public long getProblemId(){
        return _problemId;
    }
    public void setProblemId(long problemId){
        _problemId = problemId;
    }
    public String getChoice(){
        return _choice;
    }
    public void setChoice(String choice){
        _choice = choice;
    }
    public String getChoiceA(){
        return _choiceA;
    }
    public void setChoiceA(String choiceA){
        _choiceA = choiceA;
    }
    public String getChoiceB(){
        return _choiceB;
    }
    public void setChoiceB(String choiceB){
        _choiceB = choiceB;
    }
    public String getChoiceC(){
        return _choiceC;
    }
    public void setChoiceC(String choiceC){
        _choiceC = choiceC;
    }
    public String getChoiceD(){
        return _choiceD;
    }
    public void setChoiceD(String choiceD){
        _choiceD = choiceD;
    }
    public String getChoiceE(){
        return _choiceE;
    }
    public void setChoiceE(String choiceE){
        _choiceE = choiceE;
    }
    public String getChoiceF(){
        return _choiceF;
    }
    public void setChoiceF(String choiceF){
        _choiceF = choiceF;
    }
    public String getChoiceG(){
        return _choiceG;
    }
    public void setChoiceG(String choiceG){
        _choiceG = choiceG;
    }
    public String getQuestion(){
        return _question;
    }
    public void setQuestion(String question){
        _question = question;
    }
    public String getReply(){
        return _reply;
    }
    public void setReply(String reply){
        _reply = reply;
    }
    public String getMyReply(){
        return _myReply;
    }
    public void setMyReply(String myReply){
        _myReply = myReply;
    }
    public String getExplanation(){
        return _explanation;
    }
    public void setExplanation(String explanation){
        _explanation = explanation;
    }
}


package local.hal.st31.android.studyapplication3.ui.share;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import local.hal.st31.android.studyapplication3.R;

/**
 * ST31 Androidサンプル11 ダイアログ
 *
 * シンプルなダイアログクラス。
 *
 * @author yaya2
 */
public class NotContemporaneousErrDialog extends DialogFragment {
    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        String err = getArguments().getString("err", null);
        Activity parent = getActivity();
        AlertDialog.Builder builder = new AlertDialog.Builder(parent);
        builder.setTitle(R.string.dialog_err);
        builder.setMessage(err);
        builder.setNegativeButton(R.string.menu_reload, new NegativeButtonClickListener());
        builder.setPositiveButton(R.string.btnCancel, new PositiveButtonClickListener());
        AlertDialog dialog = builder.create();
        return dialog;
    }

    /**
     * ダイアログの再読み込みボタンが押されたときの処理が記述されたメンバクラス。
     */
    private class NegativeButtonClickListener implements DialogInterface.OnClickListener{
        @Override
        public void onClick(DialogInterface dialog, int which){
        }
    }

    /**
     * ダイアログのキャンセルボタンが押されたときの処理が記述されたメンバクラス。
     */
    private class PositiveButtonClickListener implements DialogInterface.OnClickListener{
        @Override
        public void onClick(DialogInterface dialog, int which){
        }
    }
}
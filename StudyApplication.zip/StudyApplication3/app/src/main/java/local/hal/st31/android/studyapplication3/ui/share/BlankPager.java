package local.hal.st31.android.studyapplication3.ui.share;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.constraintlayout.helper.widget.Carousel;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.account.LoginFragment;
import local.hal.st31.android.studyapplication3.ui.home.Flashcard.FlashcardTopFragment;
import local.hal.st31.android.studyapplication3.ui.home.Grades.GradesTopFragment;
import local.hal.st31.android.studyapplication3.ui.home.Memo.MemoTopFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemMake.ProblemMakeFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link BlankPager#newInstance} factory method to
 * create an instance of this fragment.
 */
public class BlankPager extends Fragment {
    //フラグメントを呼び出す
    public static BlankPager newInstance(){
// Fragemnt01 インスタンス生成
        BlankPager BlankPager = new BlankPager();

        return BlankPager;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_blank_pager,
                container, false);
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        migrate(ShareFragment.newInstance());
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
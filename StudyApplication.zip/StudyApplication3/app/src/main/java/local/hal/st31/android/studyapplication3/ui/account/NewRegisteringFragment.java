package local.hal.st31.android.studyapplication3.ui.account;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.Memo;
import local.hal.st31.android.studyapplication3.Database.MemoDAO;
import local.hal.st31.android.studyapplication3.Database.User;
import local.hal.st31.android.studyapplication3.Database.UserDAO;
import local.hal.st31.android.studyapplication3.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link NewRegisteringFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NewRegisteringFragment extends Fragment {

    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;

    public static NewRegisteringFragment newInstance(){
// Fragemnt01 インスタンス生成
        NewRegisteringFragment NewRegisteringFragment = new NewRegisteringFragment();

        return NewRegisteringFragment;
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "ログイン");
        editor.commit();
        setHasOptionsMenu(true);

        return inflater.inflate(R.layout.fragment_new_registering,
                container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Button newRegisteringButton = view.findViewById(R.id.newRegisteringButton);
        //ログインボタンが押された場合
        newRegisteringButton.setOnClickListener( v -> {
            SharedPreferences myPrefs = this.getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

            //ユーザーID
            EditText etUserId = view.findViewById(R.id.etUserId);
            String strUserId = etUserId.getText().toString();
            //ユーザー名
            EditText etUserName = view.findViewById(R.id.etUserName);
            String strUserName = etUserName.getText().toString();
            //パスワード
            EditText etPassword = view.findViewById(R.id.etPassword);
            String strPassword = etPassword.getText().toString();
            //パスワード確認
            EditText etPasswordCheck = view.findViewById(R.id.etPasswordCheck);
            String strPasswordCheck = etPasswordCheck.getText().toString();
            int flg = 0;

            //ユーザーID
            if(strUserId.equals("")){
                //空白チェック
                etUserId.setError("値を入力してください");
                flg = 1;
            }
            //ユーザー名
            if(strUserName.equals("")){
                //空白チェック
                etUserName.setError("値を入力してください");
                flg = 1;
            }
            //パスワード
            if(strPassword.equals("")){
                //空白チェック
                etPassword.setError("値を入力してください");
                flg = 1;
            }else if(strPassword.length() < 8){
                //文字数チェック
                etPassword.setError("8文字以上入力してください");
                flg = 1;
            }
            //パスワード確認
            if(strPasswordCheck.equals("")){
                //空白チェック
                etPasswordCheck.setError("値を入力してください");
                flg = 1;
            }else if(!strPassword.equals(strPasswordCheck)){
                //入力チェック
                etPasswordCheck.setError("パスワードと一致しません");
                flg = 1;
            }

            if(flg == 0){
                _helper = new DatabaseHelper(this.getActivity());
                SQLiteDatabase db = _helper.getWritableDatabase();

                User result = UserDAO.findUserIdByPK(db, strUserId);

                if(result != null){
                    //被りチェック
                    etUserId.setError("既に登録されているIDです");
                    flg = 1;
                }

                if(flg == 0){
                    if(strUserId.length() >= 8){
                        if(strUserId.substring(0, 8).equals("kanrisya")){
                            //公式アカウントを設立した場合
                            UserDAO.insert(db, strUserId, strUserName, strPassword, 1);
                        }else{
                            //一般ユーザーを設立した場合
                            UserDAO.insert(db, strUserId, strUserName, strPassword, 0);
                        }
                    }else{
                        //一般ユーザーを設立した場合
                        UserDAO.insert(db, strUserId, strUserName, strPassword, 0);
                    }

                    Toast.makeText(this.getActivity(), "登録完了しました", Toast.LENGTH_SHORT).show();

                    back();
                    migrate(LoginFragment.newInstance());
                }
            }
        });

        TextView loginButton = view.findViewById(R.id.loginButton);
        //ログインボタンが押された場合
        loginButton.setOnClickListener( v -> {
            back();
            migrate(LoginFragment.newInstance());
        });
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
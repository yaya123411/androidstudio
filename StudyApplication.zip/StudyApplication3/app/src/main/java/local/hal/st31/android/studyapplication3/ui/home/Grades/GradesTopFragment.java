package local.hal.st31.android.studyapplication3.ui.home.Grades;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.GradesDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.home.Memo.MemoTopFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GradesTopFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class GradesTopFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    View view;
    private String serch = "",sort = "",where = "";

    //フラグメントを呼び出す
    public static GradesTopFragment newInstance(){
// Fragemnt01 インスタンス生成
        GradesTopFragment GradesTopFragment = new GradesTopFragment();

        return GradesTopFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_grades_top,
                container, false);

        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "成績タイトル一覧");
        editor.commit();
        setHasOptionsMenu(true);

        return view;
    }

    //---------------------------------------メニューを出力する------------------------------------

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        //保存領域に接続
        SharedPreferences myPrefs = this.getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

        MenuItem menuItem = menu.findItem(R.id.menuSeach);
        SearchView searchView = (SearchView) menuItem.getActionView();

//        SearchView searchView = (SearchView) MenuItemCompat.getActionView(menuItem);
        searchView.setSubmitButtonEnabled(false);

        if (!serch.equals("")) {
            // TextView.setTextみたいなもの
            searchView.setQuery(serch, false);
        }

        searchView.setOnQueryTextListener(this.onQueryTextListener);

        super.onCreateOptionsMenu(menu, inflater);
//        inflater.inflate(R.menu.option_menu_second, menu);
    }

    //メニューが押された場合
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();
        Cursor cursor;

        boolean returnVal = true;
        int itemId = item.getItemId();
        switch(itemId){
            case R.id.menuNew:
                //新しい順
                sort = "新しい順";
                break;
            case R.id.menuOld:
                //古い順
                sort = "古い順";
                break;
            case R.id.menuMaxHighScore:
                //最高点が高い順
                sort = "最高点が高い順";
                break;
            case R.id.menuMaxLowScore:
                //最高点が低い順
                sort = "最高点が低い順";
                break;
            case R.id.menuDownload:
                //ダウンロードしている
                where = "ダウンロードしている";
                break;
            case R.id.menuNotdownload:
                //ダウンロードされていない
                where = "ダウンロードされていない";
                break;
            case R.id.menuReset:
                //リセット
                serch = "";
                where = "";
                sort = "";
                break;
        }

        cursor = GradesDAO.findSerch(db, myPrefs.getString("userId", ""), serch, where, sort);
        list(cursor);
        return returnVal;
    }

    private SearchView.OnQueryTextListener onQueryTextListener = new SearchView.OnQueryTextListener() {

        @Override
        public boolean onQueryTextSubmit(String searchWord) {
            //検索ボタンが押された後に反映
            return true;
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            //入力した直後に反映
            //保存領域に接続
            try {
                //保存領域に接続
                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                _helper = new DatabaseHelper(getActivity());
                SQLiteDatabase db = _helper.getWritableDatabase();
                Cursor cursor;

                serch = newText;
                cursor = GradesDAO.findSerch(db, myPrefs.getString("userId", ""), serch, where, sort);
                list(cursor);
            }catch (NullPointerException e){
                e.printStackTrace();
            }
            return false;
        }
    };

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        ListView problemList = view.findViewById(R.id.dialogReportList);
        problemList.setOnItemClickListener(new ListItemClickListener());

        //メモボタンが押された場合
        FloatingActionButton memo = view.findViewById(R.id.gradesTopMemo);
        memo.setOnClickListener((View v) -> {
            migrate(MemoTopFragment.newInstance());
        });

        //戻るボタンが押された場合
        ImageView btnBack = view.findViewById(R.id.gradesTopBack);
        btnBack.setOnClickListener((View v) -> {
            editor.putString("menu", "");
            editor.commit();
            back();
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        Cursor cursor = GradesDAO.findAll(db, myPrefs.getString("userId", null));
        list(cursor);
    }

    /**
     * リストがクリックされた時のリスナクラス
     */
    private class ListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            Cursor item = (Cursor) parent.getItemAtPosition(position);
            int idxId = item.getColumnIndex("_id");
            long idNo = item.getLong(idxId);

            _helper = new DatabaseHelper(getActivity());
            SQLiteDatabase db = _helper.getWritableDatabase();

            //保存領域に接続
            SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = myPrefs.edit();

            //個数を取得
            Integer count = GradesDAO.GradesCount(db, idNo);
            if(count == 0){
                //1度も問題を解いていなかった場合
                Toast.makeText(getActivity(), "成績がありません", Toast.LENGTH_SHORT).show();
            }else{
                editor.putLong("titleId", idNo);
                editor.commit();

                migrate(GradesDetailedFragment.newInstance());
            }
        }
    }

    //表示するメソッド
    public void list(Cursor cursor){
        ListView problemList = view.findViewById(R.id.dialogReportList);
        TextView count = view.findViewById(R.id.titleCount3);

        String[] from = {"title"};
        int[] to = {R.id.gradesList};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(getActivity(), R.layout.gradeslist, cursor, from, to, 0);
        adapter.setViewBinder(new CustomViewBinder());
        problemList.setAdapter(adapter);
        count.setText(cursor.getCount() + "件検出");
    }

    /**
     * リストビューのカスタムビューバインダークラス。
     */
    private class CustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch (view.getId()) {
                case R.id.gradesList:
                    TextView text = (TextView)view;
                    text.setText(cursor.getString(columnIndex));

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)text.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)text.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }
                    return true;
            }
            return false;
        }
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
package local.hal.st31.android.studyapplication3.ui.home.Grades;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.core.app.ShareCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.ChartData;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.interfaces.datasets.IPieDataSet;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kotlin.jvm.internal.Intrinsics;
import local.hal.st31.android.studyapplication3.Database.CorrectSolutionProblem;
import local.hal.st31.android.studyapplication3.Database.CorrectSolutionProblemDAO;
import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.Grades;
import local.hal.st31.android.studyapplication3.Database.GradesDAO;
import local.hal.st31.android.studyapplication3.Database.MistakeProblem;
import local.hal.st31.android.studyapplication3.Database.MistakeProblemDAO;
import local.hal.st31.android.studyapplication3.Database.Problem;
import local.hal.st31.android.studyapplication3.Database.ProblemDAO;
import local.hal.st31.android.studyapplication3.Database.TitleList;
import local.hal.st31.android.studyapplication3.Database.TitleListDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.home.Memo.MemoTopFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemMake.ProblemMakeFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GradesMoreDetailedFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class GradesMoreDetailedFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    private int count = 0;
    View view;

    //フラグメントを呼び出す
    public static GradesMoreDetailedFragment newInstance(int idNo){
// Fragemnt01 インスタンス生成
        GradesMoreDetailedFragment GradesMoreDetailedFragment = new GradesMoreDetailedFragment();

        // Bundle にパラメータを設定
        Bundle args = new Bundle();
        args.putInt("idNo", idNo);
        GradesMoreDetailedFragment.setArguments(args);

        return GradesMoreDetailedFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        editor.putString("menu", "成績詳細");
        editor.commit();
        setHasOptionsMenu(true);

        View view = inflater.inflate(R.layout.fragment_grades_more_detailed,
                container, false);

        //既存の戻るボタンが押された場合の処理
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    editor.putString("menu", "");
                    editor.commit();
                    back();
                    return true;
                }
                return false;
            }
        });
        return view;
    }

    //---------------------------------------メニューを出力する------------------------------------

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        //保存領域に接続
        SharedPreferences myPrefs = this.getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

        MenuItem menuItem = menu.findItem(R.id.menuSeach);
        SearchView searchView = (SearchView) menuItem.getActionView();

//        SearchView searchView = (SearchView) MenuItemCompat.getActionView(menuItem);
        searchView.setSubmitButtonEnabled(false);

        if (!myPrefs.getString("extract","").equals("")) {
            // TextView.setTextみたいなもの
            searchView.setQuery(myPrefs.getString("extract",""), false);
        }

        searchView.setOnQueryTextListener(this.onQueryTextListener);

        super.onCreateOptionsMenu(menu, inflater);
//        inflater.inflate(R.menu.option_menu_second, menu);
    }

    //メニューが押された場合
    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();
        Cursor cursor;

        boolean returnVal = true;
        int itemId = item.getItemId();
        switch(itemId){
            case R.id.menuCircle:
                //正解のみ
                cursor = ProblemDAO.findCondition(db, myPrefs.getLong("titleId", 0), Integer.parseInt(String.valueOf(myPrefs.getLong("gradesNo",0))), "正解", myPrefs.getString("extract",""));
                pastList(cursor);
                editor.putString("listStyle", "正解");
                break;
            case R.id.menuVatu:
                //間違いのみ
                cursor = ProblemDAO.findCondition(db, myPrefs.getLong("titleId", 0), Integer.parseInt(String.valueOf(myPrefs.getLong("gradesNo",0))), "間違い", myPrefs.getString("extract",""));
                pastList(cursor);
                editor.putString("listStyle", "間違い");
                break;
            case R.id.menuFirst:
                //最初から
                cursor = ProblemDAO.findCondition(db, myPrefs.getLong("titleId", 0), Integer.parseInt(String.valueOf(myPrefs.getLong("gradesNo",0))), "最初", myPrefs.getString("extract",""));
                pastList(cursor);
                editor.putString("listStyle", "最初");
                break;
            case R.id.menuLast:
                //最後から
                cursor = ProblemDAO.findCondition(db, myPrefs.getLong("titleId", 0), Integer.parseInt(String.valueOf(myPrefs.getLong("gradesNo",0))), "最後", myPrefs.getString("extract",""));
                pastList(cursor);
                editor.putString("listStyle", "最後");
                break;
            case R.id.menuShare:
                //共有
                Grades result = GradesDAO.findIdByPK(db, myPrefs.getLong("titleId", 0) ,Integer.parseInt(String.valueOf(myPrefs.getLong("gradesNo",0))));
                String msg = "";

                if(result.getCorrectSolutionRate() > 70){
                    msg = result.getCount() + "週目\n"+result.getCorrectSolutionRate() + "%正解\nすごい！頑張ったね！その状態をキープしよう!";
                }else{
                    msg = result.getCount() + "週目\n"+result.getCorrectSolutionRate() + "%正解\nすごい！頑張ったね！";
                }

                share(msg);
                break;
            case R.id.menuReset:
                //リセット
                editor.putString("listStyle", "");
                editor.putString("extract", "");
                editor.commit();
                cursor = ProblemDAO.findCondition(db, myPrefs.getLong("titleId", 0), Integer.parseInt(String.valueOf(myPrefs.getLong("gradesNo",0))), myPrefs.getString("listStyle",""), myPrefs.getString("extract",""));
                pastList(cursor);
                break;
            case android.R.id.home:
                //戻るボタン
                editor.putString("listStyle", "");
                editor.putString("extract", "");
                editor.commit();
                back();
                break;
        }

        editor.commit();
        return returnVal;
    }

    private SearchView.OnQueryTextListener onQueryTextListener = new SearchView.OnQueryTextListener() {

        @Override
        public boolean onQueryTextSubmit(String searchWord) {
            //検索ボタンが押された後に反映
            return true;
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            //入力した直後に反映
            //保存領域に接続
            SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = myPrefs.edit();
            _helper = new DatabaseHelper(getActivity());
            SQLiteDatabase db = _helper.getWritableDatabase();
            Cursor cursor;

            if(!newText.equals("")){
                editor.putString("extract", newText);
                editor.putString("listStyle", "検索");
                editor.commit();
            }
            cursor = ProblemDAO.findCondition(db, myPrefs.getLong("titleId", 0), Integer.parseInt(String.valueOf(myPrefs.getLong("gradesNo",0))), myPrefs.getString("listStyle",""), myPrefs.getString("extract",""));
            pastList(cursor);
            return false;
        }
    };

    //シェア
    private void share(String msg) {
        String sharedText = msg;

        // builderの生成　ShareCompat.IntentBuilder.from(Context context);
        ShareCompat.IntentBuilder builder = ShareCompat.IntentBuilder.from(getActivity());

        // アプリ一覧が表示されるDialogのタイトルの設定
        builder.setChooserTitle("Twitter");

        // シェアするタイトル
        builder.setSubject(msg);

        // シェアするテキスト
        builder.setText(sharedText);

        // シェアするタイプ（他にもいっぱいあるよ）
        builder.setType("text/plain");

        // Shareアプリ一覧のDialogの表示
        builder.startChooser();
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        Bundle args = getArguments();

        //メモボタンが押された場合
        FloatingActionButton memo = view.findViewById(R.id.gradesMoreDetailedMemo);
        memo.setOnClickListener((View v) -> {
            migrate(MemoTopFragment.newInstance());
        });

        //戻るボタンが押された場合
        ImageView btnBack = view.findViewById(R.id.gradesMoreDetailedBack);
        btnBack.setOnClickListener((View v) -> {
            editor.putString("menu", "");
            editor.commit();
            back();
        });
        //図のボタンが押された場合
        ImageView btnIllustration = view.findViewById(R.id.illustration);
        btnIllustration.setOnClickListener((View v) -> {
            //不正解の問題の個数を取得
            Double missCount = MistakeProblemDAO.count(db, myPrefs.getLong("titleId",0), myPrefs.getLong("gradesNo",0), 0);
            //未回答の問題の個数を取得
            Double notAnswereCount = MistakeProblemDAO.count(db, myPrefs.getLong("titleId",0), myPrefs.getLong("gradesNo",0), 1);
            //正解の問題の個数を取得
            Double correctCount = CorrectSolutionProblemDAO.count(db, myPrefs.getLong("titleId",0), myPrefs.getLong("gradesNo",0));
            //全体の問題の個数
            Double count = missCount + notAnswereCount + correctCount;

            LayoutInflater inflater = getActivity().getLayoutInflater();
            View dialogView = inflater.inflate(R.layout.dialog_illustration, null, false);

            View circle = dialogView.findViewById(R.id.pie_chart);
            Intrinsics.checkNotNullExpressionValue(circle, "findViewById(R.id.pie_chart)");
            PieChart chart = (PieChart)circle;
            ArrayList value = new ArrayList();
            ArrayList color = new ArrayList();
            if(correctCount/count*100 != 0){
                value.add(new PieEntry((float) Math.floor(correctCount/count*100), "正解\n" + (int) Math.floor(correctCount/count*100) + "%"));
                color.add(Color.RED);
            }
            if(missCount/count*100 != 0){
                value.add(new PieEntry((float) Math.floor(missCount/count*100), "不正解\n" + (int) Math.floor(missCount/count*100) + "%"));
                color.add(Color.BLUE);
            }
            if(notAnswereCount/count*100 != 0){
                value.add(new PieEntry((float) Math.floor(notAnswereCount/count*100), "未回答\n" + (int) Math.floor(notAnswereCount/count*100) + "%"));
                color.add(Color.GRAY);
            }
            PieDataSet dataSet = new PieDataSet((List)value, "");
            dataSet.setColors((List)color);
            chart.setData(new PieData((IPieDataSet)dataSet));
            chart.invalidate();

            //ダイアログ作成
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setView(dialogView);

            builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });

            //ダイアログ出力
            AlertDialog alertDialog = builder.create();
            alertDialog.setCanceledOnTouchOutside(false);
            alertDialog.show();
        });

        Grades result = GradesDAO.findIdByPK(db, myPrefs.getLong("titleId", 0) ,args.getInt("idNo")+1);
        double minit = Math.floor(result.getTime());
        double second = (Math.floor((result.getTime() - minit) * 100)) / 100;

        //時間に直す
        String strMinit = "";
        String strSecond = "";
        String strTime = "";
        int flg = 0;
        BigDecimal bigMinit = new BigDecimal(minit).stripTrailingZeros();
        second = second * 60;
        second = Math.round(second);
        BigDecimal bigSecond = new BigDecimal(second);
        String strDenoteTime = "";

        for(int i=0;i<17;i++){
            if(minit >= 60 * (i+1)){
                if(second != 0){
                    strSecond = Integer.parseInt(String.valueOf(bigSecond)) + "秒";
                }
                if(minit != 0){
                    strMinit = bigMinit + "分";
                }
                strTime = i + strMinit + strSecond;
                flg = 1;
            }else if(flg == 0){
                if(second != 0){
                    strSecond = String.valueOf(second).substring(0, String.valueOf(second).length()-2) + "秒";
                }
                if(minit != 0){
                    strMinit = bigMinit + "分";
                }
                strTime = strMinit + strSecond;
                break;
            }else{
                break;
            }
        }

        if(result.getTime() != 0.0){
            strDenoteTime = "時間 : " + strTime;
        }

        //タイトルを取得
        TitleList title = TitleListDAO.findIdByPK(db, myPrefs.getLong("titleId",0));

        TextView textGradesTitle = view.findViewById(R.id.gradesTitle);
        TextView textNumberOfTimes = view.findViewById(R.id.textNumberOfTimes);
        TextView textAnswerRate = view.findViewById(R.id.textAnswerRate);
        TextView textAnswerNum = view.findViewById(R.id.textAnswerNum);
        TextView textTime = view.findViewById(R.id.textBack);
        textGradesTitle.setText(title.getTitle());
        textNumberOfTimes.setText(result.getCount() + "回目");
        textAnswerRate.setText(result.getCorrectSolutionRate() + "%正解");
        textAnswerNum.setText("正解数 : " + result.getCorrectSolutionNum() + "問");
        textTime.setText(strDenoteTime);


        //問題を出力する
        ListView problemList = view.findViewById(R.id.dialogReportList);

        problemList.setOnItemClickListener(new ListItemClickListener());

        Cursor cursor = ProblemDAO.findCondition(db, myPrefs.getLong("titleId", 0), Integer.parseInt(String.valueOf(myPrefs.getLong("gradesNo",0))), myPrefs.getString("serchStyle","") ,myPrefs.getString("extract",""));
        pastList(cursor);
    }

    /**
     * リストビューのカスタムビューバインダークラス。
     */
    private class CustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch(view.getId()) {
                case R.id.line:
                    if(cursor.getString(columnIndex) == null){
                        count++;
                    }
                    return true;
                case R.id.right:
                    ImageView imageView = (ImageView)view;
                    if(cursor.getString(columnIndex) == null){
                        count++;
                    }
                    if(cursor.getString(columnIndex) != null){
                        //間違っている問題ならば
                        imageView.setImageResource(R.drawable.vatu_var2);
                    }else if(count == 1){
                        //正解した問題ならば
                        imageView.setImageResource(R.drawable.circle_ver2);
                    }else if(count == 2){
                        imageView.setImageResource(R.drawable.hyphen);
                    }
                    count = 0;

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)imageView.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)imageView.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }
                    return true;
                case R.id.listTherrImageStyle:
                    TextView style = (TextView)view;
                    if(cursor.getString(columnIndex).equals("on")){
                        style.setText("選択式");
                    }else if(cursor.getString(columnIndex).equals("off")){
                        style.setText("記述式");
                    }
                    return true;
            }
            return false;
        }
    }

    /**
     * リストがクリックされた時のリスナクラス
     */
    public class ListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            Cursor item = (Cursor) parent.getItemAtPosition(position);
            int idxId = item.getColumnIndex("_id");
            long idNo = item.getLong(idxId);

            _helper = new DatabaseHelper(getActivity());
            SQLiteDatabase db = _helper.getWritableDatabase();
            //保存領域に接続
            SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

            //ダイアログ作成
            DialogFragment dialogFragment = new PastDialogFragment();
            // 渡す値をセット
            Bundle args = new Bundle();

            //問題IDを取得
            CharSequence[] problemList = ProblemDAO.ProblemIdSeachAll(db, myPrefs.getLong("titleId",0), myPrefs.getLong("gradesNo",0), myPrefs.getString("serchStyle",""), myPrefs.getString("extract",""));
            //問題を取り出す
            MistakeProblem misResult = MistakeProblemDAO.findIdByProblemId(db, Long.parseLong((String) problemList[position]), myPrefs.getLong("gradesNo",0));
            HashMap<String, String> choose = ProblemDAO.getChoose(db, problemList[position]);
            String jsonReply = "";
            //インスタンス化
            ObjectMapper mapper = new ObjectMapper();
            try {
                // mapをjson文字列に変換します。
                jsonReply = mapper.writeValueAsString(choose);
            } catch (Exception e) {
                // エラー!
                e.printStackTrace();
            }

            args.putString("choose", jsonReply);

            if(misResult == null){
                //クリックした問題が正解していた場合
                CorrectSolutionProblem correctSolutionResult = CorrectSolutionProblemDAO.findIdByProblemId(db, Long.parseLong((String) problemList[position]), myPrefs.getLong("gradesNo",0));
                if(correctSolutionResult == null){
                    //新しく問題を追加した場合
                    Problem problem = ProblemDAO.findIdByPK(db, Long.parseLong((String) problemList[position]));
                    args.putString("question", problem.getQuestion());
                    args.putString("reply", problem.getReply());
                    args.putString("explanation", problem.getExplanation());
                    args.putInt("none", 1);
                }else{
                    args.putString("question", correctSolutionResult.getQuestion());
                    args.putString("reply", correctSolutionResult.getReply());
                    args.putString("explanation", correctSolutionResult.getExplanation());
                }
            }else{
                args.putString("question", misResult.getQuestion());
                args.putString("reply", misResult.getReply());
                HashMap<String, String> missChoose = getChoose(misResult.getChoice(), misResult.getMyReply(), misResult.getChoiceA(), misResult.getChoiceB(), misResult.getChoiceC(), misResult.getChoiceD(), misResult.getChoiceE(), misResult.getChoiceF(), misResult.getChoiceG());

                try {
                    // mapをjson文字列に変換します。
                    jsonReply = mapper.writeValueAsString(missChoose);
                } catch (Exception e) {
                    // エラー!
                    e.printStackTrace();
                }
                args.putString("missChoose", jsonReply);
                if(misResult.getMyReply().equals("")){
                    args.putString("myReply", "未回答");
                }else{
                    args.putString("myReply", misResult.getMyReply());
                }
                args.putString("explanation", misResult.getExplanation());
            }
            dialogFragment.setArguments(args);

            //ダイアログ出力
            dialogFragment.show(getActivity().getSupportFragmentManager(), "my_dialog");
        }
    }

    //リスト表示
    public void pastList(Cursor cursor){
        ListView problemList = view.findViewById(R.id.dialogReportList);
        TextView count = view.findViewById(R.id.titleCount2);
        String[] from = {"question","count","_id","choice"};
        int[] to = {R.id.left,R.id.line, R.id.right, R.id.listTherrImageStyle};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(getActivity(), R.layout.list_therr_image, cursor, from, to, 0);
        adapter.setViewBinder(new CustomViewBinder());
        problemList.setAdapter(adapter);
        count.setText(cursor.getCount() + "件検出");
    }

    /**
     * 自分の回答の選択肢の文章を取得するメソッド
     * @param choice
     * @param myReply
     * @param choiceA
     * @param choiceB
     * @param choiceC
     * @param choiceD
     * @param choiceE
     * @param choiceF
     * @param choiceG
     * @return
     */
    public static HashMap<String, String> getChoose(String choice, String myReply, String choiceA, String choiceB, String choiceC, String choiceD, String choiceE, String choiceF, String choiceG){
        HashMap<String, String> chooseList = new HashMap<>();

        if(myReply.indexOf("ア") != -1 && choice.equals("on")){
            chooseList.put("ア:", choiceA);
        }
        if(myReply.indexOf("イ") != -1 && choice.equals("on")){
            chooseList.put("イ:", choiceB);
        }
        if(myReply.indexOf("ウ") != -1 && choice.equals("on")){
            chooseList.put("ウ:", choiceC);
        }
        if(myReply.indexOf("エ") != -1 && choice.equals("on")){
            chooseList.put("エ:", choiceD);
        }
        if(myReply.indexOf("オ") != -1 && choice.equals("on")){
            chooseList.put("オ:", choiceE);
        }
        if(myReply.indexOf("カ") != -1 && choice.equals("on")){
            chooseList.put("カ:", choiceF);
        }
        if(myReply.indexOf("キ") != -1 && choice.equals("on")){
            chooseList.put("キ:", choiceG);
        }

        if(choice.equals("off")){
            //記述式ならば
            if(myReply.equals("")){
                //未回答ならば
                chooseList.put("", "未回答");
            }else{
                chooseList.put("", myReply);
            }
        }else if(choice.equals("on")){
            //選択式ならば
            if(myReply.equals("")){
                //未回答ならば
                chooseList.put("", "未回答");
            }
        }

        return chooseList;
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
package local.hal.st31.android.studyapplication3.Database;

public class CanvasLine {
    /**
     * キャンバスID
     */
    private long _canvasId;
    /**
     * X座標
     */
    private float _getX;
    /**
     * Y座標
     */
    private float _getY;

    //以下アクセサメソッド

    public long getCanvasId(){
        return _canvasId;
    }
    public void setCanvasId(long canvasId){
        _canvasId = canvasId;
    }
    public float getGetX(){
        return _getX;
    }
    public void setGetX(float getX){
        _getX = getX;
    }
    public float getGetY(){
        return _getY;
    }
    public void setGetY(float getY){
        _getY = getY;
    }
}

package local.hal.st31.android.studyapplication3.Database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;

public class CorrectSolutionProblemDAO {
    /**
     * 成績の全てのデータを取得するメソッド
     * @param db
     * @return
     */
    public static Cursor findAll(SQLiteDatabase db, String userId){
        String sql = "SELECT * FROM correctSolutionProblem WHERE userId = '" + userId + "' ORDER BY _id DESC";
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;
    }

    /**
     * 特定の成績を1件取り出す
     * @param db
     * @param id
     * @return
     */
    public static CorrectSolutionProblem findIdByPK(SQLiteDatabase db, long id){
        //id=_id
        String sql = "SELECT * FROM correctSolutionProblem WHERE _id = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);
        CorrectSolutionProblem result = null;
        if(cursor.moveToFirst()){
            int idxId = cursor.getColumnIndex("_id");
            String strId = cursor.getString(idxId);
            int idxUserId = cursor.getColumnIndex("userId");
            String strUserId = cursor.getString(idxUserId);
            int idxTitleId = cursor.getColumnIndex("titleId");
            String strTitleId = cursor.getString(idxTitleId);
            int idxCount = cursor.getColumnIndex("count");
            String strCount = cursor.getString(idxCount);
            int idxProblemId = cursor.getColumnIndex("problemId");
            String strProblemId = cursor.getString(idxProblemId);
            int idxReply = cursor.getColumnIndex("reply");
            String strReply = cursor.getString(idxReply);

            result = new CorrectSolutionProblem();
            result.setId(Long.parseLong(strId));
            result.setUserId(strUserId);
            result.setTitleId(Long.parseLong(strTitleId));
            result.setProblemId(Long.parseLong(strProblemId));
            result.setCount(Integer.parseInt(strCount));
            result.setReply(strReply);
        }
        return result;
    }

    /**
     * 成績を追加するメソッド
     * @param db
     * @param userId
     * @param titleId
     * @param reply
     * @return
     */
    public static long insert(SQLiteDatabase db, String userId, long titleId, long problemId, String downloadId, Integer count, String reply){
        String sql = "INSERT INTO correctSolutionProblem (userId, titleId, problemId, count, reply, downloadId) VALUES (?, ?, ?, ?, ?, ?)";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, userId);
        stmt.bindLong(2, titleId);
        stmt.bindLong(3, problemId);
        stmt.bindLong(4, count+1);
        stmt.bindString(5, reply);
        if(downloadId != null){
            //ダウンロードした問題ならば
            stmt.bindLong(6, Long.parseLong(downloadId));
        }
        long insertedId = stmt.executeInsert();
        return insertedId;
    }

    /**
     * 成績を削除するメソッド
     * @param db
     * @param id
     * @return
     */
    public static int delete(SQLiteDatabase db, long id){
        String sql = "DELETE FROM correctSolutionProblem WHERE _id = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, id);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    /**
     * ダウンロードした問題の成績を削除する
     * @param db
     * @param titleId
     * @return
     */
    public static int deleteByTitleId(SQLiteDatabase db, long titleId){
        String sql = "DELETE FROM correctSolutionProblem WHERE titleId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, titleId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    /**
     * 特定の成績を1件取り出す
     * @param db
     * @param problemId
     * @return
     */
    public static CorrectSolutionProblem findIdByProblemId(SQLiteDatabase db, long problemId, long count){
        //id=_id
        String sql = "SELECT * FROM problems LEFT OUTER JOIN correctSolutionProblem ON correctSolutionProblem.problemId = problems._id WHERE problemId = '" + problemId + "' AND count = '" + count + "'";
        Cursor cursor = db.rawQuery(sql, null);
        CorrectSolutionProblem result = null;
        if(cursor.moveToFirst()){
            int idxId = cursor.getColumnIndex("_id");
            String strId = cursor.getString(idxId);
            int idxUserId = cursor.getColumnIndex("userId");
            String strUserId = cursor.getString(idxUserId);
            int idxTitleId = cursor.getColumnIndex("titleId");
            String strTitleId = cursor.getString(idxTitleId);
            int idxCount = cursor.getColumnIndex("count");
            String strCount = cursor.getString(idxCount);
            int idxProblemId = cursor.getColumnIndex("problemId");
            String strProblemId = cursor.getString(idxProblemId);
            int idxChoice = cursor.getColumnIndex("choice");
            String strChoice = cursor.getString(idxChoice);
            int idxChoiceA = cursor.getColumnIndex("choiceA");
            String strChoiceA = cursor.getString(idxChoiceA);
            int idxQuestion = cursor.getColumnIndex("question");
            String strQuestion = cursor.getString(idxQuestion);
            int idxReply = cursor.getColumnIndex("reply");
            String strReply = cursor.getString(idxReply);
            int idxExplanation = cursor.getColumnIndex("explanation");
            String strExplanation = cursor.getString(idxExplanation);

            result = new CorrectSolutionProblem();
            result.setId(Long.parseLong(strId));
            result.setUserId(strUserId);
            result.setTitleId(Long.parseLong(strTitleId));
            result.setProblemId(Long.parseLong(strProblemId));
            result.setCount(Integer.parseInt(strCount));
            result.setChoice(strChoice);
            result.setChoiceA(strChoiceA);
            result.setQuestion(strQuestion);
            result.setReply(strReply);
            result.setExplanation(strExplanation);
        }
        return result;
    }

    /**
     * 正解の問題の個数を取得する
     * @param db
     * @param titleId
     * @param count
     * @return
     */
    public static Double count(SQLiteDatabase db, long titleId, long count){
        //id=_id
        String sql = "SELECT COUNT(*) as num FROM correctSolutionProblem INNER JOIN problems ON correctSolutionProblem.problemId = problems._id WHERE count = '" + count + "' AND problems.titleId = '" + titleId + "'";
        Cursor cursor = db.rawQuery(sql, null);
        Double result = null;
        if(cursor.moveToFirst()){
            int idxNum = cursor.getColumnIndex("num");
            String strNum = cursor.getString(idxNum);

            result = Double.parseDouble(strNum);
        }
        return result;
    }
}

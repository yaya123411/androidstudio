package local.hal.st31.android.studyapplication3.ui.home.Flashcard;

import static android.app.Activity.RESULT_OK;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.ParcelFileDescriptor;
import android.speech.RecognizerIntent;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;

import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.Flashcard;
import local.hal.st31.android.studyapplication3.Database.FlashcardDAO;
import local.hal.st31.android.studyapplication3.Database.FlashcardTitleDAO;
import local.hal.st31.android.studyapplication3.Database.Problem;
import local.hal.st31.android.studyapplication3.Database.ProblemDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.OCR;
import local.hal.st31.android.studyapplication3.ui.home.HomeFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FlashcardEditFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FlashcardEditFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    /**
     * 新規登録モードか更新モードかを表すフィールド。
     */
    //_mode=1
    private int _mode = FlashcardListFragment.MODE_INSERT;
    //任意の識別番号
    private static final int REQUEST_CODE = 12345;
    //ocr
    private static final int REQUEST_CODE_PICK_CONTENT = 0;
    private Intent intent;
    private OCR _ocr;
    View view;

    //フラグメントを呼び出す
    public static FlashcardEditFragment newInstance(int mode, long idNo){
// Fragemnt01 インスタンス生成
        FlashcardEditFragment FlashcardEditFragment = new FlashcardEditFragment();

        // Bundle にパラメータを設定
        Bundle args = new Bundle();
        args.putInt("mode", mode);
        args.putLong("idNo", idNo);
        FlashcardEditFragment.setArguments(args);

        return FlashcardEditFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_flashcard_edit,
                container, false);

        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "問題編集");
        editor.commit();
        setHasOptionsMenu(true);

        return view;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        boolean returnVal = true;
        int itemId = item.getItemId();
        switch(itemId) {
            case R.id.menuAudio:
                //マイクボタンが押された場合
                //音声認識用のインテントを作成
                intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                //認識する言語を指定（この場合は日本語）
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.JAPANESE.toString());
                //認識する候補数の指定
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 10);
                //音声認識時に表示する案内を設定
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "話してください");
                //音声認識を開始
                startActivityForResult(intent, REQUEST_CODE);
                break;
            case R.id.menuCamera:
                //カメラボタンが押された場合
                _ocr = new OCR(getActivity().getApplicationContext());
                LayoutInflater cameraInflater = getActivity().getLayoutInflater();
                View cameraDialogView = cameraInflater.inflate(R.layout.dialog_camera, null, false);
                AlertDialog.Builder cameraDuilder = new AlertDialog.Builder(getActivity());
                cameraDuilder.setView(cameraDialogView);

                TextView textCamera = cameraDialogView.findViewById(R.id.textCamera);
                TextView textGallery = cameraDialogView.findViewById(R.id.textGallery);

                //キャンセルボタンが押された場合
                cameraDuilder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });

                //ダイアログ出力
                AlertDialog cameraDialog = cameraDuilder.show();

                //写真を撮影するボタンが押された場合
                textCamera.setOnClickListener((View view) -> {
                    //カメラを起動
                    cameraLauncher.launch(null);
                    cameraDialog.dismiss();
                });

                textGallery.setOnClickListener((View view) -> {
                    //写真を選択するボタンが押された場合
                    if(Build.VERSION.SDK_INT < 19){
                        intent = new Intent(Intent.ACTION_PICK);
                        intent.setAction(Intent.ACTION_GET_CONTENT);
                    }else{
                        intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                    }
                    intent.setType("image/*");
                    startActivityForResult(intent, REQUEST_CODE_PICK_CONTENT);
                    cameraDialog.dismiss();
                });
                break;
        }
        return returnVal;
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        Bundle args = getArguments();

        _mode = args.getInt("mode");

        //戻るボタンが押された場合
        ImageView btnBack = view.findViewById(R.id.flashcardEditBack);
        btnBack.setOnClickListener((View v) -> {
            //ダイアログ作成
            EditText front = view.findViewById(R.id.etFront);
            EditText back = view.findViewById(R.id.etBack);

            Flashcard result = FlashcardDAO.findIdByPK(db, myPrefs.getLong("flashcardId",0));

            if(result != null){
                //リストがクリックされた場合
                if(!result.getFront().equals(front.getText().toString()) || !result.getBack().equals(back.getText().toString())){
                    //変更された場合
                    LayoutInflater inflater = getActivity().getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.dialog_back, null, false);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    TextView transition = dialogView.findViewById(R.id.dialogTransition);
                    TextView cancel = dialogView.findViewById(R.id.dialogCancel);
                    builder.setView(dialogView);

                    //ダイアログ出力
                    AlertDialog alertDialog = builder.show();

                    transition.setOnClickListener(parts -> {
                        //遷移ボタンが押された場合
                        alertDialog.dismiss();
                        editor.putString("menu", "");
                        editor.commit();
                        back();
                    });
                    cancel.setOnClickListener(parts -> {
                        //キャンセルボタンが押された場合
                        alertDialog.dismiss();
                    });
                }else{
                    editor.putString("menu", "");
                    editor.commit();
                    back();
                }
            }else{
                if(!"".equals(front.getText().toString()) || !"".equals(back.getText().toString())){
                    //変更された場合
                    LayoutInflater inflater = getActivity().getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.dialog_back, null, false);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    TextView transition = dialogView.findViewById(R.id.dialogTransition);
                    TextView cancel = dialogView.findViewById(R.id.dialogCancel);
                    builder.setView(dialogView);

                    //ダイアログ出力
                    AlertDialog alertDialog = builder.show();

                    transition.setOnClickListener(parts -> {
                        //遷移ボタンが押された場合
                        alertDialog.dismiss();
                        editor.putString("menu", "");
                        editor.commit();
                        back();
                    });
                    cancel.setOnClickListener(parts -> {
                        //キャンセルボタンが押された場合
                        alertDialog.dismiss();
                    });
                    editor.putInt("addFlg", 0);
                    editor.commit();
                }else{
                    editor.putString("menu", "");
                    editor.commit();
                    back();
                }
            }
        });

        if(_mode == FlashcardListFragment.MODE_INSERT){
            //プラスボタン(追加)が押された場合
            //消去ボタンのテキストを追加に変更
            Button btnUpdate = view.findViewById(R.id.btnUpdateAdd);
            btnUpdate.setText(R.string.btnInsert);
            editor.putLong("flashcardId", 0);
        }else{
            //リストが押された場合
            //データを保持
            Flashcard result = FlashcardDAO.findIdByPK(db, args.getLong("idNo"));
            EditText etFront = view.findViewById(R.id.etFront);
            EditText etBack = view.findViewById(R.id.etBack);
            etFront.setText(result.getFront());
            etBack.setText(result.getBack());

            editor.putLong("flashcardId", args.getLong("idNo"));
        }
        editor.commit();

        //更新or追加ボタンが押された場合
        Button btnUpdate = view.findViewById(R.id.btnUpdateAdd);
        btnUpdate.setOnClickListener((View v) -> {
            int flg = 0;
            String msg = "";
            EditText etFlont = view.findViewById(R.id.etFront);
            String strFlont = etFlont.getText().toString();
            EditText etBack = view.findViewById(R.id.etBack);
            String strBack = etBack.getText().toString();
            //タイトル
            if(strFlont.equals("")){
                etFlont.setError("値を入力してください");
                flg = 1;
            }
            //時間
            if(strBack.equals("")){
                etBack.setError("値を入力してください");
                flg = 1;
            }
            if(flg == 0){
                //入力チェックに引っかからなかった場合
                if(_mode == FlashcardListFragment.MODE_INSERT){
                    //プラスボタンが押された場合(追加処理)
                    //ダウンロードIDを取得する
                    long downloadId = FlashcardTitleDAO.downloadIdByFlashcardId(db, myPrefs.getLong("titleId", 0));
                    FlashcardDAO.insert(db, myPrefs.getString("userId", ""), myPrefs.getLong("titleId", 0), strFlont, strBack);
                    msg = "追加しました";
                    back();
                }else{
                    //リストが押された場合(変更処理)
                    FlashcardDAO.update(db, myPrefs.getLong("idNo", 0), strFlont, strBack);
                    msg = "更新しました";
                    back();
                }
            }
            Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
        });
    }

    //音声認識が終わると自動で呼び出されるメソッド
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        EditText result = dialog().findViewById(R.id.editResult);

        if(requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            //マイクボタンが押された場合
            //data から音声認識の結果を取り出す（リスト形式で）
            ArrayList<String> kekka = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

            //認識結果が一つ以上ある場合はテキストビューに結果を表示する
            if (kekka.size() > 0) {
                //一番最初にある認識結果を表示する
                result.setText(kekka.get(0));
            } else {
                //何らかの原因で音声認識に失敗した場合はエラーメッセージを表示
                result.setText("音声の認識に失敗しました…");
            }
        }else if(requestCode == REQUEST_CODE_PICK_CONTENT){
            //カメラボタンの写真を選択するボタンが押された場合
            String ocrString;
            if(resultCode == RESULT_OK && data != null){
                Bitmap bitmap = null;
                if(Build.VERSION.SDK_INT < 19){
                    try{
                        InputStream in = getActivity().getContentResolver().openInputStream(data.getData());
                        bitmap = BitmapFactory.decodeStream(in);
                        try{
                            if(in != null){ in.close(); }
                        }catch(IOException e){
                            e.printStackTrace();
                        }
                    }catch(FileNotFoundException e){
                        e.printStackTrace();
                    }
                }else{
                    Uri uri = data.getData();
                    try{
                        ParcelFileDescriptor parcelFileDescriptor = getActivity().getContentResolver().openFileDescriptor(uri, "r");
                        if(parcelFileDescriptor != null){
                            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
                            bitmap = BitmapFactory.decodeFileDescriptor(fileDescriptor);
                            parcelFileDescriptor.close();
                        }

                    }catch(IOException e){
                        e.printStackTrace();
                    }
                }
                if(bitmap != null){
                    ocrString = _ocr.getString(getActivity().getApplicationContext(), bitmap);
                }else{
                    ocrString = "bitmap is null";
                }
            }else{
                ocrString = "上手く読み取れませんでした";
            }
            result.setText(ocrString);
        }
    }

    //カメラボタンの写真を撮影するボタンが押された場合
    private final ActivityResultLauncher<Void> cameraLauncher = registerForActivityResult(
            new ActivityResultContracts.TakePicturePreview(), bitmap -> {
                EditText result = dialog().findViewById(R.id.editResult);
                try {
                    int rotationDegree = 0;
                    InputImage image = InputImage.fromBitmap(bitmap, rotationDegree);

                    // 日本語もサポートした！
                    TextRecognizer recognizer = TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());

                    Task<Text> task = recognizer.process(image)
                            .addOnSuccessListener(new OnSuccessListener<Text>() {
                                @Override
                                public void onSuccess(Text visionText) {
                                    String resultText = visionText.getText(); // 文字列取得！
                                    result.setText(resultText);
                                }
                            });
                }catch (NullPointerException e){
                    result.setText("正常に値を受け取れませんでした");
                }
            });

    //ダイアログ生成メソッド
    public AlertDialog dialog(){
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_audio_camera_result, null, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(dialogView);

        //キャンセルボタンが押された場合
        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });

        //ダイアログ出力
        return builder.show();
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
package local.hal.st31.android.studyapplication3.Database;

public class Canvas {
    /**
     * メモID
     */
    private long _memoId;
    /**
     * 始まりのX座標
     */
    private float _startGetX;
    /**
     * 始まりのY座標
     */
    private float _startGetY;
    /**
     * 終わりのX座標
     */
    private float _finishGetX;
    /**
     * 終わりのY座標
     */
    private float _finishGetY;
    /**
     * 色の指定
     */
    private Integer _color;

    //以下アクセサメソッド

    public long getMemoId(){
        return _memoId;
    }
    public void setMemoId(long memoId){
        _memoId = memoId;
    }
    public float getStartGetX(){
        return _startGetX;
    }
    public void setStartGetX(float startGetX){
        _startGetX = startGetX;
    }
    public float getStartGetY(){
        return _startGetY;
    }
    public void setStartGetY(float startGetY){
        _startGetY = startGetY;
    }
    public float getFinishGetX(){
        return _finishGetX;
    }
    public void setFinishGetX(float finishGetX){
        _finishGetX = finishGetX;
    }
    public float getFinishGetY(){
        return _finishGetY;
    }
    public void setFinishGetY(float finishGetY){
        _finishGetY = finishGetY;
    }
    public Integer getColor(){
        return _color;
    }
    public void setColor(Integer color){
        _color = color;
    }
}

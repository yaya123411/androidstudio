package local.hal.st31.android.studyapplication3.ui.home.ProblemMake;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.ProblemDAO;
import local.hal.st31.android.studyapplication3.Database.TitleList;
import local.hal.st31.android.studyapplication3.Database.TitleListDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.home.Memo.MemoTopFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProblemMakeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProblemAddFragment extends Fragment {
    /**
     * 新規登録モードを表す定数フィールド。
     */
    static final int MODE_INSERT = 1;
    /**
     * 更新モードを表す定数フィールド。
     */
    static final int MODE_UPDATE = 2;
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    private View view;
    private String serch = "",sort = "";

    //フラグメントを呼び出す
    public static ProblemAddFragment newInstance() {
// Fragemnt01 インスタンス生成
        ProblemAddFragment ProblemAddFragment = new ProblemAddFragment();

        return ProblemAddFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_problem_add,
                container, false);

        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "問題リスト");
        editor.commit();
        setHasOptionsMenu(true);

        return view;
    }

    //---------------------------------------メニューを出力する------------------------------------

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        //保存領域に接続
        SharedPreferences myPrefs = this.getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

        MenuItem menuItem = menu.findItem(R.id.menuSeach);
        SearchView searchView = (SearchView) menuItem.getActionView();

//        SearchView searchView = (SearchView) MenuItemCompat.getActionView(menuItem);
        searchView.setSubmitButtonEnabled(false);

        if (!myPrefs.getString("serch","").equals("")) {
            // TextView.setTextみたいなもの
            searchView.setQuery(myPrefs.getString("serch",""), false);
        }

        searchView.setOnQueryTextListener(this.onQueryTextListener);

        super.onCreateOptionsMenu(menu, inflater);
    }

    //メニューが押された場合
    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();
        Cursor cursor;

        boolean returnVal = true;
        int itemId = item.getItemId();
        switch(itemId){
            case R.id.menuUpdate:
                //更新順
                sort = "更新順";
                break;
            case R.id.menuNew:
                //新しい順
                sort = "新しい順";
                break;
            case R.id.menuOld:
                //古い順
                sort = "古い順";
                break;
            case R.id.menuReset:
                //リセット
                sort = "";
                serch = "";
                break;
        }

        editor.commit();
        cursor = ProblemDAO.findSerch(db, myPrefs.getLong("titleId", 0), serch, sort);
        list(cursor);
        return returnVal;
    }

    private SearchView.OnQueryTextListener onQueryTextListener = new SearchView.OnQueryTextListener() {

        @Override
        public boolean onQueryTextSubmit(String searchWord) {
            //検索ボタンが押された後に反映
            return true;
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            //入力した直後に反映
            try {
                //保存領域に接続
                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                _helper = new DatabaseHelper(getActivity());
                SQLiteDatabase db = _helper.getWritableDatabase();
                Cursor cursor;

                serch = newText;
                cursor = ProblemDAO.findSerch(db, myPrefs.getLong("titleId", 0), serch, sort);
                list(cursor);
            }catch (NullPointerException e){
                e.printStackTrace();
            }
            return false;
        }
    };

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        ListView problemList = view.findViewById(R.id.dialogReportList);
        problemList.setOnItemClickListener(new ListItemClickListener());

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        //メモボタンが押された場合
        FloatingActionButton memo = view.findViewById(R.id.flashcardListMemo);
        memo.setOnClickListener((View v) -> {
            migrate(MemoTopFragment.newInstance());
        });

        //戻るボタンが押された場合
        ImageView btnBack = view.findViewById(R.id.problemAddBack);
        btnBack.setOnClickListener((View v) -> {
            editor.putString("menu", "");
            editor.commit();
            back();
        });

        //問題作成ボタンが押された場合
        Button btnAdd = view.findViewById(R.id.btnProblemAdd);
        btnAdd.setOnClickListener((View v) -> {
            migrate(ProblemAddEditFragment.newInstance(MODE_INSERT, Long.parseLong(String.valueOf(0))));
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        Cursor cursor = ProblemDAO.findAll(db, myPrefs.getLong("titleId", 0));
        list(cursor);

        TitleList problemTitle = TitleListDAO.findIdByPK(db, myPrefs.getLong("titleId", 0));
        TextView textProblemAddTitle = view.findViewById(R.id.textProblemAddTitle);
        textProblemAddTitle.setText(problemTitle.getTitle());
    }

    /**
     * リストがクリックされた時のリスナクラス
     */
    private class ListItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Cursor item = (Cursor) parent.getItemAtPosition(position);
            int idxId = item.getColumnIndex("_id");
            long idNo = item.getLong(idxId);

            SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = myPrefs.edit();

            editor.putLong("problemId", idNo);
            editor.commit();

            migrate(ProblemAddEditFragment.newInstance(MODE_UPDATE, idNo));
        }
    }

    //問題リストを表示するメソッド
    public void list(Cursor cursor){
        SQLiteDatabase db = _helper.getWritableDatabase();
        _helper = new DatabaseHelper(getActivity());

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

        TextView textStyle = view.findViewById(R.id.styleTitle);
        TextView textQuestion = view.findViewById(R.id.questionTitle);
        Integer count = ProblemDAO.problemCount(db, myPrefs.getLong("titleId", 0));

        if(count == 0){
            //一つも問題が追加されていない場合
            textStyle.setText("");
            textQuestion.setText("");
        }else{
            textStyle.setText("形式");
            textQuestion.setText("問題");
        }

        ListView problemList = view.findViewById(R.id.dialogReportList);

        String[] from = {"choice", "question", "_id"};
        int[] to = {R.id.textStyle, R.id.accountTitle, R.id.updateDelete};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(getActivity(), R.layout.problem_list, cursor, from, to, 0);
        adapter.setViewBinder(new CustomViewBinder());
        problemList.setAdapter(adapter);
    }

    /**
     * リストビューのカスタムビューバインダークラス。
     */
    private class CustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch (view.getId()) {
                case R.id.textStyle:
                    TextView textStyle = view.findViewById(R.id.textStyle);
                    if(cursor.getString(columnIndex).equals("on")){
                        //選択式
                        textStyle.setText("選択式");
                    }else{
                        //記述式
                        textStyle.setText("記述式");
                    }
                    return true;
                case R.id.accountTitle:
                    TextView title = view.findViewById(R.id.accountTitle);
                    title.setText(cursor.getString(columnIndex));
                    return true;
                case R.id.updateDelete:
                    //削除ボタンが押された場合
                    ImageView delete = view.findViewById(R.id.updateDelete);
                    long id = Long.parseLong(cursor.getString(columnIndex));

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)delete.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)delete.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }

                    delete.setOnClickListener((View v) -> {
                        //削除ボタンが押された場合
                        LayoutInflater inflater = getActivity().getLayoutInflater();
                        View dialogView = inflater.inflate(R.layout.dialog_delete_check, null, false);
                        //ダイアログ作成
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setView(dialogView);

                        builder.setPositiveButton(R.string.dialogDeleteTitle, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                _helper = new DatabaseHelper(getActivity());
                                SQLiteDatabase db = _helper.getWritableDatabase();
                                //保存領域に接続
                                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

                                String msg = "";
                                ProblemDAO.delete(db, id);
                                Cursor cursor = ProblemDAO.findAll(db, myPrefs.getLong("titleId", 0));
                                list(cursor);
                                msg = "削除が完了しました";
                                Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                            }
                        });

                        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });

                        //ダイアログ出力
                        builder.create().show();
                    });
                    return true;
            }
            return false;
        }
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment) {
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back() {
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
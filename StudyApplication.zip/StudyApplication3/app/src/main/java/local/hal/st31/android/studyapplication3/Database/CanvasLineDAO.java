package local.hal.st31.android.studyapplication3.Database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;

public class CanvasLineDAO {
    public static ArrayList<Long> findCanvasId(SQLiteDatabase db, long memoId) {
        String sql = "SELECT canvasId FROM canvasLine WHERE memoId = '" + memoId + "' GROUP BY canvasId";
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        int count = 0;
        ArrayList<Long> result = new ArrayList<>();
        for (int i = 0; i < cursor.getCount(); i++) {
            int idxCanvasId = cursor.getColumnIndex("canvasId");
            String strCanvasId = cursor.getString(idxCanvasId);
            result.add(Long.parseLong(strCanvasId));
            cursor.moveToNext();
        }
        return result;
    }

    /**
     * 特定のキャンパス線情報を取得
     * @param db
     * @param canvasId
     * @return
     */
    public static ArrayList<ArrayList<Float>> findIdByPK(SQLiteDatabase db, ArrayList<Long> canvasId) {
        ArrayList<ArrayList<Float>> arrayList = new ArrayList<>();
        for (int i=0; i<canvasId.size(); i++){
            String sql = "SELECT * FROM canvasLine WHERE canvasId = '" + canvasId.get(i) + "'";
            Cursor cursor = db.rawQuery(sql, null);
            cursor.moveToFirst();
            ArrayList<Float> result = new ArrayList<>();
            for (int j = 0; j < cursor.getCount(); j++) {
                int idxGetX = cursor.getColumnIndex("getX");
                String getX = cursor.getString(idxGetX);
                int idxGetY = cursor.getColumnIndex("getY");
                String getY = cursor.getString(idxGetY);

                result.add(Float.parseFloat(getX));
                result.add(Float.parseFloat(getY));
                cursor.moveToNext();
            }
            arrayList.add(result);
        }
        return arrayList;
    }

    /**
     * キャンパス線データを追加するメソッド
     * @param db
     * @param canvasId
     * @param getX
     * @param getY
     * @return
     */
    public static long insert(SQLiteDatabase db, long canvasId, long memoId, float getX, float getY) {
        String canvasSql = "INSERT INTO canvasLine (canvasId, memoId, getX, getY) VALUES (?, ?, ?, ?)";
        SQLiteStatement canvasStmt = db.compileStatement(canvasSql);
        canvasStmt.bindLong(1, canvasId);
        canvasStmt.bindLong(2, memoId);
        canvasStmt.bindString(3, String.valueOf(getX));
        canvasStmt.bindString(4, String.valueOf(getY));
        long insertedId = canvasStmt.executeInsert();
        return insertedId;
    }

    /**
     * キャンパス線データを変更するメソッド
     * @param db
     * @param canvasId
     * @param getX
     * @param getY
     * @return
     */
    public static long update(SQLiteDatabase db, long canvasId, long memoId, float getX, float getY){
        String canvasSql = "INSERT INTO canvasLine (canvasId, memoId, getX, getY) VALUES (?, ?, ?, ?)";
        SQLiteStatement canvasStmt = db.compileStatement(canvasSql);
        canvasStmt.bindLong(1, canvasId);
        canvasStmt.bindLong(2, memoId);
        canvasStmt.bindString(3, String.valueOf(getX));
        canvasStmt.bindString(4, String.valueOf(getY));
        long insertedId = canvasStmt.executeInsert();
        return insertedId;
    }

    /**
     * キャンバスの線を削除するメソッド
     * @param db
     * @return
     */
    public static int delete(SQLiteDatabase db, long canvasId) {
        String sql = "DELETE FROM canvasLine WHERE canvasId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, canvasId);
        int result = stmt.executeUpdateDelete();
        return result;
    }

    public static int deleteByMemoId(SQLiteDatabase db, long memoId) {
        String sql = "DELETE FROM canvasLine WHERE memoId = ?";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindLong(1, memoId);
        int result = stmt.executeUpdateDelete();
        return result;
    }
}

package local.hal.st31.android.studyapplication3.ui.account;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager2.widget.ViewPager2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.User;
import local.hal.st31.android.studyapplication3.Database.UserDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.home.Flashcard.FlashcardTopFragment;
import local.hal.st31.android.studyapplication3.ui.home.HomeFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AccountEditFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AccountEditFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    View view;

    public static AccountEditFragment newInstance(){
// Fragemnt01 インスタンス生成
        AccountEditFragment AccountEditFragment = new AccountEditFragment();

        return AccountEditFragment;
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_account_edit,
                container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        //戻るボタンが押された場合
        ImageView btnBack = view.findViewById(R.id.accountEditBack);
        btnBack.setOnClickListener((View v) -> {
            editor.putString("menu", "アカウント");
            editor.commit();
            back();
        });

        //編集ボタンが押された場合
        Button btnEdit = view.findViewById(R.id.btnEdit);
        btnEdit.setOnClickListener((View v) -> {

            String strOldUserId = myPrefs.getString("userId", null);

            User result = UserDAO.findUserIdByPK(db, strOldUserId);

            //ユーザーID
            EditText etUserId = view.findViewById(R.id.etUserId);
            String strUserId = etUserId.getText().toString();
            //ユーザー名
            EditText etUserName = view.findViewById(R.id.etUserName);
            String strUserName = etUserName.getText().toString();
            //パスワード
            EditText etOldPassword = view.findViewById(R.id.etOldPassword);
            String strOldPassword = etOldPassword.getText().toString();
            //パスワード確認
            EditText etNewPassword = view.findViewById(R.id.etNewPassword);
            String strNewPassword = etNewPassword.getText().toString();
            int flg = 0;

            //ユーザーID
            if(strUserId.equals("")){
                //空白チェック
                etUserId.setError("値を入力してください");
                flg = 1;
            }
            //ユーザー名
            if(strUserName.equals("")){
                //空白チェック
                etUserName.setError("値を入力してください");
                flg = 1;
            }
            //古いパスワード
            if(!strOldPassword.equals(result.getPassword())){
                //本人かチェックする
                etOldPassword.setError("パスワードが一致しません");
                flg = 1;
            }
            //新しいパスワード
            if(strNewPassword.length() < 8){
                //0文字だった場合、パスワードを変更しない
                if(strNewPassword.length() != 0){
                    //文字数チェック
                    etNewPassword.setError("8文字以上入力してください");
                    flg = 1;
                }
            }

            if(flg == 0){
                User userResult = UserDAO.findUserIdByPK(db, strUserId);
                if(userResult != null){
                    //被りチェック
                    etUserId.setError("既に登録されているIDです");
                    flg = 1;
                }
                if(flg == 0){
                    if(strNewPassword.equals("")){
                        strNewPassword = strOldPassword;
                    }

                    Integer userIdResult = UserDAO.update(db,strOldUserId, strUserId, strUserName, strNewPassword);

                    editor.putString("userId", strUserId);
                    editor.putInt("intFlg", userIdResult);
                    editor.commit();
                    back();
                }
            }
        });

        String strOldUserId = myPrefs.getString("userId", null);

        User result = UserDAO.findUserIdByPK(db, strOldUserId);

        //ユーザーID
        EditText etUserId = view.findViewById(R.id.etUserId);
        //ユーザー名
        EditText etUserName = view.findViewById(R.id.etUserName);

        etUserId.setText(result.getUserId());
        etUserName.setText(result.getUserName());
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
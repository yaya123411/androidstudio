package local.hal.st31.android.studyapplication3.ui.home.ProblemMake;

import static android.app.Activity.RESULT_OK;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.UiThread;
import androidx.annotation.WorkerThread;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.core.os.HandlerCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.view.ViewParent;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;

import java.io.BufferedReader;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.GradesDAO;
import local.hal.st31.android.studyapplication3.Database.Problem;
import local.hal.st31.android.studyapplication3.Database.ProblemDAO;
import local.hal.st31.android.studyapplication3.Database.ProblemInterrupt;
import local.hal.st31.android.studyapplication3.Database.ProblemInterruptDAO;
import local.hal.st31.android.studyapplication3.Database.TitleList;
import local.hal.st31.android.studyapplication3.Database.TitleListDAO;
import local.hal.st31.android.studyapplication3.Database.User;
import local.hal.st31.android.studyapplication3.Database.UserDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.OCR;
import local.hal.st31.android.studyapplication3.ui.home.Memo.MemoTopFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemQuestion.ProblemFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemQuestion.ProblemTopFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProblemMakeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProblemMakeFragment extends Fragment {
    //タイトル作成
    /**
     * 新規登録モードを表す定数フィールド。
     */
    static final int MODE_INSERT = 1;
    /**
     * 更新モードを表す定数フィールド。
     */
    static final int MODE_UPDATE = 2;
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    private EditText editResult;
    private TextView textResult;
    //任意の識別番号
    private static final int REQUEST_CODE = 12345;
    //ocr
    private static final int REQUEST_CODE_PICK_CONTENT = 0;
    private OCR _ocr;
    private View view;
    private String serch = "",sort = "",where = "";
    private int listDesign;
    private ListView problemList;
    private boolean timeInvalidFlg = false;
    /**
     * ログに記載するタグ用の文字列。
     */
    protected static final String DEBUG_TAG = "Post2DB";
    /**
     * post先のURL。
     */
    private static final String ACCESS_URL = "http://yaya8976.php.xdomain.jp/android/studyApplication/problem.php";

    //フラグメントを呼び出す
    public static ProblemMakeFragment newInstance(){
// Fragemnt01 インスタンス生成
        ProblemMakeFragment ProblemMakeFragment = new ProblemMakeFragment();

        return ProblemMakeFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_problem_make,
                container, false);

        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "問題タイトルリスト");
        editor.commit();
        setHasOptionsMenu(true);

        return view;
    }

    //---------------------------------------メニューを出力する------------------------------------

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        //保存領域に接続
        SharedPreferences myPrefs = this.getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

        MenuItem menuItem = menu.findItem(R.id.menuSeach);
        SearchView searchView = (SearchView) menuItem.getActionView();

//        SearchView searchView = (SearchView) MenuItemCompat.getActionView(menuItem);
        searchView.setSubmitButtonEnabled(false);

        if (!myPrefs.getString("serch","").equals("")) {
            // TextView.setTextみたいなもの
            searchView.setQuery(myPrefs.getString("serch",""), false);
        }

        searchView.setOnQueryTextListener(this.onQueryTextListener);

        super.onCreateOptionsMenu(menu, inflater);
//        inflater.inflate(R.menu.option_menu_second, menu);
    }

    //メニューが押された場合
    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();
        Cursor cursor;

        boolean returnVal = true;
        int itemId = item.getItemId();
        switch(itemId){
            case R.id.menuUpdate:
                //更新順
                sort = "更新順";
                break;
            case R.id.menuNew:
                //新しい順
                sort = "新しい順";
                break;
            case R.id.menuOld:
                //古い順
                sort = "古い順";
                break;
            case R.id.menuTimeFirst:
                //制限時間が短い順
                sort = "制限時間が短い順";
                editor.putString("sort", "制限時間が短い順");
                break;
            case R.id.menuTimeLast:
                //制限時間が長い順
                sort = "制限時間が長い順";
                break;
            case R.id.menuUpload:
                //アップロードされてる
                where = "アップロードされてる";
                break;
            case R.id.menuNotupload:
                //アップロードされていない
                where = "アップロードされていない";
                break;
            case R.id.menuReset:
                //リセット
                serch = "";
                where = "";
                sort = "";
                break;
        }

        editor.commit();
        cursor = TitleListDAO.findSeach(db, myPrefs.getString("userId", ""), serch, where, sort);
        list(cursor);
        return returnVal;
    }

    private SearchView.OnQueryTextListener onQueryTextListener = new SearchView.OnQueryTextListener() {

        @Override
        public boolean onQueryTextSubmit(String searchWord) {
            //検索ボタンが押された後に反映
            return true;
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            //入力した直後に反映
            try {
                //保存領域に接続
                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                _helper = new DatabaseHelper(getActivity());
                SQLiteDatabase db = _helper.getWritableDatabase();
                Cursor cursor;

                serch = newText;
                cursor = TitleListDAO.findSeach(db, myPrefs.getString("userId", ""), serch, where, sort);
                list(cursor);
            }catch (NullPointerException e){
                e.printStackTrace();
            }
            return false;
        }
    };

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        problemList = view.findViewById(R.id.dialogReportList);
        problemList.setOnItemClickListener(new ListItemClickListener());

        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        _ocr = new OCR(getActivity().getApplicationContext());

        //メモボタンが押された場合
        FloatingActionButton memo = view.findViewById(R.id.flashcardTopMemo);
        memo.setOnClickListener((View v) -> {
            migrate(MemoTopFragment.newInstance());
        });

        //戻るボタンが押された場合
        ImageView btnBack = view.findViewById(R.id.problemMakeBack);
        btnBack.setOnClickListener((View v) -> {
            editor.putString("menu", "");
            editor.commit();
            back();
        });

        //タイトル作成ボタンが押された場合
        Button btnAdd = view.findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener((View v) -> {
            ProblemTitleEditDialog(0);
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        //保存領域に接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        Cursor cursor = TitleListDAO.findAll(db, myPrefs.getString("userId", null));
        list(cursor);

        if(myPrefs.getInt("intFlg", 0) != 0){
            String msg = "";

            if(myPrefs.getInt("intFlg", 0) == 1){
                msg = "削除";
            }else if(myPrefs.getInt("intFlg", 0) == 2){
                msg = "追加";
            }else if(myPrefs.getInt("intFlg", 0) == 3){
                msg = "更新";
            }

            Toast.makeText(this.getActivity(), msg + "しました", Toast.LENGTH_SHORT).show();

            editor.putInt("intFlg", 0);
            editor.commit();
        }
    }

    /**
     * ダイアログで問題のタイトルを追加or変更する
     * @param idNo 追加or変更を識別(追加＝0、変更＝1以上) 変更の場合は変更する行のIDが入る
     */
    public void ProblemTitleEditDialog(long idNo){
        //ダイアログ作成
        //データベース接続
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_problem_title, null, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(dialogView);

        TextView dialogProblemBtnAdd = dialogView.findViewById(R.id.dialogProblemBtnAdd);
        TextView btnCansel = dialogView.findViewById(R.id.btnCansel);
        TextView textDialogProblemTitle = dialogView.findViewById(R.id.textFlashcardTitle);
        EditText etProblemTitle = dialogView.findViewById(R.id.etFlashcardTitle);
        EditText etEditTime = dialogView.findViewById(R.id.etEditTime);
        CheckBox timeInvalid = dialogView.findViewById(R.id.timeInvalid);

        //「制限時間を無効にする」のチェックボックスが操作された場合
        timeInvalid.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                timeInvalidFlg = isChecked;
            }
        });

        if(idNo != 0){
            //変更処理
            TitleList result = TitleListDAO.findIdByPK(db, idNo);
            etProblemTitle.setText(result.getTitle());
            etEditTime.setText(result.getTime());
            dialogProblemBtnAdd.setText("変更");
            textDialogProblemTitle.setText("タイトル編集");
            if(result.getTime().equals("0")){
                //制限時間を無効にしている場合
                timeInvalid.setChecked(true);
            }
        }

        //ダイアログ出力
        AlertDialog dialog = builder.show();

        dialogProblemBtnAdd.setOnClickListener(parts -> {
            //追加ボタンが押された場合
            int flg = 0;
            String msg = "";

            String strTitle = etProblemTitle.getText().toString();
            String strEditTime = etEditTime.getText().toString();

            if(strTitle.equals("")){
                etProblemTitle.setError("値を入力してください");
                flg = 1;
            }
            if(timeInvalidFlg){
                strEditTime = "0";
            }else{
                if(strEditTime.contains(":")){
                    etEditTime.setError("不要な文字列が含まれています「:」");
                    flg = 1;
                }else if(!Pattern.matches("^-?[0-9]*.?[0-9]+$", strEditTime)){
                    etEditTime.setError("数字以外が入力されています");
                    flg = 1;
                }else if(strEditTime.equals("0")){
                    etEditTime.setError("0は指定できません");
                    flg = 1;
                }
            }

            if(flg == 0){
                //入力チェックがOKだった場合
                //保存領域をオープンさせる
                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

                if(idNo == 0){
                    //追加する処理
                    //公式の人かを識別
                    int formula = UserDAO.formulaMarkFindByPK(db, myPrefs.getString("userId", null));

                    if(strEditTime.equals("")){
                        //タイムが空白だった場合
                        TitleListDAO.insert(db, myPrefs.getString("userId", null), strTitle, 0, formula);
                    }else{
                        TitleListDAO.insert(db, myPrefs.getString("userId", null), strTitle, Integer.parseInt(strEditTime), formula);
                    }
                    msg = "追加しました";
                }else{
                    //変更する処理
                    if(strEditTime.equals("")){
                        //タイムが空白だった場合
                        TitleListDAO.update(db, myPrefs.getLong("titleId",0), strTitle, 0);
                    }else{
                        TitleListDAO.update(db, myPrefs.getLong("titleId",0), strTitle, Integer.parseInt(strEditTime));
                    }
                    msg = "変更しました";
                }
                Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                Cursor cursor = TitleListDAO.findAll(db, myPrefs.getString("userId", null));
                list(cursor);
                dialog.dismiss();
            }
        });
        btnCansel.setOnClickListener(parts -> {
            //キャンセルボタンが押された場合
            dialog.dismiss();
        });
    }

    /**
     * リストがクリックされた時のリスナクラス
     */
    private class ListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            Cursor item = (Cursor) parent.getItemAtPosition(position);
            int idxId = item.getColumnIndex("_id");
            long idNo = item.getLong(idxId);

            //データベース接続
            _helper = new DatabaseHelper(getActivity());
            SQLiteDatabase db = _helper.getWritableDatabase();

            //保存領域に接続
            SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
            //タイトルIDを保存する
            SharedPreferences.Editor editor = myPrefs.edit();

            editor.putLong("titleId", idNo);
            editor.commit();

            //単語数を取得
            String count = ProblemDAO.countProblem(db, idNo);

            //始めようとしている単語帳が中断している単語帳であるかを調べる
            ProblemInterrupt result = null;
            try {
                result = ProblemInterruptDAO.findIdByPK(db, myPrefs.getLong("titleId",0));
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if(result == null){
                //始めようとしている単語帳が中断している単語帳ではない場合
                //問題が追加されているか確認する
                Problem problemId = ProblemDAO.findTitleAll(db, idNo);
                if(problemId == null){
                    Toast.makeText(getActivity(), "中身が空です", Toast.LENGTH_SHORT).show();
                }else{
                    migrate(ProblemTopFragment.newInstance(idNo));
                }
            }else {
                //中断している問題だった場合
                //ダイアログ生成
                AlertDialog.Builder mydialog = new AlertDialog.Builder(getActivity());
                mydialog.setTitle(R.string.flashcardDialogMsg);
                TextView textMsg = new TextView(getActivity());

                textMsg.setText(Integer.parseInt(result.getPage()) + "/" + count + "\n" + result.getUpdateTime());
                textMsg.setGravity(Gravity.CENTER);
                textMsg.setTextSize(16);
                mydialog.setView(textMsg);

                String[] choices = {};
                choices = new String[]{"続きから", "最初から", "キャンセル"};

                mydialog.setItems(choices, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //問題数
                        editor.putString("count", count);
                        ProblemInterrupt result = null;
                        TitleList title = null;
                        try {
                            result = ProblemInterruptDAO.findIdByPK(db, myPrefs.getLong("titleId",0));
                            title = TitleListDAO.findIdByPK(db, myPrefs.getLong("titleId",0));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        if (which == 0) {
                            //続きからを選択した場合
                            Double second = result.getTime() - Math.floor(result.getTime());
                            second = second * 60;
                            second = Math.floor(second);
                            int s = (int) Math.round(second);
                            int m = (int) Math.floor(result.getTime());
                            //現在のページ
                            editor.putInt("now", Integer.parseInt(result.getPage())-1);
                            editor.putString("reply", result.getJson());
                            //問題を解く画面のレイアウトをデフォルトに設定
                            editor.putInt("problemMemoFlg", 0);
                            //メモ帳タイトルを初期化する
                            editor.putLong("memoTitleId", 0);
                            editor.putLong("alltime", (long) (m * 1000 * 60) + (s * 1000));
                            editor.putInt("time", Integer.parseInt(title.getTime()));
                            editor.commit();
                            ArrayList<String> problemList = ProblemDAO.ProblemIdAll(db, myPrefs.getLong("titleId",0));

                            back();
                            migrate(ProblemFragment.newInstance(problemList, Long.parseLong(String.valueOf(0)), 1));
                        } else if(which == 1) {
                            //最初からを選択した場合
                            back();
                            migrate(ProblemTopFragment.newInstance(myPrefs.getLong("titleId",0)));
                        }
                    }
                });
                mydialog.show();
            }
        }
    }

    /**
     * リストビューのカスタムビューバインダークラス。
     */
    private class CustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch(view.getId()) {
                case R.id.uploadImage:
                    _helper = new DatabaseHelper(getActivity());
                    SQLiteDatabase db = _helper.getWritableDatabase();
                    //保存領域に接続
                    SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

                    TitleList titleList = TitleListDAO.findIdByPK(db, Long.parseLong(cursor.getString(columnIndex)));
                    ImageView update = view.findViewById(R.id.uploadImage);
                    long id = Long.parseLong(cursor.getString(columnIndex));
                    if(titleList.getUploadFlg() == 1){
                        //アップロードされていれば
                        update.setVisibility(View.INVISIBLE);
                    }else{
                        //アップロードされていなければ
                        update.setOnClickListener((View v) -> {
//                          アップロードボタンが押された場合
                            //追加されている単語帳の個数を取得する
                            String problemCount = ProblemDAO.countProblem(db, id);

                            if(Integer.parseInt(problemCount) != 0){
                                //問題が1つ以上追加されていた場合
                                //ユーザー名を取得する
                                User userName = UserDAO.findUserIdByPK(db, myPrefs.getString("userId",""));
                                //タイトルを取得する
                                TitleList problemTitle = TitleListDAO.findIdByPK(db, id);

                                LayoutInflater inflater = getActivity().getLayoutInflater();
                                View dialogView = inflater.inflate(R.layout.flashcard_top_dialog, null, false);
                                TextView textUserName = dialogView.findViewById(R.id.dialogUserId);
                                TextView textProblemTitle = dialogView.findViewById(R.id.flashcardTitle);

                                textUserName.setText(userName.getUserName());
                                textProblemTitle.setText(problemTitle.getTitle());

                                //ダイアログのリストを取得
                                ListView dialogProblemList = dialogView.findViewById(R.id.dialogReportList);
                                TextView style = dialogView.findViewById(R.id.dialogFront);
                                TextView  question = dialogView.findViewById(R.id.dialogBack);
                                TextView  count = dialogView.findViewById(R.id.titleCount5);

                                style.setText("形式");
                                question.setText("問題");

                                Cursor cursors = ProblemDAO.findProblemAll(db, id);
                                String[] from = {"choice", "question"};
                                int[] to = {R.id.left, R.id.right};
                                SimpleCursorAdapter adapter = new SimpleCursorAdapter(getActivity(), R.layout.list_two_center, cursors, from, to, 0);
                                adapter.setViewBinder(new DialogCustomViewBinder());
                                dialogProblemList.setAdapter(adapter);
                                count.setText(cursors.getCount() + "件");

                                //ダイアログ作成
                                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setView(dialogView);

                                builder.setPositiveButton(R.string.dialogUpload, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        EditText etMsg = dialogView.findViewById(R.id.etMsg);
                                        String strMsg = etMsg.getText().toString();

                                        TitleListDAO.updateUpload(db, id);
                                        //問題タイトルを取得する
                                        TitleList titleList = TitleListDAO.findIdByPK(db, id);
                                        //問題を取得する
                                        ArrayList<Map<String, String>> problemList = ProblemDAO.findByTitleId(db, id);

                                        //インスタンス化
                                        ObjectMapper mapper = new ObjectMapper();
                                        String jsonReply = "";
                                        try {
                                            // mapをjson文字列に変換します。
                                            jsonReply = mapper.writeValueAsString(problemList);
                                        } catch (Exception e) {
                                            // エラー!
                                            e.printStackTrace();
                                        }

                                        sendPastData(id, strMsg, myPrefs.getString("userId", null), titleList.getTitle(), titleList.getFormulaFlg(), titleList.getTime(), jsonReply);

                                        Cursor cursor = TitleListDAO.findAll(db, myPrefs.getString("userId", null));
                                        list(cursor);
                                        Toast.makeText(getActivity(), "アップロードが完了しました", Toast.LENGTH_SHORT).show();
                                    }
                                });

                                builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                    }
                                });

                                //ダイアログ出力
                                AlertDialog alertDialog = builder.create();
                                alertDialog.setCanceledOnTouchOutside(false);
                                alertDialog.show();
                            }else{
                                Toast.makeText(getActivity(), "中身が空です", Toast.LENGTH_SHORT).show();
                            }
                        });
                        update.setVisibility(View.VISIBLE);
                    }
                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        ((ViewGroup)update.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)update.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }
                    return true;
                case R.id.edit:
                    //編集ボタンが押された場合
                    //保存領域に接続
                    SharedPreferences editMyPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editEditor = editMyPrefs.edit();

                    ImageView edit = view.findViewById(R.id.edit);
                    long editId = Long.parseLong(cursor.getString(columnIndex));

                    edit.setOnClickListener((View v) -> {
                        //タイトル編集ボタンが押された場合
                        String[] choices = new String[]{"タイトル編集", "問題一覧"};
                        editEditor.putLong("titleId", editId);
                        editEditor.commit();

                        //ダイアログ作成
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setItems(choices, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if(which == 0){
                                    //タイトル編集が押された場合
                                    ProblemTitleEditDialog(editId);
                                }else if(which == 1){
                                    //問題一覧が押された場合
                                    migrate(ProblemAddFragment.newInstance());
                                }
                            }
                        });
                        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        //ダイアログ出力
                        builder.show();
                    });
                    return true;
                case R.id.btnDelete:
                    //削除ボタンが押された場合
                    ImageView delete = view.findViewById(R.id.btnDelete);
                    id = Long.parseLong(cursor.getString(columnIndex));

                    delete.setOnClickListener((View v) -> {
                        //削除ボタンが押された場合
                        LayoutInflater inflater = getActivity().getLayoutInflater();
                        View dialogView = inflater.inflate(R.layout.dialog_delete_check, null, false);
                        //ダイアログ作成
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setView(dialogView);

                        builder.setPositiveButton(R.string.dialogDeleteTitle, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                _helper = new DatabaseHelper(getActivity());
                                SQLiteDatabase db = _helper.getWritableDatabase();
                                //保存領域に接続
                                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

                                String msg = "";
                                TitleListDAO.delete(db, id);
                                ProblemDAO.problemTitledelete(db, id);
                                GradesDAO.delete(db, id);
                                Cursor cursor = TitleListDAO.findAll(db, myPrefs.getString("userId", null));
                                list(cursor);
                                msg = "削除が完了しました";
                                Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                            }
                        });

                        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });

                        //ダイアログ出力
                        builder.create().show();
                    });
                    return true;
                case R.id.uploadTitle:
                    TextView uploadTitle = view.findViewById(R.id.uploadTitle);
                    uploadTitle.setText(cursor.getString(columnIndex));
                    ViewParent a = view.getParent();
                    return true;
            }
            return false;
        }
    }

    /**
     * 問題のリストビューのカスタムビューバインダークラス。
     */
    private class DialogCustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch (view.getId()) {
                case R.id.right:
                    TextView right = (TextView)view;
                    right.setText(cursor.getString(columnIndex));

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)right.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)right.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }
                    return true;
                case R.id.left:
                    TextView left = (TextView)view;
                    if(cursor.getString(columnIndex).equals("on")){
                        //選択式
                        left.setText("選択式");
                    }else{
                        //記述式
                        left.setText("記述式");
                    }
                    return true;
            }
            return false;
        }
    }

    //音声認識が終わると自動で呼び出されるメソッド
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        textResult.setVisibility(View.VISIBLE);
        editResult.setVisibility(View.VISIBLE);

        if(requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            //マイクボタンが押された場合
            //data から音声認識の結果を取り出す（リスト形式で）
            ArrayList<String> kekka = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

            //認識結果が一つ以上ある場合はテキストビューに結果を表示する
            if (kekka.size() > 0) {
                //一番最初にある認識結果を表示する
                editResult.setText(kekka.get(0));
            } else {
                //何らかの原因で音声認識に失敗した場合はエラーメッセージを表示
                editResult.setText("音声の認識に失敗しました…");
            }
        }else if(requestCode == REQUEST_CODE_PICK_CONTENT){
            //カメラボタンの写真を選択するボタンが押された場合
            String ocrString;
            if(resultCode == RESULT_OK && data != null){
                Bitmap bitmap = null;
                if(Build.VERSION.SDK_INT < 19){
                    try{
                        InputStream in = getActivity().getContentResolver().openInputStream(data.getData());
                        bitmap = BitmapFactory.decodeStream(in);
                        try{
                            if(in != null){ in.close(); }
                        }catch(IOException e){
                            e.printStackTrace();
                        }
                    }catch(FileNotFoundException e){
                        e.printStackTrace();
                    }
                }else{
                    Uri uri = data.getData();
                    try{
                        ParcelFileDescriptor parcelFileDescriptor = getActivity().getContentResolver().openFileDescriptor(uri, "r");
                        if(parcelFileDescriptor != null){
                            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
                            bitmap = BitmapFactory.decodeFileDescriptor(fileDescriptor);
                            parcelFileDescriptor.close();
                        }

                    }catch(IOException e){
                        e.printStackTrace();
                    }
                }
                if(bitmap != null){
                    ocrString = _ocr.getString(getActivity().getApplicationContext(), bitmap);
                }else{
                    ocrString = "bitmap is null";
                }
            }else{
                ocrString = "something wrong?";
            }
            editResult.setText(ocrString);
        }
    }

    //カメラボタンの写真を撮影するボタンが押された場合
    private final ActivityResultLauncher<Void> cameraLauncher = registerForActivityResult(
            new ActivityResultContracts.TakePicturePreview(), bitmap -> {

                textResult.setVisibility(View.VISIBLE);
                editResult.setVisibility(View.VISIBLE);

                try {
                    int rotationDegree = 0;
                    InputImage image = InputImage.fromBitmap(bitmap, rotationDegree);

                    // 日本語もサポートした！
                    TextRecognizer recognizer = TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());

                    Task<Text> task = recognizer.process(image)
                            .addOnSuccessListener(new OnSuccessListener<Text>() {
                                @Override
                                public void onSuccess(Text visionText) {
                                    String resultText = visionText.getText(); // 文字列取得！
                                    editResult.setText(resultText);
                                }
                            });
                }catch (NullPointerException e){
                    editResult.setText("正常に値を受け取れませんでした");
                }
            });

    //問題リストを出力する
    public void list(Cursor cursor){
        ListView problemList = view.findViewById(R.id.dialogReportList);
        TextView count = view.findViewById(R.id.titleCount4);
        String[] from = {"title", "_id", "_id", "_id"};
        int[] to = {R.id.uploadTitle, R.id.uploadImage, R.id.edit, R.id.btnDelete};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this.getActivity(), R.layout.upload, cursor, from, to, 0);
        adapter.setViewBinder(new CustomViewBinder());
        problemList.setAdapter(adapter);
        count.setText(cursor.getCount() + "件検出");
    }

    /**
     * 非同期でサーバにポストを開始するメソッド
     * @param msg
     * @param userId
     * @param title
     * @param formula
     * @param time
     * @param problemJson
     */
    @UiThread
    private void sendPastData(Long id, String msg, String userId, String title, int formula, String time, String problemJson){
        Looper mainLooper = Looper.getMainLooper();
        Handler handler = HandlerCompat.createAsync(mainLooper);
        BackgroundExecutor backgroundPostAccess = new BackgroundExecutor(handler, id, msg, userId, title, formula, time, problemJson);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.submit(backgroundPostAccess);
    }

    /**
     * 非同期でサーバにポストするためのクラス。
     */
    private class BackgroundExecutor implements Runnable{
        /**
         * ハンドラオブジェクト。
         */
        private final Handler _handler;
        /**
         * アップロードメッセージ
         */
        private final Long _id;
        private final String _msg;
        private final String _userId;
        private final String _title;
        private final String _formula;
        private final String _time;
        private final String _problemJson;

        /**
         * コンストラクタ。
         * 非同期でサーバにポストするのに必要な情報を取得する。
         * @param handler
         * @param msg
         */
        public BackgroundExecutor(Handler handler, Long id, String msg, String userId, String title, int formula, String time, String problemJson){
            _handler = handler;
            _id = id;
            _msg = msg;
            _userId = userId;
            _title = title;
            _formula = String.valueOf(formula);
            _time = time;
            _problemJson = problemJson;
        }

        @WorkerThread
        @Override
        public void run(){
            String postData = "titleId=" + _id + "&msg=" + _msg + "&userId=" + _userId + "&title=" + _title + "&formula=" + _formula + "&time=" + _time + "&problemJson=" + _problemJson + "&action=insert";
            HttpURLConnection con = null;
            String err = "";
            InputStream is = null;
            String result = "";

            try {
                URL url = new URL(ACCESS_URL);
                con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setConnectTimeout(5000);
                con.setReadTimeout(5000);
                con.setDoOutput(true);
                OutputStream os = con.getOutputStream();
                os.write(postData.getBytes());
                os.flush();
                os.close();
                int status = con.getResponseCode();
                if(status != 200){
                    throw new IOException("ステータスコード:" + status);
                }
                is = con.getInputStream();

                result = is2String(is);
            }
            catch (SocketTimeoutException ex){
                err = getString(R.string.msg_err_timeout);
                Log.e(DEBUG_TAG, "タイムアウト", ex);
            }
            catch (MalformedURLException ex){
                err = getString(R.string.msg_err_send);
                Log.e(DEBUG_TAG, "URL変換失敗", ex);
            }
            catch (IOException ex){
                err = getString(R.string.msg_err_send);
                Log.e(DEBUG_TAG, "通信失敗", ex);
            }
            finally {
                if(con != null){
                    con.disconnect();
                }
                try {
                    if(is != null){
                        is.close();
                    }
                }
                catch (IOException ex){
                    Log.e(DEBUG_TAG, "InputStream開放失敗", ex);
                }
            }
        }

        /**
         * InputStreamオブジェクトを文字列に変換するメソッド。変換文字コードはUTF-8。
         *
         * @param is 変換対象のInputStreamオブジェクト。
         * @return 変換された文字列。
         * @throws IOException 変換に失敗した時に発生。
         */
        private String is2String(InputStream is) throws IOException{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuffer sb = new StringBuffer();
            char[] b = new char[1024];
            int line;
            while (0 <= (line = reader.read(b))){
                sb.append(b, 0, line);
            }
            return sb.toString();
        }
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
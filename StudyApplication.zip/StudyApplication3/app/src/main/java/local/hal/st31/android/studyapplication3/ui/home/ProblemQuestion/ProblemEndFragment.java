package local.hal.st31.android.studyapplication3.ui.home.ProblemQuestion;

import static local.hal.st31.android.studyapplication3.ui.home.Grades.GradesMoreDetailedFragment.getChoose;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import local.hal.st31.android.studyapplication3.Database.CorrectSolutionProblem;
import local.hal.st31.android.studyapplication3.Database.CorrectSolutionProblemDAO;
import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.GradesDAO;
import local.hal.st31.android.studyapplication3.Database.MistakeProblem;
import local.hal.st31.android.studyapplication3.Database.MistakeProblemDAO;
import local.hal.st31.android.studyapplication3.Database.Problem;
import local.hal.st31.android.studyapplication3.Database.ProblemDAO;
import local.hal.st31.android.studyapplication3.Database.ProblemInterruptDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.home.Grades.PastDialogFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProblemEndFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProblemEndFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    View view;

    //フラグメントを呼び出す
    public static ProblemEndFragment newInstance(){
// Fragemnt01 インスタンス生成
        ProblemEndFragment ProblemEndFragment = new ProblemEndFragment();

        return ProblemEndFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_problem_end,
                container, false);

        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        return view;
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;
        //正解か不正解化を判断
        int correctSolutionCount = 0;
        //正解数をカウント
        int count = 0;

        //データベースに接続
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        //保存ファイルに接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        //戻るボタンが押された場合
        ImageView btnBack = view.findViewById(R.id.problemEndBack);
        btnBack.setOnClickListener((View v) -> {
            editor.putString("menu", "");
            editor.commit();
            back();
        });

        Map<Integer, Object> map = null;
        //インスタンス化
        ObjectMapper mapper = new ObjectMapper();

        try {
            // キーがString、値がObjectのマップに読み込みます。
            map = mapper.readValue(myPrefs.getString("reply",null), new TypeReference<Map<Integer, Object>>(){});
        } catch (Exception e) {
            // エラー！
            e.printStackTrace();
        }

        //回答を表示する処理
        String afterAnswer = "";
        Problem problem = null;
        for (Map.Entry<Integer, Object> entry : map.entrySet()) {
            problem = ProblemDAO.findIdByPK(db, entry.getKey());
            if(problem.getChoice().equals("on")){
                String[] answer = String.valueOf(entry.getValue()).split(",");
                for (String s : answer) {
                    if (!s.equals("")) {
                        afterAnswer += s + ",";
                    }
                }
                if(!afterAnswer.equals("")){
                    afterAnswer = afterAnswer.substring(0, afterAnswer.length()-1);
                }
                map.put(entry.getKey(), afterAnswer);
                afterAnswer = "";
            }
        }

        //問題数を取得
        String problemCount = ProblemDAO.countProblem(db, myPrefs.getLong("titleId",0));

        ArrayList<String> problemList = ProblemDAO.ProblemIdAll(db, myPrefs.getLong("titleId",0));

        //ダウンロードIDを取得
        String downloadId = ProblemInterruptDAO.findDownloadId(db, myPrefs.getLong("titleId",0));

        for(int i=0; i<Integer.parseInt(problemCount); i++){
            String[] reply = {};
            String[] myReply = {};
            String strMyReply = "";
            //答えを格納する
            Problem result = ProblemDAO.findIdByPK(db, problemList.get(i));
            //自分の回答を格納する
            strMyReply = (String) map.get(Integer.parseInt((String) problemList.get(i)));

            int gradesCount = GradesDAO.GradesCount(db, myPrefs.getLong("titleId",0));

            if(result.getChoice().equals("on")){
                //選択問題
                reply = result.getReply().split(",");
                myReply = strMyReply.split(",");

                for(int j=0; j<reply.length; j++){
                    for(int k=0; k<myReply.length; k++){
                        if(reply[j].equals(myReply[k])){
                            correctSolutionCount++;
                        }
                    }
                }

                if(correctSolutionCount == reply.length && reply.length == myReply.length){
                    //正解した場合
                    CorrectSolutionProblemDAO.insert(db, myPrefs.getString("userId",null), myPrefs.getLong("titleId",0), Long.parseLong(problemList.get(i)), downloadId, gradesCount, result.getReply());
                    count++;
                }else{
                    //間違えた問題だったら
                    if(strMyReply.equals("")){
                        //未回答だった場合
                        MistakeProblemDAO.insert(db, myPrefs.getString("userId",null), myPrefs.getLong("titleId",0), Long.parseLong(problemList.get(i)), downloadId, gradesCount, result.getReply(), strMyReply, 1);
                    }else{
                        MistakeProblemDAO.insert(db, myPrefs.getString("userId",null), myPrefs.getLong("titleId",0), Long.parseLong(problemList.get(i)), downloadId, gradesCount, result.getReply(), strMyReply, 0);
                    }
                }
            }else{
                //記述問題
                if(!result.getReply().equals(strMyReply)){
                    //間違えた問題だったら
                    if(strMyReply.equals("")) {
                        //未回答だった場合
                        MistakeProblemDAO.insert(db, myPrefs.getString("userId", null), myPrefs.getLong("titleId", 0), Long.parseLong(problemList.get(i)), downloadId, gradesCount, result.getReply(), strMyReply, 1);
                    }else{
                        MistakeProblemDAO.insert(db, myPrefs.getString("userId",null), myPrefs.getLong("titleId",0), Long.parseLong(problemList.get(i)), downloadId, gradesCount, result.getReply(), strMyReply, 0);
                    }
                }else{
                    CorrectSolutionProblemDAO.insert(db, myPrefs.getString("userId",null), myPrefs.getLong("titleId",0), Long.parseLong(problemList.get(i)), downloadId, gradesCount, result.getReply());
                    count++;
                }
            }
            correctSolutionCount = 0;
        }
        //分計算
        long minit = myPrefs.getInt("time", 0) - myPrefs.getLong("minit", 0) - 1;
        Double second = Double.parseDouble(String.valueOf(60 - myPrefs.getLong("second", 0)));
        BigDecimal beforeSecond = new BigDecimal(second / 60);
        BigDecimal afterSecond = beforeSecond.setScale(2, BigDecimal.ROUND_DOWN);  //小数第２位で四捨五入する
        Double time = (Double) (minit + Double.parseDouble(String.valueOf(afterSecond)));
        //正答率を計算
        int correctSolutionRate = (int) Math.floor(Double.parseDouble(String.valueOf(count)) / Double.parseDouble(problemCount) * 100);
        //成績に追加
        if(myPrefs.getInt("time", 0) == 0){
            time = 0.0;
        }
        GradesDAO.insert(db, myPrefs.getString("userId",null), myPrefs.getLong("titleId",0), downloadId, correctSolutionRate , count, time);

        //時間に直す
        String strMinit = "";
        String strSecond = "";
        String strTime = "";
        int flg = 0;
        BigDecimal bigSecond = new BigDecimal(second).stripTrailingZeros();

        for(int i=0;i<17;i++){
            if(minit >= 60 * (i+1)){
                if(second != 0){
                    strSecond = Integer.parseInt(String.valueOf(bigSecond)) + "秒";
                }
                if(minit != 0){
                    strMinit = minit + "分";
                }
                strTime = i + strMinit + strSecond;
                flg = 1;
            }else if(flg == 0){
                if(second != 0 && second != 60.0){
                    strSecond = String.valueOf(second).substring(0, String.valueOf(second).length()-2) + "秒";
                }else{
                    //時間切れになった場合
                    strMinit = (minit+1) + "分";
                }
                if(minit != 0){
                    strMinit = minit + "分";
                }
                strTime = strMinit + strSecond;
                break;
            }else{
                break;
            }
        }

        if(myPrefs.getInt("time", 0) == 0){
            strTime = "";
        }

        //同じタイトルの個数をカウントする
        int gradesCount = GradesDAO.GradesCount(db, myPrefs.getLong("titleId",0));
        TextView textNumberOfTimes = view.findViewById(R.id.textNumberOfTimes);
        TextView textAnswerRate = view.findViewById(R.id.textAnswerRate);
        TextView textAnswerNum = view.findViewById(R.id.textAnswerNum);
        TextView textTime = view.findViewById(R.id.textBack);

        textNumberOfTimes.setText(gradesCount + "回目");
        textAnswerRate.setText(correctSolutionRate + "%正解");
        textAnswerNum.setText(count + "/" + problemCount);
        textTime.setText(strTime);

        //中断したことがあれば、中断記録を消す
        ProblemInterruptDAO.delete(db, myPrefs.getLong("titleId",0));

        myPrefs.getLong("alltime", 0);
        editor.commit();

        //-------------------------------問題一覧を表示-----------------------------
        //問題を出力する
        ListView list = view.findViewById(R.id.dialogReportList);

        list.setOnItemClickListener(new ListItemClickListener());

        Cursor cursor = ProblemDAO.findPastAll(db, myPrefs.getLong("titleId", 0), gradesCount);
        String[] from = {"question","c._id","choice"};
        int[] to = {R.id.left,R.id.right,R.id.listTherrImageStyle};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(getActivity(), R.layout.list_therr_image, cursor, from, to, 0);
        adapter.setViewBinder(new CustomViewBinder());
        list.setAdapter(adapter);
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    /**
     * リストビューのカスタムビューバインダークラス。
     */
    private class CustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch(view.getId()) { //to に書いたどれかが来ているはず
                case R.id.right:
                    ImageView imageView = (ImageView)view;
                    if(cursor.getString(columnIndex) != null){
                        //間違っている問題ならば
                        imageView.setImageResource(R.drawable.vatu_var2);
                    }else{
                        //正解した問題ならば
                        imageView.setImageResource(R.drawable.circle_ver2);
                    }

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        ((ViewGroup)imageView.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)imageView.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }
                    return true;
                case R.id.listTherrImageStyle:
                    TextView style = (TextView)view;
                    if(cursor.getString(columnIndex).equals("on")){
                        style.setText("選択式");
                    }else if(cursor.getString(columnIndex).equals("off")){
                        style.setText("記述式");
                    }
                    return true;
            }
            return false; //name はアダプタのデフォルトで処理
        }
    }

    /**
     * リストがクリックされた時のリスナクラス
     */
    public class ListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            Cursor item = (Cursor) parent.getItemAtPosition(position);
            int idxId = item.getColumnIndex("_id");
            long idNo = item.getLong(idxId);

            _helper = new DatabaseHelper(getActivity());
            SQLiteDatabase db = _helper.getWritableDatabase();
            //保存領域に接続
            SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

            //解いた回数を取得
            int gradesCount = GradesDAO.GradesCount(db, myPrefs.getLong("titleId",0));

            //ダイアログ作成
            DialogFragment dialogFragment = new PastDialogFragment();
            // 渡す値をセット
            Bundle args = new Bundle();

            //問題IDを取得
            ArrayList<String> problemList = ProblemDAO.ProblemIdAll(db, myPrefs.getLong("titleId",0));
            //問題を取り出す
            MistakeProblem misResult = MistakeProblemDAO.findIdByProblemId(db, Long.parseLong((String) problemList.get(position)), gradesCount);
            HashMap<String, String> choose = ProblemDAO.getChoose(db, problemList.get(position));

            String jsonReply = "";
            //インスタンス化
            ObjectMapper mapper = new ObjectMapper();
            try {
                // mapをjson文字列に変換します。
                jsonReply = mapper.writeValueAsString(choose);
            } catch (Exception e) {
                // エラー!
                e.printStackTrace();
            }

            args.putString("choose", jsonReply);

            if(misResult == null){
                //クリックした問題が正解していた場合
                CorrectSolutionProblem correctSolutionResult = CorrectSolutionProblemDAO.findIdByProblemId(db, Long.parseLong((String) problemList.get(position)), gradesCount);
                args.putString("question", correctSolutionResult.getQuestion());
                args.putString("reply", correctSolutionResult.getReply());
                args.putString("explanation", correctSolutionResult.getExplanation());
            }else{
                args.putString("question", misResult.getQuestion());
                args.putString("reply", misResult.getReply());
                HashMap<String, String> missChoose = getChoose(misResult.getChoice(), misResult.getMyReply(), misResult.getChoiceA(), misResult.getChoiceB(), misResult.getChoiceC(), misResult.getChoiceD(), misResult.getChoiceE(), misResult.getChoiceF(), misResult.getChoiceG());
                try {
                    // mapをjson文字列に変換します。
                    jsonReply = mapper.writeValueAsString(missChoose);
                } catch (Exception e) {
                    // エラー!
                    e.printStackTrace();
                }
                args.putString("missChoose", jsonReply);
                if(misResult.getMyReply().equals("")){
                    //未回答だった場合
                    args.putString("myReply", "未回答");
                }else{
                    args.putString("myReply", misResult.getMyReply());
                }
                args.putString("explanation", misResult.getExplanation());
            }
            dialogFragment.setArguments(args);

            //ダイアログ出力
            dialogFragment.show(getActivity().getSupportFragmentManager(), "my_dialog");
        }
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
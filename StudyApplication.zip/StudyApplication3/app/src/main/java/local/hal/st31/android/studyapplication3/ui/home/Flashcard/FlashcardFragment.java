package local.hal.st31.android.studyapplication3.ui.home.Flashcard;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.CountDownTimer;
import android.text.format.Time;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.SimpleCursorAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Map;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.Flashcard;
import local.hal.st31.android.studyapplication3.Database.FlashcardDAO;
import local.hal.st31.android.studyapplication3.Database.FlashcardInterrupt;
import local.hal.st31.android.studyapplication3.Database.FlashcardInterruptDAO;
import local.hal.st31.android.studyapplication3.Database.GradesDAO;
import local.hal.st31.android.studyapplication3.Database.ProblemInterrupt;
import local.hal.st31.android.studyapplication3.Database.ProblemInterruptDAO;
import local.hal.st31.android.studyapplication3.Database.TitleListDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.download.DownloadFragment;
import local.hal.st31.android.studyapplication3.ui.home.Grades.GradesDetailedFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemMake.ProblemMakeFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemQuestion.ProblemEndFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FlashcardFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FlashcardFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    private int flg = 0;
    //自動フラグ
    private int automaticFlg = 0;
    private int automaticFlashcardFlg;
    /**
     * タイマー本体
     */
    CountDownTimer countDownTimer;
    /**
     * タイマー終了時間
     */
    long alltime = 0;
    private TextView main,textFlashcardCount;
    private Button btnPrevious,btnNext;
    private SeekBar flashcardBer;
    private Switch automatic;
    private CheckBox rememberCheckBox;
    View view;

    //フラグメントを呼び出す
    public static FlashcardFragment newInstance(ArrayList<String> flashcardId){
// Fragemnt01 インスタンス生成
        FlashcardFragment FlashcardFragment = new FlashcardFragment();

        Bundle args = new Bundle();
        args.putStringArrayList("flashcardId", flashcardId);
        FlashcardFragment.setArguments(args);

        return FlashcardFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        //SharedPreferencesで保存した値の取得
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        View view = inflater.inflate(R.layout.fragment_flashcard,
                container, false);

        editor.putString("menu", "単語帳");
        editor.commit();
        setHasOptionsMenu(true);

        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        return view;
    }

    //------------------------------------メニュー出力-------------------------------------
    //メニューが押された場合
    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        //保存ファイルに接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        //データーベース接続
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        boolean returnVal = true;
        int itemId = item.getItemId();
        switch(itemId){
            case R.id.menuPose:
                //ポーズボタンが押された場合
                if(countDownTimer != null){
                    automatic = view.findViewById(R.id.automatic);
                    automatic.setChecked(false);
                    countDownTimer.cancel();
                }
                //ダイアログ作成
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                TextView titleView = new TextView(getActivity());
                titleView.setText(R.string.poseTitle);
                titleView.setTextSize(24);
                titleView.setTextColor(Color.WHITE);
                titleView.setGravity(Gravity.CENTER);
                titleView.setPadding(20, 20, 20, 20);
                titleView.setBackgroundColor(getResources().getColor(R.color.alertBlue));
                builder.setCustomTitle(titleView);

                String[] choices = {"続行する", "中断する"};
                builder.setItems(choices, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(which == 1){
                            //中断するボタンが押された場合
                            //始めようとしている単語帳が中断している単語帳であるかを調べる
                            FlashcardInterrupt FlashcardInterruptResult = null;
                            try {
                                FlashcardInterruptResult = FlashcardInterruptDAO.findIdByPK(db, myPrefs.getLong("titleId",0));
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                            String downloadId = FlashcardInterruptDAO.findDownloadId(db, myPrefs.getLong("titleId",0));

                            Time time = new Time("Asia/Tokyo");
                            time.setToNow();
                            String date = String.format("%04d年%02d月%02d日　%02d時%02d分", time.year, time.month+1, time.monthDay, time.hour, time.minute);
                            if(FlashcardInterruptResult == null){
                                //中断履歴がなかった場合
                                FlashcardInterruptDAO.insert(db, myPrefs.getString("userId",null), myPrefs.getLong("titleId",0), downloadId, myPrefs.getInt("now",0), myPrefs.getInt("rememberFlg",0), date);
                            }else{
                                FlashcardInterruptDAO.update(db,  myPrefs.getLong("titleId",0), myPrefs.getInt("now",0), date);
                            }

                            editor.putInt("automaticFlg", 0);
                            editor.putInt("rememberFlg", 0);
                            editor.commit();

                            back();
                            if(myPrefs.getInt("downloadFlg",0) == 0){
                                //自分で作成した単語帳だった場合
                                migrate(FlashcardTopFragment.newInstance());
                            }else{
                                //ダウンロードで得た単語帳だった場合
                                migrate(DownloadFragment.newInstance());
                            }
                            Toast.makeText(getActivity(), "お疲れ様でした", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.setCancelable(false);
                alertDialog.setCanceledOnTouchOutside(false);
                alertDialog.show();
                break;
        }
        editor.putString("menu", "");
        editor.commit();
        return returnVal;
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        //データベースに接続
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        //保存ファイルに接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        //部品を取得
        textFlashcardCount = view.findViewById(R.id.textFlashcardCount);
        main = view.findViewById(R.id.textMain);
        btnPrevious = view.findViewById(R.id.btnPrevious);
        btnNext = view.findViewById(R.id.btnNext);

        Bundle args = getArguments();
        //単語を取得
        Flashcard result = FlashcardDAO.findIdByPK(db, Long.parseLong((String) args.getStringArrayList("flashcardId").get(myPrefs.getInt("now",0))));
        textFlashcardCount.setText(myPrefs.getInt("now",0)+1 + "/" + myPrefs.getString("count",null));
        //単語を出力
        main.setClickable(true);
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //単語がクリックされた場合
                if(flg == 0){
                    main.setText(result.getFront());
                    flg = 1;
                }else{
                    main.setText(result.getBack());
                    flg = 0;
                }
            }
        });
        if(flg == 0){
            //デフォルト
            main.setText(result.getFront());
            flg = 1;
        }

        if(myPrefs.getInt("now",0) == 0){
            //一番最初の問題だった場合
            btnPrevious.setEnabled(false);
        }
        if(myPrefs.getInt("now",0) == Integer.parseInt(myPrefs.getString("count",null))-1){
            //一番最後の問題だった場合
            btnNext.setText("終了");
        }

        //----------------------単語操作(flashcardBer)が操作された場合-----------------------------
        // SeekBar
        flashcardBer = view.findViewById(R.id.flashcardBer);
        if(Integer.parseInt(myPrefs.getString("count", null)) == 1){
            //問題の個数が1個だった場合
            flashcardBer.setVisibility(View.INVISIBLE);
        }
        // 初期値
        flashcardBer.setProgress(myPrefs.getInt("now",0));
        // 最大値
        flashcardBer.setMax(Integer.parseInt(myPrefs.getString("count",null))-1);
        flashcardBer.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    //ツマミがドラッグされると呼ばれる
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        //下の問題数変更
                        textFlashcardCount.setText(progress+1 + "/" + myPrefs.getString("count",null));
                        // 初期値
                        flashcardBer.setProgress(progress);
                        SharedPreferences.Editor editor = myPrefs.edit();
                        //現在のページを変更
                        editor.putInt("now", progress);
                        editor.commit();
                    }

                    //ツマミがタッチされた時に呼ばれる
                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    //ツマミがリリースされた時に呼ばれる
                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        //確定させる
                        if(countDownTimer != null){
                            countDownTimer.cancel();
                            automatic.setChecked(false);
                        }
                        back();
                        migrate(FlashcardFragment.newInstance(args.getStringArrayList("flashcardId")));
                    }

                });

        //-----------------------------------自動-----------------------------------
        automatic = view.findViewById(R.id.automatic);
        automatic.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            TextView shareTitle = view.findViewById(R.id.shareTitle);
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    //自動スイッチがオンの場合
                    automaticFlg = 1;
                    alltime = 5 * 1000;
                    automaticFlashcardFlg = 0;
                    time();
                } else {
                    //自動スイッチがオフの場合
                    automaticFlg = 0;
                    automaticFlashcardFlg = 1;
                    editor.putInt("automaticFlg", 0);
                    editor.commit();
                    countDownTimer.cancel();
                }
            }
        });
        if(myPrefs.getInt("automaticFlg",0) == 1){
            //スタート前の設定でオンの場合
            automatic.setChecked(true);
            automaticFlg = 1;
            alltime = 5 * 1000;
            automaticFlashcardFlg = 0;
            countDownTimer.cancel();
            time();
        }

        //------------------------------------覚えた-------------------------------------
        rememberCheckBox = view.findViewById(R.id.remember);
        //チェックボックスが押された場合
        rememberCheckBox.setOnClickListener(parts -> {
            if (rememberCheckBox.isChecked()) {
                //チェック入れた場合
                FlashcardDAO.rememberUpdate(db, Long.parseLong((String) args.getStringArrayList("flashcardId").get(myPrefs.getInt("now",0))), 1);
            } else {
                //チェック外した場合
                FlashcardDAO.rememberUpdate(db, Long.parseLong((String) args.getStringArrayList("flashcardId").get(myPrefs.getInt("now",0))), 0);
            }
        });
        Flashcard flashcard = FlashcardDAO.findIdByPK(db, Long.parseLong((String) args.getStringArrayList("flashcardId").get(myPrefs.getInt("now",0))));
        if(flashcard.getRemember() == 1){
            //「覚えた」にチェックがついていた場合
            rememberCheckBox.setChecked(true);
        }

        //前へボタンが押された場合
        Button btnPrevious = view.findViewById(R.id.btnPrevious);
        btnPrevious.setOnClickListener((View v) -> {
            if(countDownTimer != null){
                countDownTimer.cancel();
                automatic.setChecked(false);
            }
            editor.putInt("now", myPrefs.getInt("now",0)-1);
            editor.commit();
            back();
            migrate(FlashcardFragment.newInstance(args.getStringArrayList("flashcardId")));
        });

        //次へボタンが押された場合
        Button btnNext = view.findViewById(R.id.btnNext);
        btnNext.setOnClickListener((View v) -> {
            if(countDownTimer != null){
                countDownTimer.cancel();
                automatic.setChecked(false);
            }
            String strNext = btnNext.getText().toString();
            if(strNext.equals("終了")){
                //終了ボタンが押された場合
                dialog();
            }else{
                //保存領域に接続
                editor.putInt("now", myPrefs.getInt("now",0)+1);
                editor.commit();
                back();
                migrate(FlashcardFragment.newInstance(args.getStringArrayList("flashcardId")));
            }
        });
    }

    //制限時間を出力するメソッド
    public void time(){
        countDownTimer = new CountDownTimer(alltime, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                //保存ファイルに接続
                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = myPrefs.edit();

                //データーベース接続
                _helper = new DatabaseHelper(getActivity());
                SQLiteDatabase db = _helper.getWritableDatabase();

                if(automaticFlashcardFlg == 1 || flg == 0){
                    //次以降に切り替わった時にここに入る
                    //現在のページを変更
                    editor.putInt("now", myPrefs.getInt("now",0)+1);
                    editor.commit();
                    //berの処理
                    //下の問題数変更
                    textFlashcardCount.setText(myPrefs.getInt("now",0) + "/" + myPrefs.getString("count",null));
                    // 初期値
                    flashcardBer.setProgress(myPrefs.getInt("now",0));
                    automaticFlashcardFlg = 0;
                }

                //単語を取得
                ArrayList<String> problemList = FlashcardDAO.flashcardIdAll(db, myPrefs.getLong("titleId",0), myPrefs.getInt("rememberFlg",0));
                if(problemList.size() > myPrefs.getInt("now",0)){
                    //単語帳が存在した場合
                    Flashcard result = FlashcardDAO.findIdByPK(db, Long.parseLong((String) problemList.get(myPrefs.getInt("now",0))));
                    if(flg == 0){
                        //単語帳の表示が裏だった場合
                        main.setText(result.getFront());
                        flg = 1;
                        //「覚えた」のチェックボックス処理
                        if(result.getRemember() == 1){
                            //「覚えた」にチェックがついていた場合
                            rememberCheckBox.setChecked(true);
                        }else{
                            rememberCheckBox.setChecked(false);
                        }
                    }else{
                        //単語帳の表示が表だった場合
                        main.setText(result.getBack());
                        automaticFlashcardFlg = 1;
                        flg = 0;
                    }
                    if(myPrefs.getInt("now",0) == 0){
                        //一番最初の問題だった場合
                        btnPrevious.setEnabled(false);
                    }else{
                        btnPrevious.setEnabled(true);
                    }
                    if(myPrefs.getInt("now",0) == problemList.size()-1){
                        //一番最後の問題だった場合
                        btnNext.setText("終了");
                    }else{
                        btnNext.setText("次へ");
                    }
                    time();
                }else{
                    //単語帳が存在しない場合
                    dialog();
                }
            }
        }.start();
    }

    //終了ダイアログの生成
    public void dialog(){
        //ダイアログ作成
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        TextView titleView = new TextView(getActivity());
        titleView.setText(R.string.endTitle);
        titleView.setTextSize(24);
        titleView.setTextColor(Color.WHITE);
        titleView.setGravity(Gravity.CENTER);
        titleView.setPadding(20, 20, 20, 20);
        titleView.setBackgroundColor(getResources().getColor(R.color.alertBlue));
        builder.setCustomTitle(titleView);

        String[] choices = {"終了する", "キャンセル"};
        builder.setItems(choices, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(which == 0){
                    //終了するボタンが押された場合
                    //保存領域に接続
                    SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = myPrefs.edit();

                    _helper = new DatabaseHelper(getActivity());
                    SQLiteDatabase db = _helper.getWritableDatabase();

                    FlashcardInterruptDAO.delete(db, myPrefs.getLong("titleId",0));
                    editor.putInt("automaticFlg", 0);
                    editor.putInt("rememberFlg", 0);
                    editor.commit();

                    back();
                    if(myPrefs.getInt("downloadFlg",0) == 0){
                        //自分で作成した単語帳だった場合
                        migrate(FlashcardTopFragment.newInstance());
                    }else{
                        //ダウンロードで得た単語帳だった場合
                        migrate(DownloadFragment.newInstance());
                    }
                    Toast.makeText(getActivity(), "お疲れ様でした", Toast.LENGTH_SHORT).show();
                }else if(which == 1){
                    //キャンセルが押された場合
                    automatic.setChecked(false);
                }
            }
        });

        //ダイアログ出力
        AlertDialog alertDialog = builder.create();
        alertDialog.setCancelable(false);
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.show();
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
package local.hal.st31.android.studyapplication3.ui.home.ProblemQuestion;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.CountDownTimer;
import android.text.format.Time;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Map;

import local.hal.st31.android.studyapplication3.Database.Canvas;
import local.hal.st31.android.studyapplication3.Database.CanvasDAO;
import local.hal.st31.android.studyapplication3.Database.CanvasLineDAO;
import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.Memo;
import local.hal.st31.android.studyapplication3.Database.MemoDAO;
import local.hal.st31.android.studyapplication3.Database.Problem;
import local.hal.st31.android.studyapplication3.Database.ProblemDAO;
import local.hal.st31.android.studyapplication3.Database.ProblemInterrupt;
import local.hal.st31.android.studyapplication3.Database.ProblemInterruptDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.download.DownloadFragment;
import local.hal.st31.android.studyapplication3.ui.home.Memo.CanvasFragment;
import local.hal.st31.android.studyapplication3.ui.home.Memo.CanvasView;
import local.hal.st31.android.studyapplication3.ui.home.ProblemMake.ProblemMakeFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProblemFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProblemFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    /**
     * タイマー本体
     */
    private CountDownTimer countDownTimer;
    /**
     * タイマー終了時間
     */
    long alltime = 0;
    /**
     * 1問の回答を代入する
     */
    String oneReply = "";
    /**
     * 新規登録モードを表す定数フィールド。
     */
    static final int MODE_INSERT = 1;
    private SharedPreferences myPrefs;
    CanvasView cv;
    String color;
    int colorFlg = 0;
    int intColor = 0;
    AlertDialog.Builder builder;
    View view;

    //フラグメントを呼び出す
    public static ProblemFragment newInstance(ArrayList<String> problemList, Long idNo, int mode){
// Fragemnt01 インスタンス生成
        ProblemFragment ProblemFragment = new ProblemFragment();

        Bundle args = new Bundle();
        args.putStringArrayList("problemList", problemList);
        args.putLong("idNo", idNo);
        args.putInt("mode", mode);
        ProblemFragment.setArguments(args);

        return ProblemFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        //保存ファイルに接続
        this.myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "問題出題");

        if(myPrefs.getInt("problemMemoFlg",0) == 0){
            //デフォルト
            view = inflater.inflate(R.layout.fragment_problem,
                    container, false);
        }else if(myPrefs.getInt("problemMemoFlg",0) == 1){
            //メモ帳が押された場合
            view = inflater.inflate(R.layout.problem_two,
                    container, false);
            editor.putString("menu", "問題出題2画面メモリスト");
        }else if(myPrefs.getInt("problemMemoFlg",0) == 2){
            //メモ帳の追加ボタン又はリストをタップした場合
            view = inflater.inflate(R.layout.problem_memo_edit_two,
                    container, false);
            editor.putString("menu", "問題出題2画面メモ編集");
        }else if(myPrefs.getInt("problemMemoFlg",0) == 3){
            //キャンパスボタンが押された場合
            view = inflater.inflate(R.layout.problem_canvas_two,
                    container, false);
            editor.putString("menu", "問題出題2画面キャンバス");
        }
        //拡大表示が押された場合
        if(myPrefs.getInt("problemMemoFlg",0) == 4){
            //メモ帳リストの拡大表示ボタンが押された場合
            view = inflater.inflate(R.layout.problem_memo_list,
                    container, false);
            editor.putString("menu", "問題出題拡大表示メモリスト");
        }else if(myPrefs.getInt("problemMemoFlg",0) == 5){
            //メモ帳編集の拡大表示ボタンが押された場合
            view = inflater.inflate(R.layout.problem_memo_edit,
                    container, false);
            editor.putString("menu", "問題出題拡大表示メモ編集");
        }else if(myPrefs.getInt("problemMemoFlg",0) == 6){
            //メモ帳キャンバスの拡大表示ボタンが押された場合
            view = inflater.inflate(R.layout.problem_canvas,
                    container, false);
            editor.putString("menu", "問題出題拡大表示キャンバス");
        }

        editor.commit();
        setHasOptionsMenu(true);

        cv = (CanvasView) view.findViewById(R.id.problem_canvas_view);
        if(cv != null){
            //キャンパスボタンが押された場合
            _helper = new DatabaseHelper(getActivity());
            SQLiteDatabase db = _helper.getWritableDatabase();

            Bundle args = getArguments();

            ArrayList<Long> canvasId = CanvasLineDAO. findCanvasId(db, args.getLong("idNo"));
            ArrayList<Canvas> result = CanvasDAO.findIdByPK(db, args.getLong("idNo"));
            ArrayList<ArrayList<Float>> resultLine = CanvasLineDAO.findIdByPK(db, canvasId);
            if(result.size() != 0){
                ArrayList<Integer> ArrayColor = new ArrayList<>();  // カラーリスト
                ArrayList<ArrayList<Float>> coordinateParent = new ArrayList<>(); //座標を保存する

                for (int i=0; i<result.size(); i++){
                    ArrayList<Float> coordinateChaild = new ArrayList<>();

                    coordinateChaild.add(result.get(i).getStartGetX());
                    coordinateChaild.add(result.get(i).getStartGetY());
                    coordinateChaild.add(result.get(i).getFinishGetX());
                    coordinateChaild.add(result.get(i).getFinishGetY());

                    coordinateParent.add(coordinateChaild);
                    ArrayColor.add(result.get(i).getColor());
                }
                CanvasView.setCoordinate(coordinateParent);
                CanvasView.setColorList(ArrayColor);
                CanvasView.setLine(resultLine);
            }
        }

        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });
        return view;
    }

    //メニューが押された場合
    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        //保存ファイルに接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        Bundle args = getArguments();

        boolean returnVal = true;
        int itemId = item.getItemId();
        switch(itemId){
            case R.id.menuPose:
                //ポーズボタンが押された場合
                if(countDownTimer != null){
                    countDownTimer.cancel();
                }

                //ダイアログ作成
                builder = new AlertDialog.Builder(getActivity());
                TextView titleView = new TextView(getActivity());
                titleView.setText(R.string.poseTitle);
                titleView.setTextSize(24);
                titleView.setTextColor(Color.WHITE);
                titleView.setGravity(Gravity.CENTER);
                titleView.setPadding(20, 20, 20, 20);
                titleView.setBackgroundColor(getResources().getColor(R.color.alertBlue));
                builder.setCustomTitle(titleView);

                String[] choices = {"続行する", "中断する"};
                builder.setItems(choices, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(which == 0){
                            //続行するボタンが押された場合
                            if(myPrefs.getInt("time", 0) != 0){
                                time();
                            }
                        }else if(which == 1){
                            //中断するボタンが押された場合
                            //データベース接続
                            _helper = new DatabaseHelper(getActivity());
                            SQLiteDatabase db = _helper.getWritableDatabase();

                            EditText etReply = view.findViewById(R.id.etReply);
                            String strReply = etReply.getText().toString();

                            //保存ファイルに接続
                            SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

                            Bundle args = getArguments();

                            //始めようとしている単語帳が中断している単語帳であるかを調べる
                            ProblemInterrupt result = null;
                            try {
                                result = ProblemInterruptDAO.findIdByPK(db, myPrefs.getLong("titleId",0));
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                            Double second = Double.parseDouble(String.valueOf(myPrefs.getLong("second", 0)));
                            BigDecimal beforeSecond = new BigDecimal(second / 60);
                            BigDecimal afterSecond = beforeSecond.setScale(2, BigDecimal.ROUND_DOWN);  //小数第２位で四捨五入する
                            Double time = (Double) (myPrefs.getLong("minit",0) + Double.parseDouble(String.valueOf(afterSecond)));

                            ArrayList<String> problemList = args.getStringArrayList("problemList");
                            Problem problemResult = ProblemDAO.findIdByPK(db, problemList.get(myPrefs.getInt("now", 0)));
                            if(problemResult.getChoice().equals("off")){
                                //記述式だった場合
                                oneReply = strReply;
                            }

                            Map<Integer, Object> map = null;
                            //インスタンス化
                            ObjectMapper mapper = new ObjectMapper();

                            try {
                                // jsonからmapに変換
                                map = mapper.readValue(myPrefs.getString("reply", null), new TypeReference<Map<Integer, Object>>() {
                                });
                            } catch (Exception e) {
                                // エラー！
                                e.printStackTrace();
                            }
                            if(!"".equals(oneReply)) {
                                //回答されていた場合
                                map.put(Integer.parseInt((String) problemList.get(myPrefs.getInt("now", 0))), oneReply);
                            }


                            String jsonReply = "";
                            try {
                                // mapをjson文字列に変換します。
                                jsonReply = mapper.writeValueAsString(map);
                            } catch (Exception e) {
                                // エラー!
                                e.printStackTrace();
                            }

                            String downloadId = ProblemInterruptDAO.findDownloadId(db, myPrefs.getLong("titleId",0));

                            Time date = new Time("Asia/Tokyo");
                            date.setToNow();
                            String strDate = String.format("%04d年%02d月%02d日　%02d時%02d分", date.year, date.month+1, date.monthDay, date.hour, date.minute);

                            if(result == null){
                                //中断履歴がなかった場合
                                ProblemInterruptDAO.insert(db, myPrefs.getString("userId",null), myPrefs.getLong("titleId",0), downloadId, jsonReply, myPrefs.getInt("now",0)+1, time, strDate);
                            }else{
                                ProblemInterruptDAO.update(db,  myPrefs.getLong("titleId",0), jsonReply, myPrefs.getInt("now",0)+1, time, strDate);
                            }
                            Toast.makeText(getActivity(), "中断しました", Toast.LENGTH_SHORT).show();
                            editor.putString("menu", "問題一覧");
                            editor.putInt("tileFlg", 0);
                            editor.putInt("problemMemoFlg", 0);
                            editor.commit();
                            back();
                            if(myPrefs.getInt("downloadFlg",0) == 0){
                                //自分で作った問題だった場合
                                migrate(ProblemMakeFragment.newInstance());
                            }else{
                                //ダウンロードして得た問題だった場合
                                migrate(DownloadFragment.newInstance());
                            }
                        }
                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.setCancelable(false);
                alertDialog.setCanceledOnTouchOutside(false);
                alertDialog.show();
                break;
            case R.id.menuPen:
                //キャンバスボタンが押された場合
                EditText etTitle = view.findViewById(R.id.productMemoEtTitle);
                String strTitle = etTitle.getText().toString();
                EditText etNote = view.findViewById(R.id.productMemoEtNote);
                String strNote = etNote.getText().toString();

                _helper = new DatabaseHelper(getActivity());
                SQLiteDatabase db = _helper.getWritableDatabase();
                if(args.getLong("idNo") != 0){
                    editor.putLong("memoTitleId", args.getLong("idNo"));
                    editor.commit();
                }

                Memo memo = MemoDAO.findIdByPK(db, myPrefs.getLong("memoTitleId", 0));

                if (memo != null) {
                    //上書き処理
                    if (!strTitle.equals(memo.getTitle()) || !strNote.equals(memo.getNote())) {
                        //タイトル又は内容が変更されていた場合
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("保存しますか?");

                        builder.setPositiveButton(R.string.dialog_yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //はいが押された場合
                                long memoId = MemoDAO.insert(db, myPrefs.getString("userId", null), strTitle, strNote);
                                editor.putLong("memoTitleId", memoId);
                                if(myPrefs.getInt("problemMemoFlg",0) == 2){
                                    //2画面のキャンバスボタンが押された場合
                                    editor.putInt("problemMemoFlg", 3);
                                }else if(myPrefs.getInt("problemMemoFlg",0) == 5){
                                    //拡大表示のキャンバスボタンが押された場合
                                    editor.putInt("problemMemoFlg", 6);
                                }
                                editor.commit();
                                memoActivity(myPrefs.getLong("memoTitleId", 0) ,1);
                            }
                        });
                        builder.setNegativeButton(R.string.dialog_no, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //いいえが押された場合
                                etTitle.setText(memo.getTitle());
                                etNote.setText(memo.getNote());
                                if(myPrefs.getInt("problemMemoFlg",0) == 2){
                                    //2画面のキャンバスボタンが押された場合
                                    editor.putInt("problemMemoFlg", 3);
                                }else if(myPrefs.getInt("problemMemoFlg",0) == 5){
                                    //拡大表示のキャンバスボタンが押された場合
                                    editor.putInt("problemMemoFlg", 6);
                                }
                                editor.commit();
                                memoActivity(myPrefs.getLong("memoTitleId", 0) ,1);
                            }
                        });

                        //ダイアログ出力
                        builder.create().show();
                    } else {
                        if(myPrefs.getInt("problemMemoFlg",0) == 2){
                            //2画面のキャンバスボタンが押された場合
                            editor.putInt("problemMemoFlg", 3);
                        }else if(myPrefs.getInt("problemMemoFlg",0) == 5){
                            //拡大表示のキャンバスボタンが押された場合
                            editor.putInt("problemMemoFlg", 6);
                        }
                        editor.commit();
                        memoActivity(myPrefs.getLong("memoTitleId", 0) ,1);
                    }
                } else {
                    //新規登録処理
                    if (!strTitle.equals("") || !strNote.equals("")) {
                        //タイトル又は内容が変更されていた場合
                        builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("保存しますか?");

                        builder.setPositiveButton(R.string.dialog_yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //はいが押された場合
                                long memoId = MemoDAO.insert(db, myPrefs.getString("userId", null), strTitle, strNote);
                                editor.putLong("memoTitleId", memoId);
                                if(myPrefs.getInt("problemMemoFlg",0) == 2){
                                    //2画面のキャンバスボタンが押された場合
                                    editor.putInt("problemMemoFlg", 3);
                                }else if(myPrefs.getInt("problemMemoFlg",0) == 5){
                                    //拡大表示のキャンバスボタンが押された場合
                                    editor.putInt("problemMemoFlg", 6);
                                }
                                editor.commit();
                                memoActivity(myPrefs.getLong("memoTitleId", 0) ,1);
                            }
                        });
                        builder.setNegativeButton(R.string.dialog_no, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //いいえが押された場合
                                etTitle.setText("");
                                etNote.setText("");
                                if(myPrefs.getInt("problemMemoFlg",0) == 2){
                                    //2画面のキャンバスボタンが押された場合
                                    editor.putInt("problemMemoFlg", 3);
                                }else if(myPrefs.getInt("problemMemoFlg",0) == 5){
                                    //拡大表示のキャンバスボタンが押された場合
                                    editor.putInt("problemMemoFlg", 6);
                                }
                                editor.commit();
                                memoActivity(myPrefs.getLong("memoTitleId", 0) ,1);
                            }
                        });

                        //ダイアログ出力
                        builder.create().show();
                    } else {
                        migrate(CanvasFragment.newInstance(args.getLong("idNo")));
                        if(myPrefs.getInt("problemMemoFlg",0) == 2){
                            //2画面のキャンバスボタンが押された場合
                            editor.putInt("problemMemoFlg", 3);
                        }else if(myPrefs.getInt("problemMemoFlg",0) == 5){
                            //拡大表示のキャンバスボタンが押された場合
                            editor.putInt("problemMemoFlg", 6);
                        }
                        editor.commit();
                        memoActivity(args.getLong("idNo") ,1);
                    }
                }
                break;
            case R.id.menuProblemTowMagnification:
                //拡大表示
                if(myPrefs.getInt("problemMemoFlg",0) == 1){
                    //メモ帳リストの拡大ボタンが押された場合
                    editor.putInt("problemMemoFlg", 4);
                    memoActivity(0 ,1);
                }else if(myPrefs.getInt("problemMemoFlg",0) == 2){
                    //メモ帳編集の拡大ボタンが押された場合
                    editor.putInt("problemMemoFlg", 5);
                    memoActivity(args.getLong("idNo") ,1);
                }else if(myPrefs.getInt("problemMemoFlg",0) == 3){
                    //メモ帳キャンバスの拡大ボタンが押された場合
                    editor.putInt("problemMemoFlg", 6);
                    memoActivity(args.getLong("idNo") ,1);
                }
                editor.commit();
                break;
            case R.id.menuShrink:
                //縮小表示
                if(myPrefs.getInt("problemMemoFlg",0) == 4){
                    //メモ帳リストの縮小ボタンが押された場合
                    editor.putInt("problemMemoFlg", 1);
                    memoActivity(0 ,1);
                }else if(myPrefs.getInt("problemMemoFlg",0) == 5){
                    //メモ帳編集の縮小ボタンが押された場合
                    editor.putInt("problemMemoFlg", 2);
                    memoActivity(args.getLong("idNo") ,1);
                }else if(myPrefs.getInt("problemMemoFlg",0) == 6){
                    //メモ帳キャンパスの縮小ボタンが押された場合
                    editor.putInt("problemMemoFlg", 3);
                    memoActivity(args.getLong("idNo") ,1);
                }
                editor.commit();
                break;
            case R.id.menuBack:
                //一つ戻るボタンが押された場合
                intColor = cv.oneReturn();
                if(intColor == Color.BLACK){
                    //ペンの色が黒の場合
                    color = "#000000";
                }else if(intColor == Color.BLUE){
                    //ペンの色が青の場合
                    color = "#0000ff";
                }else if(intColor == Color.GREEN){
                    //ペンの色が緑の場合
                    color = "#008000";
                }else if(intColor == Color.YELLOW){
                    //ペンの色が黄色の場合
                    color = "#ffff00";
                }else if(intColor == Color.RED){
                    //ペンの色が赤の場合
                    color = "#ff0000";
                }
                break;
            case R.id.menuAdvance:
                //一つ進むボタンが押された場合
                cv.oneAdvance();
                break;
            default:
                returnVal = super.onOptionsItemSelected(item);
        }
        return returnVal;
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;
        //データベースに接続
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        //保存ファイルに接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        super.onCreate(savedInstanceState);

        Bundle args = getArguments();

        alltime = myPrefs.getLong("alltime", 0);
        //制限時間
        if(myPrefs.getInt("time", 0) != 0){
            time();
        }

        FloatingActionButton memo = view.findViewById(R.id.memo);
        Button btnPrevious = view.findViewById(R.id.btnPrevious);
        Button btnNext = view.findViewById(R.id.btnNext);
        Button back = view.findViewById(R.id.back);
        Button btnSave = view.findViewById(R.id.btnSave);
        Button problemMemoAdd = view.findViewById(R.id.btnSave);
        ImageView palette = view.findViewById(R.id.palette);
        EditText productMemoEtNote = view.findViewById(R.id.productMemoEtNote);
        EditText productMemoEtTitle = view.findViewById(R.id.productMemoEtTitle);

        ArrayList<String> problemList = args.getStringArrayList("problemList");

        //メモボタンが押された場合
        memo.setOnClickListener((View v) -> {
            //メモ画面の常時非表示を切り替える
            if(myPrefs.getInt("problemMemoFlg",0) == 0){
                editor.putInt("problemMemoFlg", 1);
            }else{
                editor.putInt("problemMemoFlg", 0);
            }
            editor.commit();

            memoActivity(args.getLong("idNo"), 1);
        });
        if(back != null){
            //追加or戻るが押された場合
            back.setOnClickListener((View v) -> {
                //戻るボタンが押された場合
                long idNo = args.getLong("idNo");
                if(myPrefs.getInt("problemMemoFlg",0) == 2){
                    //分割画面でリストが選択された場合
                    editor.putInt("problemMemoFlg", 1);
                    idNo = 0;
                }else if(myPrefs.getInt("problemMemoFlg",0) == 3){
                    //分割画面のキャンバスで戻るボタンが押された場合
                    editor.putInt("problemMemoFlg", 2);
                }else if(myPrefs.getInt("problemMemoFlg",0) == 6){
                    //分割画面でリストが選択された場合
                    editor.putInt("problemMemoFlg", 5);
                }else{
                    //拡大表示状態でリストが選択された場合
                    editor.putInt("problemMemoFlg", 4);
                    idNo = 0;
                }
                editor.commit();
                memoActivity(idNo, 1);
            });
            problemMemoAdd.setOnClickListener((View v) -> {
                //追加ボタンが押された場合
                int flg = 0;
                String strProductMemoEtTitle = productMemoEtTitle.getText().toString();
                String strProductMemoEtNote = productMemoEtNote.getText().toString();

                if(strProductMemoEtTitle.equals("")){
                    //入力チェック
                    productMemoEtTitle.setError("値を入力してください");
                    flg = 1;
                }

                if(flg == 0){
                    //入力チェックに引っかからなかった場合
                    if(args.getLong("idNo") == 0){
                        //新規で登録した場合
                        MemoDAO.insert(db, myPrefs.getString("userId",""), strProductMemoEtTitle, strProductMemoEtNote);
                    }else{
                        //更新した場合
                        MemoDAO.update(db, args.getLong("idNo"), strProductMemoEtTitle, strProductMemoEtNote);
                    }

                    if(myPrefs.getInt("problemMemoFlg",0) == 5){
                        //拡張している編集リストの更新or追加ボタンが押された場合
                        editor.putInt("problemMemoFlg", 4);
                    }else if(myPrefs.getInt("problemMemoFlg",0) == 2){
                        //2画面の編集リストの更新or追加ボタンが押された場合
                        editor.putInt("problemMemoFlg", 1);
                    }
                    editor.commit();
                    memoActivity(0 ,1);
                }
            });
        }

        if(palette != null){
            //保存orパレットボタンが押された場合
            btnSave.setOnClickListener((View v) -> {
                //保存ボタンが押された場合
                ArrayList<ArrayList<Float>> coordinateParent = CanvasView.getCoordinate();
                ArrayList<ArrayList<Float>> lineParent = CanvasView.getLine();
                ArrayList<Integer> colorList = CanvasView.getColorList();

                if(args.getLong("idNo") != 0){
                    editor.putLong("memoTitleId", args.getLong("idNo"));
                    editor.commit();
                }

                Memo memoDAO = MemoDAO.findIdByPK(db, myPrefs.getLong("memoTitleId", 0));

                if(memoDAO == null){
                    //新規登録するならば
                    //ダイアログ作成
                    LayoutInflater inflater = getActivity().getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.dialog_flashcard_title, null, false);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setView(dialogView);

                    TextView dialogCanvasBtnAdd = dialogView.findViewById(R.id.dialogProblemBtnAdd);
                    TextView btnCansel = dialogView.findViewById(R.id.btnCansel);
                    EditText etCanvasTitle = dialogView.findViewById(R.id.etFlashcardTitle);

                    //ダイアログ出力
                    AlertDialog dialog = builder.show();

                    dialogCanvasBtnAdd.setOnClickListener(parts -> {
                        //追加ボタンが押された場合
                        int flg = 0;
                        String strTitle = etCanvasTitle.getText().toString();
                        if(strTitle.equals("")){
                            etCanvasTitle.setError("値を入力してください");
                            flg = 1;
                        }else{
                            flg = 0;
                        }
                        if(flg == 0){
                            long memoId = MemoDAO.insert(db, myPrefs.getString("userId", null), strTitle, "");
                            for(int i=0; i<coordinateParent.size(); i++){
                                long canvasId = CanvasDAO.insert(db, memoId, coordinateParent.get(i).get(0), coordinateParent.get(i).get(1), coordinateParent.get(i).get(2), coordinateParent.get(i).get(3), colorList.get(i));
                                for(int j=0; j<lineParent.get(i).size()/2; j++){
                                    CanvasLineDAO.insert(db, canvasId, memoId, lineParent.get(i).get(j*2), lineParent.get(i).get(j*2+1));
                                }
                            }

                            editor.putLong("memoAction", 1);
                            editor.putLong("memoTitleId", memoId);
                            editor.commit();

                            dialog.dismiss();
                            Toast.makeText(this.getActivity(), "保存しました", Toast.LENGTH_SHORT).show();
                        }
                    });
                    btnCansel.setOnClickListener(parts -> {
                        //キャンセルボタンが押された場合
                        dialog.dismiss();
                    });
                }else{
                    //上書き保存をするならば
                    CanvasDAO.delete(db, myPrefs.getLong("memoTitleId", 0));
                    CanvasLineDAO.deleteByMemoId(db, myPrefs.getLong("memoTitleId", 0));
                    for(int i=0; i<coordinateParent.size(); i++){
                        long canvasId = CanvasDAO.update(db, myPrefs.getLong("memoTitleId", 0), coordinateParent.get(i).get(0), coordinateParent.get(i).get(1), coordinateParent.get(i).get(2), coordinateParent.get(i).get(3), colorList.get(i));
                        for(int j=0; j<lineParent.get(i).size()/2; j++){
                            CanvasLineDAO.update(db, canvasId, myPrefs.getLong("memoTitleId", 0), lineParent.get(i).get(j*2), lineParent.get(i).get(j*2+1));
                        }
                    }
                    Toast.makeText(this.getActivity(), "保存しました", Toast.LENGTH_SHORT).show();
                }
            });
            palette.setOnClickListener((View v) -> {
                //パレットボタンが押された場合
                //ダイアログ作成
                LayoutInflater inflater = getActivity().getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.dialog_problem_palette, null, false);
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setView(dialogView);

                //ダイアログ出力
                AlertDialog dialog = builder.show();
                dialog.setCancelable(false);
                dialog.setCanceledOnTouchOutside(false);

                TextView btnRed = dialogView.findViewById(R.id.btnRed);
                TextView btnYellow = dialogView.findViewById(R.id.btnYellow);
                TextView btnGreen = dialogView.findViewById(R.id.btnGreen);
                TextView btnBlue = dialogView.findViewById(R.id.btnBlue);
                TextView btnBlack = dialogView.findViewById(R.id.btnBlack);
                TextView btnClean = dialogView.findViewById(R.id.btnClean);
                TextView btnCancel = dialogView.findViewById(R.id.btnCancel);
                ImageView penColor = dialogView.findViewById(R.id.penColor);

                cv.penColor(Color.BLACK);

                if(colorFlg == 0){
                    color = "#000000";
                }
                penColor.setColorFilter(Color.parseColor(color), PorterDuff.Mode.SRC_IN);

                //- 動作設定
                btnClean.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        colorFlg = 0;
                        cv.penColor(Color.BLACK);
                        cv.allDelete();
                        dialog.dismiss();
                    }
                });

                //- 動作設定
                btnRed.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        colorFlg = 1;
                        color = "#ff0000";
                        intColor = Color.RED;
                        cv.penColor(Color.RED);
                        dialog.dismiss();
                    }
                });

                //- 動作設定
                btnYellow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        colorFlg = 1;
                        color = "#ffff00";
                        intColor = Color.YELLOW;
                        cv.penColor(Color.YELLOW);
                        dialog.dismiss();
                    }
                });

                //- 動作設定
                btnGreen.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        colorFlg = 1;
                        color = "#008000";
                        intColor = Color.GREEN;
                        cv.penColor(Color.GREEN);
                        dialog.dismiss();
                    }
                });

                //- 動作設定
                btnBlue.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        colorFlg = 1;
                        color = "#0000ff";
                        intColor = Color.BLUE;
                        cv.penColor(Color.BLUE);
                        dialog.dismiss();
                    }
                });

                //- 動作設定
                btnBlack.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        colorFlg = 1;
                        color = "#000000";
                        cv.penColor(Color.BLACK);
                        dialog.dismiss();
                    }
                });

                btnCancel.setOnClickListener(parts -> {
                    //キャンセルボタンが押された場合
                    if(intColor != 0){
                        cv.penColor(intColor);
                    }else{
                        cv.penColor(Color.BLACK);
                    }
                    dialog.dismiss();
                });
            });
        }

        if(btnPrevious != null){
            //次へ、前へボタンが存在する場合
            //前へボタンが押された場合
            btnPrevious.setOnClickListener((View v) -> {
                EditText etReply = view.findViewById(R.id.etReply);
                String strReply = etReply.getText().toString();

                Problem result = ProblemDAO.findIdByPK(db, problemList.get(myPrefs.getInt("now", 0)));

                if(result.getChoice().equals("off")){
                    //記述式だった場合
                    oneReply = strReply;
                }

                Map<Integer, Object> map = null;
                //インスタンス化
                ObjectMapper mapper = new ObjectMapper();

                try {
                    // キーがString、値がObjectのマップに読み込みます。
                    map = mapper.readValue(myPrefs.getString("reply",null), new TypeReference<Map<Integer, Object>>(){});
                } catch (Exception e) {
                    // エラー！
                    e.printStackTrace();
                }
                if(oneReply != null) {
                    if(myPrefs.getInt("now", 0) != 0){
                        map.put(Integer.parseInt((String) problemList.get(myPrefs.getInt("now", 0))), oneReply);
                    }
                }
                String jsonReply = "";
                try {
                    // mapをjson文字列に変換します。
                    jsonReply = mapper.writeValueAsString(map);
                } catch (Exception e) {
                    // エラー!
                    e.printStackTrace();
                }
                editor.putString("reply", jsonReply);
                editor.putInt("beforeNow", myPrefs.getInt("now",0));
                editor.putInt("now", myPrefs.getInt("now",0)-1);
                editor.commit();
                if(countDownTimer != null){
                    countDownTimer.cancel();
                }
                back();
                migrate(ProblemFragment.newInstance(problemList, Long.parseLong(String.valueOf(0)), 0));
            });

            //次へボタンが押された場合
            btnNext.setOnClickListener((View v) -> {
                //画面部品
                String strBtnNext = btnNext.getText().toString();
                EditText etReply = view.findViewById(R.id.etReply);
                String strReply = etReply.getText().toString();

                Problem result = ProblemDAO.findIdByPK(db, problemList.get(myPrefs.getInt("now", 0)));

                if(result.getChoice().equals("off")){
                    //記述式だった場合
                    oneReply = strReply;
                }

                Map<Integer, Object> map = null;
                //インスタンス化
                ObjectMapper mapper = new ObjectMapper();

                try {
                    // jsonからmapに変換
                    map = mapper.readValue(myPrefs.getString("reply", null), new TypeReference<Map<Integer, Object>>() {
                    });
                } catch (Exception e) {
                    // エラー！
                    e.printStackTrace();
                }
                if(!"".equals(oneReply)) {
                    //回答されていた場合
                    map.put(Integer.parseInt((String) problemList.get(myPrefs.getInt("now", 0))), oneReply);
                }


                String jsonReply = "";
                try {
                    // mapをjson文字列に変換します。
                    jsonReply = mapper.writeValueAsString(map);
                } catch (Exception e) {
                    // エラー!
                    e.printStackTrace();
                }
                editor.putString("reply", jsonReply);
                editor.putInt("now", myPrefs.getInt("now",0)+1);
                editor.commit();
                if(countDownTimer != null){
                    countDownTimer.cancel();
                }
                if(strBtnNext.equals("終了")){
                    if(countDownTimer != null){
                        countDownTimer.cancel();
                    }
                    editor.putInt("problemMemoFlg", 0);
                    editor.putInt("continueFlg", 0);
                    editor.commit();
                    //終了ボタンが押された場合
                    if(countDownTimer != null){
                        countDownTimer.cancel();
                    }
                    editor.putInt("tileFlg", 0);

                    //ダイアログ作成
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    TextView titleView = new TextView(getActivity());
                    titleView.setText(R.string.endTitle);
                    titleView.setTextSize(24);
                    titleView.setTextColor(Color.WHITE);
                    titleView.setGravity(Gravity.CENTER);
                    titleView.setPadding(20, 20, 20, 20);
                    titleView.setBackgroundColor(getResources().getColor(R.color.alertBlue));
                    builder.setCustomTitle(titleView);

                    String[] choices = {"終了する", "キャンセル"};
                    builder.setItems(choices, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if(which == 0){
                                //終了するボタンが押された場合
                                //保存ファイルに接続
                                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = myPrefs.edit();
                                //メモ帳を元に戻す
                                editor.putLong("alltime", 0);
                                editor.putInt("problemMemoFlg", 0);
                                editor.putString("menu", "問題終了");
                                editor.commit();

                                back();
                                migrate(ProblemEndFragment.newInstance());
                            }else if(which == 1){
                                //キャンセルが押された場合
                                if(myPrefs.getInt("time", 0) != 0){
                                    time();
                                }
                                //保存領域に接続
                                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = myPrefs.edit();

                                editor.putInt("continueFlg", 1);
                                editor.commit();
                            }
                        }
                    });

                    //ダイアログ出力
                    AlertDialog alertDialog = builder.create();
                    alertDialog.setCancelable(false);
                    alertDialog.setCanceledOnTouchOutside(false);
                    alertDialog.show();

                    editor.putInt("now", myPrefs.getInt("now",0)-1);
                    editor.commit();
                }else{
                    editor.putInt("continueFlg", 1);
                    editor.commit();
                }

                if(myPrefs.getInt("continueFlg", 0) == 1){
                    //ダイアログの「回答を続ける」をクリック又は次へをクリックした場合
                    editor.putInt("continueFlg", 0);
                    editor.commit();

                    back();
                    migrate(ProblemFragment.newInstance(problemList, Long.parseLong(String.valueOf(0)), 0));
                }
            });
        }

        if(myPrefs.getInt("problemMemoFlg",0) == 1 || myPrefs.getInt("problemMemoFlg",0) == 4){
            //メモ帳が押された場合
            ListView memoList = view.findViewById(R.id.dialogReportList);
            memoList.setOnItemClickListener(new ListItemClickListener());

            //作成ボタンが押された場合
            Button btnAdd = view.findViewById(R.id.btnAdd);
            btnAdd.setOnClickListener((View v) -> {
                if(myPrefs.getInt("problemMemoFlg",0) == 1){
                    editor.putInt("problemMemoFlg", 2);
                }else if(myPrefs.getInt("problemMemoFlg",0) == 4){
                    //拡大表示状態で追加ボタンが押された場合
                    editor.putInt("problemMemoFlg", 5);
                }
                editor.commit();

                memoActivity(args.getLong("idNo"), 1);
            });
        }else if(myPrefs.getInt("problemMemoFlg",0) == 2 || myPrefs.getInt("problemMemoFlg",0) == 5){
            //メモ帳の追加ボタン又はリストをタップした場合

            int mode = args.getInt("mode");

            if(args.getLong("idNo") != 0){
                editor.putLong("memoTitleId", args.getLong("idNo"));
                editor.commit();
            }
            if(mode == 1 || myPrefs.getLong("memoAction", 0) == 1){
                //リストがクリックされた場合
                btnSave.setText("更新");
                //データを保持
                Memo result = MemoDAO.findIdByPK(db, myPrefs.getLong("memoTitleId", 0));
                EditText etTitle = view.findViewById(R.id.productMemoEtTitle);
                EditText etNote = view.findViewById(R.id.productMemoEtNote);
                etTitle.setText(result.getTitle());
                etNote.setText(result.getNote());
                editor.putLong("memoAction", 0);
                editor.commit();
            }else{
                editor.putLong("memoTitleId", 0);
                editor.commit();
            }
        }

        try{
            String strBtnNext = "";

            //表示する問題を取得
            Problem result = ProblemDAO.findIdByPK(db, problemList.get(myPrefs.getInt("now", 0)));

            //部品を取得
            TextView textQuestion = view.findViewById(R.id.textQuestion2);
            TextView textNumberOfIssues = view.findViewById(R.id.textNumberOfIssues);
            EditText etReply = view.findViewById(R.id.etReply);
            CheckBox chooseA = view.findViewById(R.id.chooseA);
            CheckBox chooseB = view.findViewById(R.id.chooseB);
            CheckBox chooseC = view.findViewById(R.id.chooseC);
            CheckBox chooseD = view.findViewById(R.id.chooseD);
            CheckBox chooseE = view.findViewById(R.id.chooseE);
            CheckBox chooseF = view.findViewById(R.id.chooseF);
            CheckBox chooseG = view.findViewById(R.id.chooseG);

            if(btnPrevious != null){
                //ボタンの活性非活性表示
                if (myPrefs.getInt("now", 0) == 0) {
                    //一番前の問題まで来た場合
                    btnPrevious.setEnabled(false);
                } else {
                    btnPrevious.setEnabled(true);
                }
            }

            if(btnNext != null){
                strBtnNext = btnNext.getText().toString();
            }
            if (myPrefs.getInt("now", 0) == Integer.parseInt(myPrefs.getString("count", null)) - 1) {
                //一番後ろの問題まで来た場合
                btnNext.setText("終了");
            } else if (strBtnNext.equals("終了")) {
                //終了ボタンが押された場合
                editor.putString("menu", "問題終了");
                editor.commit();
                back();
                migrate(ProblemEndFragment.newInstance());
            } else {
                //一番最後の画面から前に戻った場合
                if(btnNext != null){
                    btnNext.setText("次へ");
                }
            }

            if(textNumberOfIssues != null){
                //問題数表示
                textNumberOfIssues.setText(myPrefs.getInt("now", 0) + 1 + "/" + myPrefs.getString("count", null));
                //問題を表示
                textQuestion.setText(result.getQuestion());
            }
            //回答を表示
            try{
                if (result.getChoice().equals("on")) {
                    //表示する問題が選択問題だった場合
                    if(etReply != null){
                        etReply.setVisibility(View.INVISIBLE);
                    }
                    margin(-100, R.id.chooseA, "checkbox");

                    if (!result.getChoiceA().equals("")) {
                        //選択肢が登録されている場合
                        chooseA.setText(result.getChoiceA());
                    }
                    if (!result.getChoiceB().equals("")) {
                        //選択肢が登録されている場合
                        chooseB.setText(result.getChoiceB());
                    } else {
                        chooseB.setVisibility(View.INVISIBLE);
                    }
                    if (!result.getChoiceC().equals("")) {
                        //選択肢が登録されている場合
                        chooseC.setText(result.getChoiceC());
                    } else {
                        chooseC.setVisibility(View.INVISIBLE);
                    }
                    if (!result.getChoiceD().equals("")) {
                        //選択肢が登録されている場合
                        chooseD.setText(result.getChoiceD());
                    } else {
                        chooseD.setVisibility(View.INVISIBLE);
                    }
                    if (!result.getChoiceE().equals("")) {
                        //選択肢が登録されている場合
                        chooseE.setText(result.getChoiceE());
                    } else {
                        chooseE.setVisibility(View.INVISIBLE);
                    }
                    if (!result.getChoiceF().equals("")) {
                        //選択肢が登録されている場合
                        chooseF.setText(result.getChoiceF());
                    } else {
                        chooseF.setVisibility(View.INVISIBLE);
                    }
                    if (!result.getChoiceG().equals("")) {
                        //選択肢が登録されている場合
                        chooseG.setText(result.getChoiceG());
                    } else {
                        chooseG.setVisibility(View.INVISIBLE);
                    }
                } else {
                    //表示する問題が記述問題だった場合
                    //A~Gの選択肢を消す
                    chooseA.setVisibility(View.INVISIBLE);
                    chooseB.setVisibility(View.INVISIBLE);
                    chooseC.setVisibility(View.INVISIBLE);
                    chooseD.setVisibility(View.INVISIBLE);
                    chooseE.setVisibility(View.INVISIBLE);
                    chooseF.setVisibility(View.INVISIBLE);
                    chooseG.setVisibility(View.INVISIBLE);

                    //回答入力欄の表示
                    etReply.setVisibility(View.VISIBLE);

                }
            }catch (NullPointerException e){
                e.printStackTrace();
            }

            Map<Integer, Object> map = null;
            //インスタンス化
            ObjectMapper mapper = new ObjectMapper();

            try {
                // キーがString、値がObjectのマップに読み込みます。
                map = mapper.readValue(myPrefs.getString("reply", null), new TypeReference<Map<Integer, Object>>() {
                });
            } catch (Exception e) {
                // エラー！
                e.printStackTrace();
            }

            oneReply = (String) map.get(Integer.parseInt((String) problemList.get(myPrefs.getInt("now", 0))));

            try {
                if (oneReply != null) {
                    //既に回答済みの場合
                    if (oneReply.indexOf("ア") != -1) {
                        chooseA.setChecked(true);
                    }
                    if (oneReply.indexOf("イ") != -1) {
                        chooseB.setChecked(true);
                    }
                    if (oneReply.indexOf("ウ") != -1) {
                        chooseC.setChecked(true);
                    }
                    if (oneReply.indexOf("エ") != -1) {
                        chooseD.setChecked(true);
                    }
                    if (oneReply.indexOf("オ") != -1) {
                        chooseE.setChecked(true);
                    }
                    if (oneReply.indexOf("カ") != -1) {
                        chooseF.setChecked(true);
                    }
                    if (oneReply.indexOf("キ") != -1) {
                        chooseG.setChecked(true);
                    }
                    etReply.setText(oneReply);
                }

                //チェックボックスが押された場合
                chooseA.setOnClickListener(parts -> {
                    if (chooseA.isChecked()) {
                        if ("".equals(oneReply)) {
                            oneReply += "ア";
                        } else {
                            oneReply += ",ア";
                        }
                    } else {
                        oneReply = oneReply.replace("ア", "");
                    }
                });
                chooseB.setOnClickListener(parts -> {
                    if (chooseB.isChecked()) {
                        if ("".equals(oneReply)) {
                            oneReply += "イ";
                        } else {
                            oneReply += ",イ";
                        }
                    } else {
                        oneReply = oneReply.replace("イ", "");
                    }
                });
                chooseC.setOnClickListener(parts -> {
                    if (chooseC.isChecked()) {
                        if ("".equals(oneReply)) {
                            oneReply += "ウ";
                        } else {
                            oneReply += ",ウ";
                        }
                    } else {
                        oneReply = oneReply.replace("ウ", "");
                    }
                });
                chooseD.setOnClickListener(parts -> {
                    if (chooseD.isChecked()) {
                        if ("".equals(oneReply)) {
                            oneReply += "エ";
                        } else {
                            oneReply += ",エ";
                        }
                    } else {
                        oneReply = oneReply.replace("エ", "");
                    }
                });
                chooseE.setOnClickListener(parts -> {
                    if (chooseE.isChecked()) {
                        if ("".equals(oneReply)) {
                            oneReply += "オ";
                        } else {
                            oneReply += ",オ";
                        }
                    } else {
                        oneReply = oneReply.replace("オ", "");
                    }
                });
                chooseF.setOnClickListener(parts -> {
                    if (chooseF.isChecked()) {
                        if ("".equals(oneReply)) {
                            oneReply += "カ";
                        } else {
                            oneReply += ",カ";
                        }
                    } else {
                        oneReply = oneReply.replace("カ", "");
                    }
                });
                chooseG.setOnClickListener(parts -> {
                    if (chooseG.isChecked()) {
                        if ("".equals(oneReply)) {
                            oneReply += "キ";
                        } else {
                            oneReply += ",キ";
                        }
                    } else {
                        oneReply = oneReply.replace("キ", "");
                    }
                });

                //------------------------------バーが操作された場合----------------------------------------
                // SeekBar
                SeekBar problemBar = view.findViewById(R.id.problemBar);
                if(Integer.parseInt(myPrefs.getString("count", null)) == 1){
                    //問題の個数が1個だった場合
                    problemBar.setVisibility(View.INVISIBLE);
                }
                // 初期値
                problemBar.setProgress(myPrefs.getInt("now",0));
                // 最大値
                problemBar.setMax(Integer.parseInt(myPrefs.getString("count",null))-1);
                problemBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    //ツマミがドラッグされると呼ばれる
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        //下の問題数変更
                        textNumberOfIssues.setText(progress+1 + "/" + myPrefs.getString("count",null));
                        // 初期値
                        problemBar.setProgress(progress);
                        SharedPreferences.Editor editor = myPrefs.edit();
                        //現在のページを変更
                        editor.putInt("now", progress);
                        editor.commit();
                    }

                    //ツマミがタッチされた時に呼ばれる
                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                        editor.putInt("beforeNow", myPrefs.getInt("now",0));
                        editor.commit();
                    }

                    //ツマミがリリースされた時に呼ばれる
                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        //確定させる
                        memoActivity(-1, 0);
                    }

                });
            }catch (NullPointerException e){
                e.printStackTrace();
            }

        }catch (NullPointerException e){
            e.printStackTrace();
        }
    }

    //----------------------------メモ帳が押された場合-------------------------------------
    @Override
    public void onResume() {
        super.onResume();
        //保存ファイルに接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        if(myPrefs.getInt("problemMemoFlg",0) == 1 || myPrefs.getInt("problemMemoFlg",0) == 4){

            _helper = new DatabaseHelper(getActivity());
            SQLiteDatabase db = _helper.getWritableDatabase();

            Cursor cursor = MemoDAO.findAll(db, myPrefs.getString("userId", null));

            list(cursor);
        }
    }

    /**
     * リストがクリックされた時のリスナクラス
     */
    private class ListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            Cursor item = (Cursor) parent.getItemAtPosition(position);
            int idxId = item.getColumnIndex("_id");
            long idNo = item.getLong(idxId);

            SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = myPrefs.edit();

            if(myPrefs.getInt("problemMemoFlg",0) == 1){
                //分割画面でリストが選択された場合
                editor.putInt("problemMemoFlg", 2);
            }else{
                //拡大表示状態でリストが選択された場合
                editor.putInt("problemMemoFlg", 5);
            }
            editor.commit();

            memoActivity(idNo, 1);
        }
    }

    /**
     * メモ帳のリストビューのカスタムビューバインダークラス。
     */
    private class CustomViewBinder implements SimpleCursorAdapter.ViewBinder {
        @Override
        public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
            switch (view.getId()) {
                case R.id.accountTitle:
                    //タイトル
                    TextView accountTitle = view.findViewById(R.id.accountTitle);
                    accountTitle.setText(cursor.getString(columnIndex));
                    return true;
                case R.id.updateDelete:
                    //削除ボタン
                    long id = Long.parseLong(cursor.getString(columnIndex));
                    ImageView btnDelete = (ImageView)view;

                    Resources res = getResources();
                    int chocolate_color = res.getColor(R.color.list);
                    if(cursor.getPosition() % 2 == 0){
                        //idが偶数の場合
                        ((ViewGroup)btnDelete.getParent()).setBackgroundColor(chocolate_color);
                    }else{
                        ((ViewGroup)btnDelete.getParent()).setBackgroundColor(Color.rgb(255, 255, 255));
                    }

                    btnDelete.setOnClickListener((View v) -> {
                        //削除ボタンが押された場合
                        LayoutInflater inflater = getActivity().getLayoutInflater();
                        View dialogView = inflater.inflate(R.layout.dialog_delete_check, null, false);
                        //ダイアログ作成
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setView(dialogView);

                        builder.setPositiveButton(R.string.dialogDeleteTitle, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //データベース接続
                                _helper = new DatabaseHelper(getActivity());
                                SQLiteDatabase db = _helper.getWritableDatabase();

                                //保存領域に接続
                                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);

                                MemoDAO.delete(db, id);

                                Cursor cursor = MemoDAO.findAll(db, myPrefs.getString("userId", null));

                                list(cursor);
                            }
                        });

                        builder.setNegativeButton(R.string.btnCancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });

                        //ダイアログ出力
                        builder.create().show();
                    });
                    return true;
            }
            return false;
        }
    }

    public void list(Cursor cursor){
        ListView problemList = view.findViewById(R.id.dialogReportList);

        String[] from = {"title", "_id"};
        int[] to = {R.id.accountTitle, R.id.updateDelete};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(getActivity(), R.layout.upload_delete, cursor, from, to, 0);
        adapter.setViewBinder(new CustomViewBinder());
        problemList.setAdapter(adapter);
    }

    /**
     * marginの動的の変更
     */
    public void margin(int value, int parts, String style){
        if(style.equals("checkbox")){
            try {
                CheckBox margin = view.findViewById(parts);
                ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams)margin.getLayoutParams();
                layoutParams.topMargin = value;
                margin.setLayoutParams(layoutParams);
            }catch (NullPointerException e){
                e.printStackTrace();
            }
        }
    }

    //制限時間を出力するメソッド
    public void time(){
        TextView time = (TextView)view.findViewById(R.id.textTimeLimit);
//        SharedPreferences.Editor editor = myPrefs.edit();
        countDownTimer = new CountDownTimer(alltime, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                //保存ファイルに接続
//                SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = myPrefs.edit();
                alltime = millisUntilFinished;
                editor.putLong("alltime", millisUntilFinished);
                // 残り分
                long m = millisUntilFinished / 1000 / 60;
                // 残り秒
                long s = millisUntilFinished / 1000 % 60;

                editor.putLong("minit", m);
                editor.putLong("second", s);

                editor.commit();
                if(m == 0){
                    time.setText("制限時間: "+s+"秒");
                }else{
                    time.setText("制限時間: "+m+"分"+String.format("%02d", s)+"秒");
                }
            }

            @Override
            public void onFinish() {
                _helper = new DatabaseHelper(getActivity());
                SQLiteDatabase db = _helper.getWritableDatabase();

                SharedPreferences.Editor editor = myPrefs.edit();

                Bundle args = getArguments();

                ArrayList<String> problemList = args.getStringArrayList("problemList");

                try{
                    EditText etReply = view.findViewById(R.id.etReply);
                    String strReply = "";
                    if(etReply != null){
                        strReply = etReply.getText().toString();
                    }

                    Problem result = null;

                    if(result.getChoice().equals("off")){
                        //記述式だった場合
                        oneReply = strReply;
                    }
                }catch (NullPointerException e){
                    e.printStackTrace();
                }

                Map<Integer, Object> map = null;
                //インスタンス化
                ObjectMapper mapper = new ObjectMapper();

                try {
                    // jsonからmapに変換
                    map = mapper.readValue(myPrefs.getString("reply", null), new TypeReference<Map<Integer, Object>>() {
                    });
                } catch (Exception e) {
                    // エラー！
                    e.printStackTrace();
                }
                if(!"".equals(oneReply)) {
                    //回答されていた場合
                    map.put(Integer.parseInt((String) problemList.get(myPrefs.getInt("now",0))), oneReply);
                }
                String jsonReply = "";
                try {
                    // mapをjson文字列に変換します。
                    jsonReply = mapper.writeValueAsString(map);
                } catch (Exception e) {
                    // エラー!
                    e.printStackTrace();
                }
                editor.putString("reply", jsonReply);
                editor.putLong("alltime", 0);
                editor.putString("menu", "");
                editor.commit();
                back();
                migrate(ProblemEndFragment.newInstance());
            }
        }.start();
    }

    /**
     * メモ帳に飛ぶときに値を渡すメソッド
     * @param id
     * @param nowPageChange 現在の答えを更新する(1)or遷移前のページを更新する(0)
     */
    public void memoActivity(long id, int nowPageChange){
        //データベースに接続
        if(countDownTimer != null){
            countDownTimer.cancel();
        }
        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        //保存ファイルに接続
        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        Bundle args = getArguments();

        ArrayList<String> problemList = args.getStringArrayList("problemList");

        try{
            EditText etReply = view.findViewById(R.id.etReply);
            String strReply = "";
            if(etReply != null){
                strReply = etReply.getText().toString();
            }

            Problem result = null;

            if(nowPageChange == 0){
                //遷移前のページを更新する場合
                result = ProblemDAO.findIdByPK(db, problemList.get(myPrefs.getInt("beforeNow",myPrefs.getInt("now",0))));
            }else{
                result = ProblemDAO.findIdByPK(db, problemList.get(myPrefs.getInt("now", 0)));
            }

            if(result.getChoice().equals("off")){
                //記述式だった場合
                oneReply = strReply;
            }
        }catch (NullPointerException e){
            e.printStackTrace();
        }

        Map<Integer, Object> map = null;
        //インスタンス化
        ObjectMapper mapper = new ObjectMapper();

        try {
            // jsonからmapに変換
            map = mapper.readValue(myPrefs.getString("reply", null), new TypeReference<Map<Integer, Object>>() {
            });
        } catch (Exception e) {
            // エラー！
            e.printStackTrace();
        }
        if(!"".equals(oneReply)) {
            //回答されていた場合
            if(nowPageChange == 0){
                //遷移前のページを更新する場合
                map.put(Integer.parseInt((String) problemList.get(myPrefs.getInt("beforeNow",myPrefs.getInt("now",0)))), oneReply);
            }else{
                //現在のページを更新する場合
                map.put(Integer.parseInt((String) problemList.get(myPrefs.getInt("now",0))), oneReply);
            }
        }

        String jsonReply = "";
        try {
            // mapをjson文字列に変換します。
            jsonReply = mapper.writeValueAsString(map);
        } catch (Exception e) {
            // エラー!
            e.printStackTrace();
        }
        editor.putInt("beforeNow", myPrefs.getInt("now",0));
        editor.putString("reply", jsonReply);
        editor.commit();

        if(id != 0){
            //リストがクリックされた場合
            back();
            migrate(ProblemFragment.newInstance(problemList, id, MODE_INSERT));
        }else{
            back();
            migrate(ProblemFragment.newInstance(problemList, Long.parseLong(String.valueOf(0)), 0));
        }
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        try{
            FragmentManager fragmentManager = getParentFragmentManager();
            FragmentTransaction fragmentTransaction =
                    fragmentManager.beginTransaction();
            // BackStackを設定
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.setReorderingAllowed(true);

            fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                    fragment);
            fragmentTransaction.commit();
        }catch (IllegalStateException e){
            e.printStackTrace();
        }
    }

    //戻るためのメソッド
    public void back(){
        try{
            FragmentManager fragmentManager = getParentFragmentManager();
            fragmentManager.popBackStack();
        }catch (IllegalStateException e){
            e.printStackTrace();
        }
    }
}
package local.hal.st31.android.studyapplication3.ui.home.ProblemQuestion;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import local.hal.st31.android.studyapplication3.Database.DatabaseHelper;
import local.hal.st31.android.studyapplication3.Database.ProblemDAO;
import local.hal.st31.android.studyapplication3.Database.TitleList;
import local.hal.st31.android.studyapplication3.Database.TitleListDAO;
import local.hal.st31.android.studyapplication3.R;
import local.hal.st31.android.studyapplication3.ui.account.LoginFragment;
import local.hal.st31.android.studyapplication3.ui.home.HomeFragment;
import local.hal.st31.android.studyapplication3.ui.home.Memo.MemoTopFragment;
import local.hal.st31.android.studyapplication3.ui.home.ProblemMake.ProblemMakeFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProblemTopFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProblemTopFragment extends Fragment {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    View view;

    //フラグメントを呼び出す
    public static ProblemTopFragment newInstance(Long idNo){
// Fragemnt01 インスタンス生成
        ProblemTopFragment ProblemTopFragment = new ProblemTopFragment();

        Bundle args = new Bundle();
        args.putLong("idNo", idNo);
        ProblemTopFragment.setArguments(args);

        return ProblemTopFragment;
    }

    //表示画面を出力
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_problem_top,
                container, false);

        //既存の戻るボタンの無効化
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    return true;
                }
                return false;
            }
        });

        SharedPreferences myPrefs = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        editor.putString("menu", "");
        editor.commit();
        setHasOptionsMenu(true);

        return view;
    }

    //処理を記述
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;

        _helper = new DatabaseHelper(getActivity());
        SQLiteDatabase db = _helper.getWritableDatabase();

        //保存領域に接続
        SharedPreferences myPrefs = this.getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();

        Bundle args = getArguments();

        ArrayList<String> problemList = ProblemDAO.ProblemIdAll(db, args.getLong("idNo"));

        //メモボタンが押された場合
        FloatingActionButton memo = view.findViewById(R.id.problemTopMemo);
        memo.setOnClickListener((View v) -> {
            migrate(MemoTopFragment.newInstance());
        });

        //戻るボタンが押された場合
        ImageView btnBack = view.findViewById(R.id.problemTopBack);
        btnBack.setOnClickListener((View v) -> {
            back();
        });

        //スタートボタンが押された場合
        Button btnStart = view.findViewById(R.id.btnStart);
        btnStart.setOnClickListener((View v) -> {
            back();
            migrate(CountDownFragment.newInstance(problemList));
        });

        TextView textTitle = view.findViewById(R.id.textfroant);
        TextView textNumberOfIssues = view.findViewById(R.id.textNumberOfIssues);
        TextView textTime = view.findViewById(R.id.textBack);

        TitleList titleResult = TitleListDAO.findIdByPK(db, args.getLong("idNo"));
        String count = ProblemDAO.countProblem(db, args.getLong("idNo"));
        //時間を分に変換
        int time = Integer.parseInt(titleResult.getTime());
        int minit = 0;
        String strTime = "";

        for(int i=0;i<17;i++){
            if(time >= 60 * i + 1){
                minit = time - (i * 60);
                if(minit == 0){
                    if(i == 0){
                        //時間が0だった場合
                        strTime = time + "分";
                    }else{
                        strTime = i + "時間";
                    }
                }else{
                    if(i == 0){
                        strTime = time + "分";
                    }else{
                        strTime = i + "時間" + minit + "分";
                    }
                }
            }else{
                break;
            }
        }

        textTitle.setText(titleResult.getTitle());
        textNumberOfIssues.setText("出題数:" + count + "問");
        textTime.setText(strTime);

        //回答枠を作成
        Map<Integer, String> reply = new HashMap<>();
        for(int i=0;i<Integer.parseInt(count);i++){
            reply.put(Integer.parseInt((String) problemList.get(i)), "");
        }
        //インスタンス化
        ObjectMapper mapper = new ObjectMapper();

        String jsonReply = null;
        try {
            // mapをjson文字列に変換します。
            jsonReply = mapper.writeValueAsString(reply);
        } catch (Exception e) {
            // エラー!
            e.printStackTrace();
        }

        //タイトルID
        editor.putLong("titleId", titleResult.getId());
        //問題数
        editor.putString("count", count);
        //時間
        editor.putInt("time", time);
        //現在のページ
        editor.putInt("now", 0);
        //回答を代入するjsonデータを送る
        editor.putString("reply", jsonReply);
        //ページ遷移前のページ
        editor.putInt("beforeNow", 0);
        //問題を解く画面のレイアウトをデフォルトに設定
        editor.putInt("problemMemoFlg", 0);
        //メモ帳タイトルを初期化する
        editor.putLong("memoTitleId", 0);
        // タイマー終了時間
        editor.putLong("alltime", (long) time * 1000 * 60);
        editor.commit();
    }

    //画面遷移するためのメソッド
    public void migrate(Fragment fragment){
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        // BackStackを設定
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setReorderingAllowed(true);

        fragmentTransaction.replace(R.id.nav_host_fragment_content_main,
                fragment);
        fragmentTransaction.commit();
    }

    //戻るためのメソッド
    public void back(){
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.popBackStack();
    }
}
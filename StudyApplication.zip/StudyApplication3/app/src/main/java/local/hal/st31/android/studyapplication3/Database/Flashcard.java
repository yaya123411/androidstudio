package local.hal.st31.android.studyapplication3.Database;

public class Flashcard {
    /**
     * 問題番号
     */
    private long _Id;
    /**
     * タイトルID
     */
    private long _flashcardTitleId;
    /**
     * 表
     */
    private String _front;
    /**
     * 裏
     */
    private String _back;
    /**
     * 覚えたフラグ(覚えた=1、覚えてない=0)
     */
    private int _remember;
    /**
     * 更新日
     */
    private String _updateTime;

    //以下アクセサメソッド

    public long getId(){
        return _Id;
    }
    public void setId(long Id){
        _Id = Id;
    }
    public long getFlashcardTitleId(){
        return _flashcardTitleId;
    }
    public void setFlashcardTitleId(long flashcardTitleId){
        _flashcardTitleId = flashcardTitleId;
    }
    public String getFront(){
        return _front;
    }
    public void setFront(String front){
        _front = front;
    }
    public String getBack(){
        return _back;
    }
    public void setBack(String back){
        _back = back;
    }
    public int getRemember(){
        return _remember;
    }
    public void setRemember(int remember){
        _remember = remember;
    }
    public String getUpdateTime(){
        return _updateTime;
    }
    public void setUpdateTime(String updateTime){
        _updateTime = updateTime;
    }
}
